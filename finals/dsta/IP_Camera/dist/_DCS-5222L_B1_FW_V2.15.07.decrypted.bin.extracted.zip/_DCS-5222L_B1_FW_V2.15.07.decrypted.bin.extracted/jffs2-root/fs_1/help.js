var MENU_ITEM_HELP = new Array(
"help_menu","",1,
"checkout","checkout.htm",1);

var g_showsd = (g_supportsdhide==0) || (parseInt(GV("<%sdinsert%>",0))==1 && parseInt(GV("<%sdformat%>",1))==1);
var g_showAF = g_isSupportAF && (g_isSupportVisca==0);
var g_showPreset = g_isSupportEPTZ && (g_isSupportVisca==0);
var g_supportFishEye=parseInt(GV("<%supportfisheye%>",0)); //support fisheye

var g_supportvnf=parseInt(GV("<%supportvnf%>",0));

var g_supportpiris=parseInt(GV("<%supportpiris%>",0));

//start--2014.12.04 added
var g_supportmotionpercentage = parseInt(GV("<%supportmotionpercentage%>","0"));
//end--2014.12.04

//===========================================
// c_help.htm
//===========================================
var helpCameraArray = new Array(
  "livevideostring",1);
  
var helpSetupArray = new Array(
  "setup_wizard",1,
  "network_setup",1,
  "setup_wifi",g_supportWifi,
  "dynamic_dns",1,
  "image_setup",1,
  "audio_and_video",1,
  "setup_auto_focus_t",g_showAF,
  "setup_auto_perset_t",g_showPreset,
  "setup_ptzsetup",g_support_real_ptz==1,
  "motion_detection",1,
  "setup_sound_detection",g_supportsound_detection==1,  
  "setup_tamper",g_supporttamper==1,
  "time_and_date",1,
  "setup_event",1,
  "setup_sdlist",g_showsd );
  
var helpAdvancedArray = new Array(
  "setup_digital_io",(g_supgioin>0 || g_supgioout>0 || g_suptvout==1 && g_suptLed==1) && g_supportFishEye==0 ,
  "setup_rs485",g_isSupportRS485 && (g_isSupportVisca==0),
  (s_irled==0?"setup_icr":(g_supportirledcolor==1?"setup_icr_ir_color":"setup_icr_ir")),g_s_daynight,
  "setup_white_light_led",g_supportwhitelightled,
  "setup_https",1,
  "setup_access_list",1,
  "setup_snmp",g_isSupportsnmp  
  );
  
var helpMaintenanceArray = new Array(
  "maintenanceStrimg",1,
  "maintenanceStrimg1",1,
  "maintenanceStrimg2",1);
  
var helpStstusArray=new Array(
  "ststusString1",1,
  "ststusString2",1);


//===========================================
// help_camera.htm
//===========================================   
  var helpStrArray = new Array(
    "video_profile_str_1",1,
    "full_screen_str",1,
    "snapshotstr",1,
    "client_recording_str",1,
    "set_path_str",1,
    "listen_str",g_isSupportAudio==1,
    "talk_str",g_isSupportTwoWayAudio==1,
    "start_stop_digital_output_str", g_supportFishEye!=1  && g_supgioin>0,
    "digital_input_indicator_str", g_supportFishEye!=1  && g_supgioin>0,
    "motion_detection_trigger_str",1,
    "recording_trigger_str",1,
    "language_str",1,
    "Go_To_Preset_List",1,
    "ePTZ_pad",1,
    "help_SD_Status",1,
    "help_IO_Status",g_supgioout>0,
    "help_Global_view",g_isSupportEPTZ==1
  );

//===========================================
// help_setup.htm
//===========================================  
  var helpStrArray_setup = new Array(
    "internet_connection_settings_str",1,
	"ip_motion_detection_settings_str",1
  );
 
  var helpStrArray_net = new Array(
    "lan_setting_str",1,
    "dns1_str",0,
    "pppoe_setting_str",1,
    "http_port_str",1,
    "https_port_str",1,
    "rtsp_port_str",1,
	"traffic_str",(g_supportbwc==1 && g_supportqos==0 && g_supportcos==0),
	"help_cos",g_supportcos==1,
	"help_qos",g_supportqos==1,
	"help_ipv6_enable",g_supportIPv6==1,
    "help_ipv6_information",g_supportIPv6==1,
    "help_ipv6_manually",g_supportIPv6==1,
    "help_enable_multicast",g_isSupportMulticast==1,
    "help_rtc_videoaudio_port",g_isSupportMulticast==1,
    "help_Bonjour",g_supportbonjour==1
  );
  
  var helpStrArray_wifi = new Array(
	"help_setup_wifi2_enable",1,
	"help_setup_wifi2_ssid",1,
	"help_setup_wifi_mode",1,
	"help_setup_wifi2_security",1,
	"help_setup_wps",g_support_wps_conf==1,
	"help_eap_txt",g_support_wpa_enterprise==1
  );

  var helpStrArray_dns = new Array(
    "dynamic_dns1_str",1,
    "dns1_str",1,
    "user_name_d_str",1,
    "password_d_str",1,
    "verify_password_str",1,
    "timeout_str",1
  );
  
//--start 2011.3.29 added, for new exposure mode
  var s_exposuremode = parseInt(GV("<%supportexposuretimemode%>",0));// 0/1= old/new exposuretime
  var s_metering	 = parseInt(GV("<%supportmeteringmethod%>",0));//Metering Method
  var s_denoise		 = parseInt(GV("<%supportdenoise%>",0));//denoise
  var s_ev		     = parseInt(GV("<%supportevcomp%>",0));//ev
  var s_dre		     = parseInt(GV("<%supportdre%>",0));//dynamic range enhancement
//--end 2011.3.29
//--start 2011.4.6
  var s_flicker	   = parseInt("<%supportantiflicker%>");
//--end 2011.4.6
  var s_mir          = parseInt("<%supportmirror%>");//Enabled mirroi
  var s_flip         = parseInt("<%supportflip%>");//Enabled flip
  var s_blc          = parseInt("<%supportblcmode%>");
  var s_hue          = parseInt("<%supporthue%>");
  var s_awb          = parseInt("<%supportAWB%>");
  var s_agc          = parseInt("<%supportagc%>");
  var s_agcctrl      = parseInt("<%supportagcctrl%>");
  var s_exposuretime = parseInt("<%supportexposuretime%>");
  var s_bright       = parseInt("<%supportbrightness%>");
  var s_contrast     = parseInt("<%supportcontrast%>");
  var s_sat          = parseInt("<%supportsaturation%>");
  var s_sharp        = parseInt("<%supportsharpness%>");
  var s_flickless    = parseInt(GV("<%supportflickless%>",0));
  var s_wdrlevel     = parseInt(GV("<%supportwdrlevel%>",1));

  var helpStrArray_img = new Array(
    "privacy_mask_str",!g_supportFishEye,
	"setup_image_help_antiflicker",s_flicker,
	"mirror_str",s_mir,
	"flip_str",s_flip,
	"blc_str",s_blc,
	(g_powerlinedisplay ? "setup_image_rightTxt_a5" : "setup_image_help_antiflicker"),s_flickless,
    "awb_str",s_awb,
    "setup_image_rightTxt_3_1",s_exposuremode==0 && s_exposuretime,//2011.3.29 modified, for old exposure time
	"setup_image_help_ExposureMode",s_exposuremode==1 && s_exposuretime,//2011.3.29 added, for new exposure mode
	"help_Iris_adjustment",(s_exposuremode==1 && s_exposuretime) && g_supportpiris,//2012.4.10 added, for new iris mode
	"help_Iris_speed",(s_exposuremode==1 && s_exposuretime) && g_supportpiris,//2012.4.10 added, for new iris mode
    "setup_image_help_MaxGain",s_exposuremode==1 && s_exposuretime,
	"agc_str",s_exposuremode==0 && s_agc,//s_agcctrl,//2011.3.29 modified, for old exposure time
	"setup_image_help_denoise",s_denoise,//2011.3.29 added, for new exposure mode
    "brightness_str",s_bright,
    "contrast_str",s_contrast,
    "saturation_str",s_sat,
    "sharpness_str",s_sharp,
    "wdrlevel_str",s_wdrlevel,
	"setup_image_rightTxt_11",g_supportFishEye==1  || g_support_real_ptz==1,
	"setup_image_rightTxt_12",g_supportvnf==1		//3D filter
  );

/*
  helpStrArray_img[4] = "hue";   helpStrArray_img[5] = "hue_str";
  helpStrArray_img[6] = "blc";   helpStrArray_img[7] = "blc_str";
  helpStrArray_img[12] = "aes";  helpStrArray_img[13] = "aes_str";
*/
  var len = ("<%profile1resolutionname.all%>").split(";").length;
  var slist = "<%profile1resolutionname.all%>".split(";");
  var str = GL("frame_size_str_1",{1:len,2:slist[len-1],3:slist[0]});
  //start added--2011.1.14
  var g_supportprofilenumber = GV("<%supportprofilenumber%>","0");
  var g_supportaspectratio = GV("<%supportaspectratio%>","0");
  //end added--2010.1.14
  var helpStrArray_audio = new Array(
    "setup_av_help_profileNumber",parseInt(g_supportprofilenumber),
	"setup_av_help_AspectRatio",parseInt(g_supportaspectratio),
    "video_profile_str_1",1,
    "encode_mode_str_1",1,
    str,1,
	"help_intra_period",g_supportgoplength,
	"setup_av_view_window",1,
    "max_frame_rate_str",1,
    "setup_av_rightTxt_4",1,
    "audio_setup_str",g_isSupportAudio
  );

/*
  helpStrArray_audio[2] = "encode_type";      helpStrArray_audio[3] = "encode_type_str";
  helpStrArray_audio[4] = "resolution_a";     helpStrArray_audio[5] = "resolution_a_str";
  helpStrArray_audio[8] = "fixed_bit_rate";   helpStrArray_audio[9] = "fixed_bit_rate_str";
  helpStrArray_audio[10] = "jpeg_quality";    helpStrArray_audio[11] = "jpeg_quality_str";
  helpStrArray_audio[12] = "rtsp_url";     helpStrArray_audio[13] = "rtsp_url_str";
  helpStrArray_audio[16] = "enable_speaker";  helpStrArray_audio[17] = "enable_speaker_str";
  helpStrArray_audio[18] = "speaker_volume";  helpStrArray_audio[19] = "speaker_volume_str";
  helpStrArray_audio[20] = "enable_microphone";  helpStrArray_audio[21] = "enable_microphone_str";
  helpStrArray_audio[22] = "microphone_volume";  helpStrArray_audio[23] = "microphone_volume_str";
*/

  var helpStrArray_mo = new Array(
    "enable_video_motion_str",1,
    "sensitivity_str",1,
    "percentage_str",g_supportmotionpercentage==1,
	"setup_ee_rightTxt_pir2",(g_supportpir==1)
  );
//20140411
 var helpStrArray_sound = new Array(
 	"setup_sound_detect_rightTxt_2",1
  );
 var helpStrArray_ptz = new Array(
    "setup_viscasetup_help_autopan",1,
    "setup_viscasetup_help_cruise",1,
	"setup_viscasetup_help_homefunction",1
  );  

var helpStrArray_tamper = new Array(
	"setup_tamper_rightTxt_0",1,
	"setup_tamper_rightTxt_1",1,
	"setup_tamper_rightTxt_2",0
  );
  ////////////////////////////
  var helpStrArray_time = new Array(
    "time_zone_str",1,
    "enable_daylight_savings_str",1,
    "auto_daylight_saving_str",1,
    "daylight_savings_dates_str",1,
    "daylight_savings_offset_str",1,
    "offset_str",1,
    "automatic_time_configuration_str",1,
    "synchronize_ntp_server_str",1,
    "ntp_server_str",1,
    "manual_str",1,
    "copy_your_computer_str",1
  );

  var helpStrArray_rec = new Array(
    "enable_recording_str",1,
    "samba_auth_str",1,
    "user_name_re_str",1,
    "password_re_str",1,
    "password_confim_str",1,
    "server_re_str",1,
    "shared_folder_re_str",1,
    "test_str",1,
    "get_status_str",1,
    "resolution_re_str",1,
    "record_of_free_space_is_left_str",1,
    "storage_is_full_str",1,
    "overwrite_older_recordings_str",1,
    "continuous_str",1,
    "event_based_str",1,
    "prerecord_seconds_str",1,
    "postrecord_seconds_str",1,
    "scheduled_re_str",1
  );

  var helpStrArray_sna = new Array();
  helpStrArray_sna[0] = "enable_snapshot";  helpStrArray_sna[1] = "enable_snapshot_str";
  helpStrArray_sna[2] = "trigger_event";    helpStrArray_sna[3] = "trigger_event_str";
  helpStrArray_sna[4] = "e_mail_Setting";   helpStrArray_sna[5] = "e_mail_Setting_str";
  helpStrArray_sna[6] = "mail_address";     helpStrArray_sna[7] = "mail_address_str";
  helpStrArray_sna[8] = "user_name_e";      helpStrArray_sna[9] = "user_name_e_str";
  helpStrArray_sna[10] = "password_e";      helpStrArray_sna[11] = "password_e_str";
  helpStrArray_sna[12] = "smtp_mail_server";helpStrArray_sna[13] = "smtp_mail_server_str";
  helpStrArray_sna[14] = "sender_mail_address";helpStrArray_sna[15] = "sender_mail_address_str";
  helpStrArray_sna[16] = "recipient_mail_address";helpStrArray_sna[17] = "recipient_mail_address_str";
  helpStrArray_sna[18] = "port_e";          helpStrArray_sna[19] = "port_e_str";
  helpStrArray_sna[20] = "ftp_setting";     helpStrArray_sna[21] = "ftp_setting_str";
  helpStrArray_sna[22] = "dtp_server";      helpStrArray_sna[23] = "dtp_server_str";
  helpStrArray_sna[24] = "user_name_ftp";   helpStrArray_sna[25] = "user_name_ftp_str";
  helpStrArray_sna[26] = "password_ftp";    helpStrArray_sna[27] = "password_ftp_str";
  helpStrArray_sna[28] = "host_name_ftp";   helpStrArray_sna[29] = "host_name_ftp_str";
  helpStrArray_sna[30] = "path_str";        helpStrArray_sna[31] = "path_str_str";
  helpStrArray_sna[32] = "filename_prefix"; helpStrArray_sna[33] = "filename_prefix_str";
  helpStrArray_sna[34] = "port_ftp";        helpStrArray_sna[35] = "port_ftp_str";
  helpStrArray_sna[36] = "passive_mode";    helpStrArray_sna[37] = "passive_mode_str";
  
  var helpStrArray_dig = new Array();
  helpStrArray_dig[0] = "enable_signal";  helpStrArray_dig[1] = "enable_signal_str";
  helpStrArray_dig[2] = "trigger_event_d";    helpStrArray_dig[3] = "trigger_event_d_str";
  helpStrArray_dig[4] = "motion_detection_d";   helpStrArray_dig[5] = "motion_detection_d_str";
  helpStrArray_dig[6] = "signal1";     helpStrArray_dig[7] = "signal1_str";
  helpStrArray_dig[8] = "signal2";      helpStrArray_dig[9] = "signal1_str";
   
  var helpStrArray_485 = new Array();
  helpStrArray_485[0] = "supportpan";  helpStrArray_485[1] = "supportpan_str";
  helpStrArray_485[2] = "protocol_rs"; helpStrArray_485[3] = "protocol_rs_str";
  helpStrArray_485[4] = "id_rs";       helpStrArray_485[5] = "id_rs_str";
  helpStrArray_485[6] = "baud_rate";   helpStrArray_485[7] = "baud_rate_str";
  helpStrArray_485[8] = "data_bits";   helpStrArray_485[9] = "data_bits_str";
  helpStrArray_485[10] = "stop_bit";   helpStrArray_485[11] = "stop_bit_str";
  helpStrArray_485[12] = "parity_bit"; helpStrArray_485[13] = "parity_bit_str";

	var g_showNetLost = parseInt(GV("<%supportnetlost%>"));
	var g_showVideoLost = parseInt(GV("<%supportvideolost%>"));
	var g_showSupportPir = parseInt(GV("<%supportpir%>"));
	
	
  var helpKeyArray_event = new Array(
  "setup_es_rightTxt_0",1,
  "setup_es_rightTxt_1",1,
  "setup_es_rightTxt_2",1,
  "setup_es_rightTxt_3",0,
  "setup_es_rightTxt_4",1,
  "setup_es_rightTxt_5",1,
  "setup_em_rightTxt_0",1,
  "setup_em_rightTxt_1",1,
  "setup_em_rightTxt_2",1,
  "setup_ee_rightTxt_0",1,
  "setup_ee_rightTxt_1",1,
  "setup_ee_rightTxt_3",1,
  "setup_ee_rightTxt_4",1,
  "setup_ee_rightTxt_5",g_supportFishEye!=1 && g_supgioin>0,
  "setup_ee_rightTxt_6",1,
  "setup_ee_rightTxt_net_lost",g_showNetLost,
  "setup_ee_rightTxt_tamper",g_supporttamper,
  "setup_ee_rightTxt_pir",g_showSupportPir,		//!g_showSupportPir && g_supportFishEye!=1,	
  "setup_ee_rightTxt_video_lost",g_showVideoLost,
  "setup_sound_detect_rightTxt_1",g_supportsound_detection==1,
  "setup_ee_rightTxt_7",1,
  "setup_ee_rightTxt_8",1,
  "setup_ee_rightTxt_10",g_supportFishEye!=1 && g_supgioout>0,
  "setup_er_rightTxt_0",1,
  "setup_er_rightTxt_1",1,
  "setup_er_rightTxt_2",1,
  "setup_er_rightTxt_3",1,
  "setup_er_rightTxt_4",1
  );

  var helpKeyArray_sdlist = new Array(
  "setup_sdlist_rightTxt_0",1,
  "setup_sdlist_rightTxt_1",1,
  "setup_sdlist_rightTxt_2",1
  );
  
  var helpKeyArray_focus = new Array(
  "setup_focus_rightTxt_1",1,
  "setup_focus_rightTxt_2",1
  );
  
  var helpKeyArray_preset = new Array(
  "setup_preset_rightTxt_1",1,
  "setup_preset_rightTxt_2",1,
  "setup_preset_rightTxt_3",1,
  "setup_preset_rightTxt_4",1,
  "setup_preset_rightTxt_5",1
  );

  var iostr = "<strong>"+GL("setup_digital_io_orange_t")+':</strong>'+GL("setup_digital_io_rightTxt_0");
  var helpKeyArray_digital_io = new Array(
  iostr,(g_supgioin>0 || g_supgioout>0 ),
  "setup_digital_io_rightTxt_1",g_suptvout
  );
  
  var helpKeyArray_rs485 = new Array(
  "setup_rs485_rightTxt_3",1,
  "setup_rs485_rightTxt_4",1,
  "setup_rs485_rightTxt_6",1,
  "setup_rs485_rightTxt_7",1,
  "setup_rs485_rightTxt_5",1
  );
  
  var helpKeyArray_icr = new Array(
  //"setup_icr_rightTxt_0",1,
  //(s_irled==0?"setup_icr_rightTxt_01":"setup_icr_rightTxt_0"),1,
  "setup_icr_rightTxt_1",1,
  "setup_icr_rightTxt_2",1,
  "setup_icr_rightTxt_3",1,
  "setup_icr_rightTxt_4",1,
  "setup_icr_rightTxt_a0",s_power,
   (g_supportirledcolor==1?"setup_icr_rightTxt_b0_color":"setup_icr_rightTxt_b0"),s_irled
  );
   
  var helpKeyArray_white_led = new Array(
  "setup_whiteled_rightTxt_1",1
  );
  
  var helpKeyArray_https = new Array(
  "setup_https_in_rightTxt_0",1,
  "setup_https_in_rightTxt_1",0,
  "setup_https_in_rightTxt_2",0,
  "setup_https_in_rightTxt_3",1
  );
  
  var helpKeyArray_AL = new Array(
  "setup_al_rightTxt_0",1,
  "setup_al_rightTxt_1",1
  );
  
   var helpKeyArray_snmp = new Array(
  "help_enable_snmpv1_v2",1,
  "help_enable_snmpv3",1
  
  );

//===========================================
// help_setup.htm
//===========================================  
  var helpStrArray_Management = new Array(
    "admin_password_str",1,
    "add_user_str",1,
    "delete_user_str",1,
    "camera_name_str",1,
    "enable_OSD_str",1,
    "label_str",1,
    "show_time_str",1,
	"setup_digital_io_rightTxt_2",g_suptLed,
	"setup_privacy_control_txt1",g_supportprivacycontrol,
	"setup_privacy_control_txt2",g_supportprivacycontrol,
	"setup_privacy_control_txt3",g_supportprivacycontrol
  );

  var helpStrArray_Backup = new Array(
    "backup_str",1,
    "restore_str",1,
    "restore_factory_defaults_str",1,
    "reboot_device_str",1,
	"help_csrf",(g_support_csrf_ref == 1)
  );

  var helpStrArray_Firmware = new Array(
    "firmware_information_str",1,
    "firmware_upgrade_str",1
  );

//===========================================
// help_status.htm
//===========================================  
  var helpStrArray_Info = new Array(
    "device_info_str",1
  );

  var helpStrArray_Log = new Array(
    "log1_str",1,
	"help_remotelog_txt0",g_supportremotelog,
	"help_remotelog_txt1",g_supportremotelog
  );


function GetHelpOrangeBodyHtml(keyArray)
{
  var o='';
  o+='<table width="750" border="0" cellpadding="0" cellspacing="0" ><tr><td>';
  for(i=0;i<keyArray.length;i+=2)
  {
    if(keyArray[(i+1)] == 1)
      o+='<li>'+GL(keyArray[i])+'</li>';
  }
  o+='</td></tr></table>';
  return o;
};

function GetHelpBlackBodyHtml(keyArray,linkPage)
{
  var o='';
  o+='<table border="0" width="425px" ><tr><td>';
  for(i=0;i<keyArray.length;i+=2)
  {
    if(keyArray[(i+1)] == 1)
      o+='<li><a target="_blank" href="'+linkPage+'#'+keyArray[i]+'" ><font color="#000000" >'+GL(keyArray[i])+'</font></a></li>';
  }
  o+='</td></tr></table>';
  return o;
};

function GetHelpPH()
{
  var o='';
  o+=GetHtmlHeaderNoBannerStr(null,"D-LINK CORPORATION | INTERNET CAMERA | HELP");
  o+='<table bordercolordark="#FFFFFF" width="60%" align="center" bgcolor="#ffffff" border="1" cellpadding="2" cellspacing="0" >';
  o+='<tr><td id="maincontent_container" valign="top"><div id="maincontent">';
  return o;
};

function GetHelpPB()
{
  var o='';
  o+='</div></td></tr></table><br>';
  o+='<div align="center">Copyright &copy; '+CopyrightYear+' D-Link Corporation.</div>';
  o+='<br></body>';
  return o;
};

function HelpWinOpenBlackText(helpStrArray)
{
  if(g_isIpcam)
    var g_str = GL("ipcam_str"); 
  else
    var g_str = GL("videoserver_str"); 
  var o='';
  o+='<table width="750" border="0" cellpadding="0" cellspacing="0" >';
  o+='<tr><td>';
  for(i=0;i<helpStrArray.length;i+=2)
  {
    if(helpStrArray[i+1])
    {
      o+=GL(helpStrArray[i],{1:g_str});
	  if(i<helpStrArray.length-2)
	    o+='<br><br>';
    }  
  }
  o+='</td></tr></table>';
  return o;
};

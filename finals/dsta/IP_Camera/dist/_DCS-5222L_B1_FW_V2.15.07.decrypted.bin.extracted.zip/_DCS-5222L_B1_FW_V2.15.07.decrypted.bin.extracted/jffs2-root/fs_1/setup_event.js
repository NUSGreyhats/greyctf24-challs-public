var g_supportFtpRetrying = parseInt(GV("<%supportretrying%>", 0));//2011.8.12 added for Ftp retrying

var g_servertype = 99;
function EventServerObj(serverStr)
{
  var serverInfo = serverStr.split(":"); // change  ; to :
  this.id = parseInt(serverInfo[0]);
  this.type = parseInt(serverInfo[1]);
  this.name = serverInfo[2];
  this.user = serverInfo[3];
  this.password = serverInfo[4];
  this.hostname = serverInfo[5];
  this.port = parseInt(serverInfo[6]);
  this.frommail = serverInfo[7];
  this.tomail = serverInfo[8];
  this.ftpfolder = serverInfo[9];
  this.ftpmode = parseInt(serverInfo[10]);
  this.workgroup = serverInfo[11];
  this.winsserver = serverInfo[12];
  this.emailenable = serverInfo[13];
 //--start 2011.8.12 added for FTP retrying
  if(g_supportFtpRetrying)
  {
	  this.ftpInterval = serverInfo[14];
	  this.ftpRetryInterval = serverInfo[15];
  }
  else if (g_supportftps)
  {
	//this.ftpoverssl = serverInfo[14];  //20140311 add
 	this.ftpencrypt = serverInfo[14];  //20140424 add  ���FTP���[�K�覡
 }
  else
  {
	  this.ftpInterval = 10;
	  this.ftpRetryInterval = 5;
 }
  //--end 2011.8.12
  
  this.GV = function()
  {
    var o = '';
    switch(this.type)
    {
      case 0://SMTP Server
        o = (this.id+':'+this.type+':'+this.name+':'+this.user+':'+this.password+':'+this.hostname+':'+this.port+':'+this.frommail+':'+this.tomail+':::::'+this.emailenable);
		if(g_supporthttpserver)
		  o += (':'); //20140311 add
        break;
      case 1://FTP Server
        o = this.id+':'+this.type+':'+this.name+':'+this.user+':'+this.password+':'+this.hostname+':'+this.port+':::'+this.ftpfolder+':'+this.ftpmode+':::'; 
		if(g_supportftps)
			o += (':'+this.ftpencrypt); //20140311 add
			//o += (':'+this.ftpoverssl); //20140311 add
        break;
      case 2://HTTP Server		
        o = (this.id+':'+this.type+':'+this.name+':'+this.user+':'+this.password+':'+this.hostname+':'+this.port+':::::::');
		if(g_supporthttpserver)
		  o += (':'); //20140311 add
        break;
      case 3://SAMBA Server
        o = (this.id+':'+this.type+':'+this.name+':'+this.user+':'+this.password+':'+this.hostname+'::::::'+this.workgroup+':'+this.winsserver+':');
		if(g_supporthttpserver)
		  o += (':'); //20140311 add
        break;
      case 4://SD Card
        o = (this.id+':'+this.type+':'+this.name+':::::::::::');
		if(g_supporthttpserver)
		  o += (':'); //20140311 add
        break;
      default:
        o = 'null';
        break;
    }
	//--start 2011.8.12 added for FTP retrying
	if(g_supportFtpRetrying)
		o += (':'+this.ftpInterval+':'+this.ftpRetryInterval);
	//--end 2011.8.12
    return o;
  };
  this.TS = function ()
  {
    var o = '';
    switch(this.type)
    {
      case 0:
        o = 'Email';
        break;
      case 1:
        o = 'Ftp';
        break;
      case 2:
        o = 'Http';
        break;
      case 3:
        o = 'Network storage';
        break;
      case 4:
        o = 'SD card';
        break;
      default:
        o = 'Unknow';
        break;
    }
    return o;
  };
};

//id;type;name;user;password;hostname;port;senderemail;toemail;ftpfolder;ftpmode;workgroup;winsserver;emailenable
var g_serverlistStr = GV("<%eventserverlist.all%>","0:0:S1:admin:9999:admin@gmail.com:25:user@yahoo.com:smtp@hotmail.com:::::0*1:1:S2:user:9999:user.com:21::::1::*null:0*3:3:S4:admin:9999:\\nas_name\\volumn1\\myfile::::::::0*4:4:S5:::::::::::0");
var l_servers = g_serverlistStr.split("*"); // change "," to *   willliamchen 2014.03.11
var g_servernamelist = "";
var g_serverindexlist = "";
var g_serveramount = 0;
var g_freeserver = (-1);

var g_httpserverlist="";

if(g_serverlistStr != "null" && g_serverlistStr != "")
{
  for(var i=0;i<l_servers.length;i++)
  {
    if(l_servers[i]=="" || l_servers[i]=="null")
    {
      g_freeserver = (g_freeserver==(-1)) ? i : g_freeserver;
      g_serverindexlist += (i==0) ? 0 : (';'+0);
      continue;
    }

    eval('var eventserver'+g_serveramount+' = new EventServerObj(l_servers['+i+']);');
    g_servernamelist += (g_serveramount==0) ? eval('eventserver'+g_serveramount+'.name') : (";"+eval('eventserver'+g_serveramount+'.name'));
    g_serverindexlist += (i==0) ? (g_serveramount+1) : (';'+(g_serveramount+1));
	if(g_supporthttpserver){
	 if(eval('eventserver'+g_serveramount+'.type')==2)
			g_httpserverlist +=eval('eventserver'+g_serveramount+'.name')+";";
    }
	g_serveramount++;
  }
}
else
{
  g_freeserver = 0;
}


function EventMediaObj(mediaStr)
{
  var mediaInfo = mediaStr.split(";");
  this.id = parseInt(mediaInfo[0]);
  this.type = parseInt(mediaInfo[1]);
  this.name = mediaInfo[2];
  this.source = parseInt(mediaInfo[3]);
  this.pre = parseInt(mediaInfo[4]);
  this.post = parseInt(mediaInfo[5]);
  this.datetime = parseInt(mediaInfo[6]);
  this.maxsize = parseInt(mediaInfo[7]);
  this.prefixname = mediaInfo[8];
  this.GV = function()
  {
    var o = '';
    switch(this.type)
    {
      case 0:
        o = (this.id+':'+this.type+':'+this.name+':'+this.source+':'+this.pre+':'+this.post+':'+this.datetime+'::'+this.prefixname);
        break;
      case 1:
        o = (this.id+':'+this.type+':'+this.name+':'+this.source+':'+this.pre+':'+this.post+'::'+this.maxsize+':'+this.prefixname);
        break;
      case 2:
        o = (this.id+':'+this.type+':'+this.name+'::::::');
        break;
      default:
        o = 'null';
        break;
    }
    return o;
  };
  this.TS = function ()
  {
    var o = '';
    switch(this.type)
    {
      case 0:
        o = 'Snapshot';
        break;
      case 1:
        o = 'Video clip';
        break;
      case 2:
        o = 'System log';
        break;
      default:
        o = 'Unknow';
        break;
    }
    return o;
  };
};

//id;type;name;source;pre;post;sdatetime;vmaxsize;prefizename
var g_medialistStr = GV("<%eventmedialist.all%>","0;0;M1;0;1;1;1;;event1,null,2;2;M3;;;;;;,null,4;1;M4-video;2;0;5;;500;event2");
var l_medias = g_medialistStr.split(",");
var g_medianamelist = "";
var g_mediaindexlist = "";
var g_mediaamount = 0;
var g_freemedia = (-1);
if(g_medialistStr != "null" && g_medialistStr != "")
{
  for(var i=0;i<l_medias.length;i++)
  {
    if(l_medias[i]=="" || l_medias[i]=="null")
    {
      g_freemedia = (g_freemedia==(-1)) ? i : g_freemedia;
      g_mediaindexlist += (i==0) ? 0 : (';'+0);
      continue;
    }

    eval('var eventmedia'+g_mediaamount+' = new EventMediaObj(l_medias['+i+']);');
    g_medianamelist += (g_mediaamount==0) ? eval('eventmedia'+g_mediaamount+'.name') : (";"+eval('eventmedia'+g_mediaamount+'.name'));
    g_mediaindexlist += (i==0) ? (g_mediaamount+1) : (';'+(g_mediaamount+1));
    g_mediaamount++;
  }
}
else
{
  g_freemedia = 0;
}


function EventObj(eventStr)
{ 
 // alert('eventStr ' + eventStr);
  var eventInfo = eventStr.split(";");
  var scheduleInfo = parseInt(eventInfo[7],16); //sun,mon....
  var rangeInfo = eventInfo[9]; // hh:mm:ss...
  
  // media area//
   if (g_supportZbc==1 || g_supgioout==0){
   	  var serverInfo = parseInt(eventInfo[10],16); //ctrl_checker
	  var smediaInfo = eventInfo[11];
   }
   else if(g_supportwhitelightled==1) { 
	  var serverInfo = parseInt(eventInfo[12],16);
	  var smediaInfo = eventInfo[13];
  }
   else{ 
	  var serverInfo = parseInt(eventInfo[12],16);
	  var smediaInfo = eventInfo[13];
  }
  
//start--2010.10.15 added
  if(g_isSupportVisca==1)
		var gioInInfo = parseInt(eventInfo[14],16);
//end--2010.10.15

  this.id = parseInt(eventInfo[0]);
  this.enable = parseInt(eventInfo[1]);
  this.SS = function()
  {
    return ((this.enable==1) ? 'ON' : 'OFF');
  };
  this.priority = parseInt(eventInfo[2]);
  this.delay = eventInfo[3];
  this.trigger = parseInt(eventInfo[4]);
  this.tpara = eventInfo[5];
  this.name = eventInfo[6];
  this.sunday = ((scheduleInfo & 0x00000001) != 0) ? 1 : 0;
  this.monday = ((scheduleInfo & 0x00000002) != 0) ? 1 : 0;
  this.tuesday = ((scheduleInfo & 0x00000004) != 0) ? 1 : 0;
  this.wednesday = ((scheduleInfo & 0x00000008) != 0) ? 1 : 0;
  this.thursday = ((scheduleInfo & 0x00000010) != 0) ? 1 : 0;
  this.friday = ((scheduleInfo & 0x00000020) != 0) ? 1 : 0;
  this.saturday = ((scheduleInfo & 0x00000040) != 0) ? 1 : 0;
  this.smode = parseInt(eventInfo[8]);
  this.shour = parseInt(rangeInfo.substr(0,2),10);
  this.sminute = parseInt(rangeInfo.substr(2,2),10);
  this.ehour = parseInt(rangeInfo.substr(6,2),10);
  this.eminute = parseInt(rangeInfo.substr(8,2),10);
  this.RS = function()
  {
    return (FixNum(this.shour,2)+':'+FixNum(this.sminute,2)+'~'+ FixNum(this.ehour,2)+':'+FixNum(this.eminute,2));
  };
  
  if(g_supportZbc !=1 && g_supgioout>0){
	  this.gio = parseInt(eventInfo[10]);
	  this.gduration = eventInfo[11];
  }
  
  //2013.04.22
  if(g_supportwhitelightled==1){  
	  this.whiteledcheck=parseInt(eventInfo[14]);
	  this.whiteledactiveMode=parseInt(eventInfo[15]);
	  this.whitelightActive=parseInt(eventInfo[16]);
	  this.whitelightInActive=eventInfo[17]; 
	  this.whiteledduration=parseInt(eventInfo[18]);	  
  }	
//end
  
  //alert('smediaInfo ' + smediaInfo );
  this.server0 = ((serverInfo & 0x00000001) != 0) ? 1 : 0;
  var smedia0Info = parseInt(smediaInfo.substr(4,1),16);
  this.smedia0 = (smedia0Info == 0xf) ? 0 : (smedia0Info+1);
  this.server1 = ((serverInfo & 0x00000002) != 0) ? 1 : 0;
  var smedia1Info = parseInt(smediaInfo.substr(3,1),16);
  this.smedia1 = (smedia1Info == 0xf) ? 0 : (smedia1Info+1);
  this.server2 = ((serverInfo & 0x00000004) != 0) ? 1 : 0;
  var smedia2Info = parseInt(smediaInfo.substr(2,1),16);
  this.smedia2 = (smedia2Info == 0xf) ? 0 : (smedia2Info+1);
  this.server3 = ((serverInfo & 0x00000008) != 0) ? 1 : 0;
  var smedia3Info = parseInt(smediaInfo.substr(1,1),16);
  this.smedia3 = (smedia3Info == 0xf) ? 0 : (smedia3Info+1);
  this.server4 = ((serverInfo & 0x00000010) != 0) ? 1 : 0;
  var smedia4Info = parseInt(smediaInfo.substr(0,1),16);
  this.smedia4 = (smedia4Info == 0xf) ? 0 : (smedia4Info+1);
//start--2010.10.15 added for visca
  if(g_isSupportVisca==1){
	this.GioIn1 = (gioInInfo & 0x1) >0 ? 1 : 0;
	this.GioIn2 = (gioInInfo & 0x2) >0 ? 1 : 0;
	this.GioIn3 = (gioInInfo & 0x4) >0 ? 1 : 0;
	this.GioIn4 = (gioInInfo & 0x8) >0 ? 1 : 0;
	this.GioIn5 = (gioInInfo & 0x10)>0 ? 1 : 0;
	this.GioIn6 = (gioInInfo & 0x20)>0 ? 1 : 0;
	this.GioIn7 = (gioInInfo & 0x40)>0 ? 1 : 0;
	this.GioIn8 = (gioInInfo & 0x80)>0 ? 1 : 0;
    this.PtzEn = parseInt(eventInfo[15]);
    this.PtzMode = parseInt(eventInfo[16]);
    this.PtzModeArg = parseInt(eventInfo[17]);
  }    
//end--2010.10.15
// 2013.02.23 for zbc
  if (g_supportZbc==1)
  {
	this.PtzEn = parseInt(eventInfo[12]);
	this.PtzMode = parseInt(eventInfo[13]);
	this.PtzModeArg = parseInt(eventInfo[14]);

  }
    //2014.03.13
  if(g_supporthttpserver==1) { 
	  this.httpserverenable = parseInt(eventInfo[14]);
	  this.httpserverindex = eventInfo[15];
  }

// end 

  this.GV = function()
  {
  
    var o='';
    o+=this.id+':'+this.enable+':'+this.priority+':'+this.delay+':'+this.trigger+':';
   
    o+=this.tpara;
    o+=':'+this.name;

    var scheduleValue = (this.sunday*0x00000001)+(this.monday*0x00000002)+(this.tuesday*0x00000004)+(this.wednesday*0x00000008)+(this.thursday*0x00000010)+(this.friday*0x00000020)+(this.saturday*0x00000040);
    o+=':'+FixNum(scheduleValue.toString(16),2,'0')+':'+this.smode+':';
    //if(this.smode == 1)
      o+=FixNum(this.shour,2)+FixNum(this.sminute,2)+"00"+FixNum(this.ehour,2)+FixNum(this.eminute,2)+"00";
	  
	if (g_supportZbc!=1 && g_supgioout>0)  
		o+=':'+this.gio+':'+this.gduration;	
	
    var serverValue = (this.server0*0x00000001)+(this.server1*0x00000002)+(this.server2*0x00000004)+(this.server3*0x00000008)+(this.server4*0x00000010);
	// server value
	o+=':'+FixNum(serverValue.toString(16),2,'0');
	//media value
    o+=':'+((this.smedia4==0)?'f':(this.smedia4-1))+((this.smedia3==0)?'f':(this.smedia3-1))+((this.smedia2==0)?'f':(this.smedia2-1))+((this.smedia1==0)?'f':(this.smedia1-1))+((this.smedia0==0)?'f':(this.smedia0-1));
//	alert ('med '+((this.smedia4==0)?'f':(this.smedia4-1))+((this.smedia3==0)?'f':(this.smedia3-1))+((this.smedia2==0)?'f':(this.smedia2-1))+((this.smedia1==0)?'f':(this.smedia1-1))+((this.smedia0==0)?'f':(this.smedia0-1)));
	
  //start--2010.10.15 added for visca
    if(g_isSupportVisca==1){
        var gioInValue = (this.GioIn1*0x1)+(this.GioIn2*0x2)+(this.GioIn3*0x4)+(this.GioIn4*0x8)+(this.GioIn5*0x10)+(this.GioIn6*0x20)+(this.GioIn7*0x40)+(this.GioIn8*0x80);
        o+=':'+FixNum(gioInValue.toString(16),4,'0');
    	o+= ':'+this.PtzEn+':'+this.PtzMode+':'+this.PtzModeArg;
    }
  //end--2010.10.15  
 //   o+=":0000";
   
   // 2013.02.23 for zbc
	if (g_supportZbc==1)
	{
		o+= ':'+this.PtzEn+':'+this.PtzMode+':'+this.PtzModeArg;
	} //end    
	
	//2013.04.22 whiteled
   if(g_supportwhitelightled==1)	
   {
	  o+= ':'+ this.whiteledcheck +':' + this.whiteledactiveMode +':' + this.whitelightActive +':' + this.whitelightInActive + ':' + this.whiteledduration;
   } //end   
   //20140313 add
   if(g_supporthttpserver==1) {
	o+=':'+this.httpserverenable+':'+this.httpserverindex;
   }
    return o;
  };

  this.TS = function ()
  {
    var o = '';
    switch(this.trigger)
    {
      case 0:
        o = 'Motion';
        break;
      case 1:
        o = 'Periodic';
        break;
      case 2:
        o = 'Digital input';
        break;
      case 3:
        o = 'System boot';
        break;
	  case 4:
        o = 'Network lost';
        break;
      case 5:
        o = 'Video lost';
        break;
//--start 2011.6.21 added
	  case 6:
		o = 'PIR';
		break;
//--end 2011.6.21
//--start 2013.08.13 added
	  case 7:
		o = 'Tamper Detection';
		break;
//--end 2013.6.20
//--start 2013.10.03 added
	  case 8:
		o = 'Sound Detection';
		break;
//--end 2013.8.13
      default:
        o = 'Unknow';
        break;
    }
    return o;
  };
};

//id;enable;priority;delay;trigger;trigger-para;name;schedule-day;schedule-mode;schedule-range;gioenable;gio-duration;active;active-media
var g_viscaevent = "";
var g_zbcevent="";
var g_whiteledevent="";
var g_serverhttpevent = "";

if(g_isSupportVisca==1)
	g_viscaevent = ";0000;0;0;1";
else if(g_supportZbc==1)
	g_zbcevent = ";0;0;1";
else if(g_supportwhitelightled==1)	 
	g_whiteledevent=";0;0;-60;0;3";	
else if(g_supporthttpserver==1)	 //20140313 add
	g_serverhttpevent=";0;0";	

var g_eventlistStr = GV("<%eventlist.all%>","null,1;1;0;10;1;2;E2;7f;0;000000235900;1;1;03;fff24"+g_viscaevent+",2;1;0;0;2;1;E3;77;1;080000203000;0;0;0b;f4f20"+g_viscaevent);
var l_events = g_eventlistStr.split(",");
var g_eventnamelist = "";
var g_eventamount = 0;
var g_freeevent = (-1);
//--2011.2.8 added
var g_maxserver = GV("<%maxeventserver%>",5);
var g_maxmedia = GV("<%maxeventmedia%>",5);
var g_maxevent = GV("<%maxeventnumber%>",3);
var g_maxrecording = GV("<%maxrecording%>",2);
//--2011.2.8
if(g_eventlistStr != "null" && g_eventlistStr != "")
{  
  for(var i=0;i<l_events.length;i++)
  {
    if(l_events[i]=="" || l_events[i]=="null")
    {
      g_freeevent = (g_freeevent==(-1)) ? i : g_freeevent;
      continue;
    }

    eval('var eventobject'+g_eventamount+' = new EventObj(l_events['+i+']);');
    g_eventnamelist += (g_eventamount==0) ? eval('eventobject'+g_eventamount+'.name') : (";"+eval('eventobject'+g_eventamount+'.name'));
    g_eventamount++;
  }
}
else
{
  g_freeevent = 0;
}


var g_supLongRecord = GV("<%supportlongrecord%>",0);
function EventRecordingObj(recordingStr)
{
  var recordingInfo = recordingStr.split(";");
  var scheduleInfo = parseInt(recordingInfo[5],16);
  var rangeInfo = recordingInfo[7];
  this.id = parseInt(recordingInfo[0]);
  this.enable = parseInt(recordingInfo[1]);
  this.SS = function()
  {
		return ((this.enable==1) ? 'ON' : 'OFF');
  };
  this.priority = parseInt(recordingInfo[2]);
  this.source = parseInt(recordingInfo[3]);
  this.name = recordingInfo[4];
  this.sunday = ((scheduleInfo & 0x00000001) != 0) ? 1 : 0;
  this.monday = ((scheduleInfo & 0x00000002) != 0) ? 1 : 0;
  this.tuesday = ((scheduleInfo & 0x00000004) != 0) ? 1 : 0;
  this.wednesday = ((scheduleInfo & 0x00000008) != 0) ? 1 : 0;
  this.thursday = ((scheduleInfo & 0x00000010) != 0) ? 1 : 0;
  this.friday = ((scheduleInfo & 0x00000020) != 0) ? 1 : 0;
  this.saturday = ((scheduleInfo & 0x00000040) != 0) ? 1 : 0;
  this.smode = parseInt(recordingInfo[6]);
  this.shour = parseInt(rangeInfo.substr(0,2),10);
  this.sminute = parseInt(rangeInfo.substr(2,2),10);
  this.ehour = parseInt(rangeInfo.substr(6,2),10);
  this.eminute = parseInt(rangeInfo.substr(8,2),10);
  this.RS = function()
  {
		return (FixNum(this.shour,2)+':'+FixNum(this.sminute,2)+'~'+ FixNum(this.ehour,2)+':'+FixNum(this.eminute,2));
  };
  //alert( parseInt(recordingInfo[8],16) );
  var destInfo = parseInt(recordingInfo[8],16);
  
  this.destserver = (destInfo == 0xf) ? 0 : (destInfo+1);
  this.maxspace = recordingInfo[9];
  this.eachsize = recordingInfo[10];//the file-size or time-range.
  this.prefixname = recordingInfo[11];
//--start 2011.11.9 added, if unitType=0 then eachsize is file-size else time-range.
  if(g_supLongRecord==1)
	this.unitType = recordingInfo[12];
  else
	this.unitType = 0;
//--end 2011.11.9


  this.GV = function()
  {
    var o='';
    o+=this.id+':'+this.enable+':'+this.priority+':'+this.source+':'+this.name;

    var scheduleValue = (this.sunday*0x00000001)+(this.monday*0x00000002)+(this.tuesday*0x00000004)+(this.wednesday*0x00000008)+(this.thursday*0x00000010)+(this.friday*0x00000020)+(this.saturday*0x00000040);
    o+=':'+FixNum(scheduleValue.toString(16),2,'0')+':'+this.smode+':';
    //if(this.smode == 1)
      o+=FixNum(this.shour,2)+FixNum(this.sminute,2)+"00"+FixNum(this.ehour,2)+FixNum(this.eminute,2)+"00";

    o+=':'+((this.destserver==0)?'f':(this.destserver))+':'+this.maxspace+':'+this.eachsize+':'+this.prefixname;
//--start 2011.11.9 added, if unitType=0 then eachsize is file-size else time-range.
	if(g_supLongRecord==1)
		o+=':'+this.unitType;
//--end 2011.11.9
    return o;
  };
};

var g_utstr = "";//unit type string.
if(g_supLongRecord==1)
	g_utstr = ";0";
//id;enable;priority;source;name;schedule-day;schedule-mode;schedule-range;dest-server;max-space;each-size;prefix-name;unit-type
var g_recordinglistStr = GV("<%eventrecordinglist.all%>","0;1;0;0;R1;7f;0;000000235900;4;1000;200;event1"+g_utstr+",null,2;0;1;1;R3;2a;1;105900130100;1;2000;300;record3"+g_utstr);
var l_recordings = g_recordinglistStr.split(",");
var g_recordingnamelist = "";
var g_recordingamount = 0;
var g_freerecording = (-1);
if(g_recordinglistStr != "null" && g_recordinglistStr != "")
{
  for(var i=0;i<l_recordings.length;i++)
  {
    if(l_recordings[i]=="" || l_recordings[i]=="null")
    {
      g_freerecording = (g_freerecording==(-1)) ? i : g_freerecording;
      continue;
    }

    eval('var eventrecording'+g_recordingamount+' = new EventRecordingObj(l_recordings['+i+']);');
    g_recordingnamelist += (g_recordingamount==0) ? eval('eventrecording'+g_recordingamount+'.name') : (";"+eval('eventrecording'+g_recordingamount+'.name'));
    g_recordingamount++;
  }
}
else
{
  g_freerecording = 0;
}

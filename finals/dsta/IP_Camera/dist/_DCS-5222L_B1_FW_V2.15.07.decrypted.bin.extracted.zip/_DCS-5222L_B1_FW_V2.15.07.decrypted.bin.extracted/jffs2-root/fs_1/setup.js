var MENU_ITEM_SETUP = new Array(
  "setup_wizard","setup_wizard.htm",1,
  "setup_network","setup_network.htm",1,
  "setup_wifi","setup_wifi_2.htm",g_supportWifi,
  "setup_dynamic","setup_dynamic.htm",1,
  "setup_image","setup_image.htm",1,
  ((g_isSupportAudio == 1 || g_isSupportTwoWayAudio == 1) ?"setup_audio_video" : "sys_video"),( (g_supportnvrbased ==1)  ? "setup_audio_video_nvrbased.htm" : "setup_audio_video.htm"),1,
  "setup_auto_focus_t","setup_image_focus.htm",g_isSupportAF && (g_isSupportVisca==0),
  "setup_auto_perset_t","setup_image_preset.htm",(g_isSupportEPTZ && (g_isSupportVisca==0) && (g_supportZbc==0) && (g_supportFishEye==0 || g_supportfish_v2 == 0)),
//--start 2012.11.30 add for fisheye
  "setup_auto_perset_t","setup_image_preset_fisheye.htm",(g_supportFishEye || g_supportfish_v2),
//--end 2012.11.30
  "setup_ptzsetup","setup_viscasetup.htm",g_isSupportVisca==1,
  "setup_ptz_preset","setup_visca_sequence.htm",g_isSupportVisca==1,
//--start 2012.11.22 add for zbc speed dome
  "setup_ptzsetup","setup_zbcsetup.htm",g_supportZbc==1,
  "setup_ptz_preset","setup_zbc_sequence.htm",g_supportZbc==1,
//--end 2012.11.22

  "setup_ptzsetup","setup_ptsetup.htm",g_support_real_ptz==1,
  "setup_motion","setup_motion.htm",1,
  "setup_tamper","setup_tamper_detection.htm",g_supporttamper==1,
  "setup_sound_detection","setup_sound_detection.htm",g_supportsound_detection==1,
  "setup_time_ady","setup_time_ady.htm",1,
  "setup_recording","setup_recording.htm",0,
  "setup_snapshot","setup_snapshot.htm",0,
  //"setup_rs485","setup_rs485.htm",0,
  "setup_event","setup_event.htm",1,
  //"setup_sdlist","sdlist.htm",1,
  "setup_sdlist",(g_supportnvrbased==1? "cgi-bin/sdoperate.cgi?list=&path=/":"cgi-bin/sdlist.cgi"),(g_supportsdhide==0) || (parseInt(GV("<%sdinsert%>",0))==1 && parseInt(GV("<%sdformat%>",1))==1), 
  "checkout","checkout.htm",2
);
//index of MENU_ITEM_SETUP
var ISETUP_WIZARD = 0;
var ISETUP_NETWORK = 1;
var ISETUP_WIFI = 2;
var ISETUP_DYNAMIC = 3;
var ISETUP_IMAGE = 4;
var ISETUP_AUDIO_VIDEO = 5;
var ISETUP_FOCUS = 6;
var ISETUP_PRESET = 7;
var ISETUP_PRESET_FISHEYE = 8;	//2012.11.30 ADD FOR FISHEYE
var ISETUP_VISCA_SETUP = 9;
var ISETUP_VISCA_SEQUENCE = 10;
//--start 2012.11.22 add for zbc speed dome
var ISETUP_ZBC_SETUP = 11;
var ISETUP_ZBC_SEQUENCE = 12;
//--end 2012.11.22
var ISETUP_HISI_SETUP = 13;
var ISETUP_MOTION = 14;
var ISETUP_TAMPER_DETECTION = 15;
var ISETUP_SOUND_DETECTION = 16;
var ISETUP_TIMEDAY = 17;
var ISETUP_RECORDING = 18;
var ISETUP_SNAPSHOT = 19;
var ISETUP_EVENT = 20;
var ISETUP_SDLIST = 21;


var MENU_ITEM_ADVANCED = new Array(
  "setup_digital_io","setup_digital_io.htm",(g_supgioin>0 || g_supgioout>0 || g_suptvout==1 ), // g_suptLed==1
  "setup_digital_in","setup_digital_in.htm",0,
  "setup_rs485","setup_rs485.htm",g_isSupportRS485 && (g_isSupportVisca==0),
  (s_irled==0?"setup_icr":(g_supportirledcolor==1?"setup_icr_ir_color":"setup_icr_ir")),"setup_icr.htm", (g_s_daynight || s_irled),
  "setup_white_light_led","setup_white_light_led.htm",g_supportwhitelightled,
  "setup_https","setup_https.htm",1,
  //"setup_qos","setup_qos.htm",g_supportqos || g_supportcos,//2010.12.27 added for QoS/CoS
  "setup_ipfilter","setup_ipfilter.htm",0,
  "setup_access_list","setup_access_list.htm",1,
  "setup_snmp","setup_snmp.htm",g_isSupportsnmp,
  "setup_notification","setup_notification.htm",g_supporteventhttp==1,
  "checkout","checkout.htm",2
);
//index of MENU_ITEM_ADVANCED
var IADVAN_DIGI_IO = 0;
var IADVAN_DIGI_IN = 1;
var IADVAN_RS485 = 2;
var IADVAN_ICR = 3;
var IADVAN_WHITLIGHTELED=4;
var IADVAN_HTTPS = 5;
//var IADVAN_QOS = 6;
var IADVAN_IP_FILTER = 6;
var IADVAN_ACCESS_LIST = 7;
var IADVAN_SNMP = 8;
var IADVAN_NOTIFICATION = 9;


var oneDay = new Date(2000,0,2,0,0,0) - new Date(2000,0,1,0,0,0);
var oneDayLess = new Date(2000,0,1,23,59,59) - new Date(2000,0,1,0,0,0);

function ScheduleObj(id)
{
  this.id=id;
  this.status=0;
  this.day=0;
  this.sHour=0;
  this.sMin=0;
  this.sSec=0;
  this.eHour=0;
  this.eMin=0;
  this.eSec=0;
  this.showDay=0;
  this.GT_S = function ()
  {
    return new Date(2000,0,1,this.sHour,this.sMin,this.sSec);
  };
  this.GT_E = function ()
  {
    return new Date(2000,0,1,this.eHour,this.eMin,this.eSec);
  };
  this.GetDuration = function ()
  {
    //Fix:20070227_1 line:3
    if (this.status>0 && this.sHour == 0 && this.sMin == 0 && this.sSec == 0 && this.eHour == 0 && this.eMin == 0 && this.eSec == 0)
    {
      return (oneDay);
    }
    return (this.GT_E().getTime() - this.GT_S().getTime());
  };
  this.SV = function (data)
  {
    var res= false;
    if (data.length >= 15)
    {
      this.status=parseInt(data.substr(0,1),16);
      this.day=parseInt(data.substr(1,2),10);
      //showday 0:sunday, 1~6 ,mon to sat, 7: everyday
      this.showDay = this.day;
      if (this.day == 7) this.showDay = 0;
      if (this.day == 8) this.showDay = 7;
      this.sHour=parseInt(data.substr(3,2),10);
      this.sMin=parseInt(data.substr(5,2),10);
      this.sSec=parseInt(data.substr(7,2),10);
      //duration
      var tH=parseInt(data.substr(9,2),10);
      var tM=parseInt(data.substr(11,2),10);
      var tS=parseInt(data.substr(13,2),10);
      var tmpTime2 = new Date(2000,0,1,this.sHour+tH,this.sMin+tM,this.sSec+tS);
      var iniDate = new Date(2000,0,1,0,0,0);
      if ((tmpTime2 - iniDate) == oneDayLess)
      {
        tmpTime2 = iniDate;
      }
      this.eHour = tmpTime2.getHours();
      this.eMin = tmpTime2.getMinutes();
      this.eSec = tmpTime2.getSeconds();

      //alert("start:"+this.sHour+":"+this.sMin+":"+this.sSec+" End:"+this.eHour+":"+this.eMin+":"+this.eSec);
      res = true;
    }
    return res;
  };
  this.GV = function ()
  {
    var o='';
    o+=FixNum(this.id,2);
    o+=this.status.toString(16);
    this.day = this.showDay;
    if (this.showDay == 0) this.day = 7;
    if (this.showDay == 7) this.day = 8;
    o+=FixNum(this.day,2);
    o+=FixNum(this.sHour,2);
    o+=FixNum(this.sMin,2);
    o+=FixNum(this.sSec,2);
    var diffTime = this.GetDuration();
    //Fix:20070227_1 line:6 add if-else
    if (diffTime == oneDay)
    {
      o+="235959";
    }
    else
    {
      var dd = new Date(2000,0,1,0,0,0);
      var nn = new Date(dd.getTime()+diffTime);
      o+=FixNum(nn.getHours(),2);
      o+=FixNum(nn.getMinutes(),2);
      o+=FixNum(nn.getSeconds(),2);
    }

    return o;
  };
};


var fifoQueue = new Array(); 

var fish = {setcmd:{} };

if(g_supportfish_v2)
	fish.setcmd = {pan: "fisheyepanspeed=", tilt : "fisheyetiltspeed=", zoom : "fisheyezoomspeed="};
else
	fish.setcmd = {pan: "setfepanspeed=", tilt : "setfetiltspeed=", zoom : "setfezoomspeed="};

var fish_panspeed    = new Ctrl_SelectEx("fish_panspeed",g_fish_panspeedname,"<%panspeed%>",fish.setcmd.pan,"SaveFishValue('fishpanspeed')");
var fish_tiltspeed   = new Ctrl_SelectEx("fish_tiltspeed",g_fish_tiltspeedname,"<%tiltspeed%>",fish.setcmd.tilt,"SaveFishValue('fishtiltspeed')");
var fish_zoomspeed   = new Ctrl_SelectEx("fish_zoomspeed",g_fish_zoomspeedname,"<%zoomspeed%>",fish.setcmd.zoom,"SaveFishValue('fishzoomspeed')");

var fish_panoramicspeed  = new Ctrl_SelectEx("fish_panoramicspeed",g_fish_panoramicspeedname,"<%panoramicspeed%>","setfepanoramicspeed=","SaveFishValue('fish_panoramicspeed')");
var fish_rotatespeed   = new Ctrl_SelectEx("fish_rotatespeed",g_fish_rotatespeedname,"<%rotatespeed%>","setferotatespeed=","SaveFishValue('fish_rotatespeed')");
var fisheyepresetlistname= new Ctrl_SelectEx("fisheyepresetlistname",g_fisheyepresetlistname,0,"",(g_supportfish_v2 ? "ChangePresetSelect()":""));  
var fisheyepresetlistname1= new Ctrl_SelectEx("fisheyepresetlistname1",g_fisheyepresetlistname,0,"","GoToFish()");
var fisheyepresetlistname2= new Ctrl_SelectEx("fisheyepresetlistname2",g_fisheyepresetlistname);  //for preset sequence
//end
var g_fisheyeusrdefhome=parseInt(GV("<%fisheyeusrdefhome%>",0)); //0=manual, 1=auto


var panspeed     = new Ctrl_SelectNum("panspeed",0,0x40,1,0x1A);
var tiltespeed   = new Ctrl_SelectNum("tiltespeed",0,0x40,1,0x1A);
mpMode=GetCookieInt("MP_MODE",1);
UpdateGSize(mpMode);
//--start 2012.11.22 added for zbc speed dome
if(g_supportZbc==1){
  var g_zbcfocusmode = parseInt(GV("<%zbcfocusmode%>",0)); //0=manual, 4=auto
  var zbcpresetlistname = GV("<%zbcseqlistname%>","--Preset List--");
  var zbcpresetselect = new Ctrl_SelectEx("zbcpresetselect",zbcpresetlistname,null,null,"GoToZbcPreset()");
}
//--end 2012.11.22
//PTZ (visca)
if(g_isSupportVisca == 1){
  var eptzpresetlistname = GV("<%viscasequencelistname%>","--Preset List--");
  var g_focusmodeinq = parseInt(GV("<%focusmodeinq%>",0)); //0=manual, 1=auto
}else
if(mpMode == 1)
  var eptzpresetlistname = GV("<%eptzpresetlistname1.all%>","--Preset List--");
else if(mpMode == 2)
  var eptzpresetlistname = GV("<%eptzpresetlistname2.all%>","--Preset List--");
else if(mpMode == 3)
  var eptzpresetlistname = GV("<%eptzpresetlistname3.all%>","--Preset List--");

var presetselect = new Ctrl_SelectEx("presetselect",eptzpresetlistname,null,null,"GoToPreset()");

if (isNaN(g_h264Status))
{
  g_h264Status = 5;
};
function SavePTZSpeed()
{
  SendHttpPublic(c_iniUrl+"&eptzspeed="+ptzspeed.GV());
};
var ptzspeed    = new Ctrl_SelectNum("ptzspeed",1,10,1,"<%eptzspeed%>",null,"SavePTZSpeed()");
var profile     = new Ctrl_SelectNum("profile",1,3,1,"<%eptzstreamid%>",null,"ChangeProfile()");
var _ptzspeed = GV("<%eptzspeed%>",5);
if(g_isSupportVisca == 1)
{
  var l_defspeed = "1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16";
  var visca_panspeed    = new Ctrl_SelectEx("visca_panspeed",GV("<%panspeedname%>",l_defspeed),GV("<%panspeed%>",1),"","OnClickSpeed('panspeed')");
  var visca_tiltspeed    = new Ctrl_SelectEx("visca_tiltspeed",GV("<%tiltspeedname%>",l_defspeed),GV("<%tiltspeed%>",1),"","OnClickSpeed('tiltspeed')");
  var visca_ptzpanlist    = new Ctrl_SelectEx("visca_ptzpanlist",GV("<%autopanname%>","1;2;3;4"),0);
  var visca_ptzseqlist    = new Ctrl_SelectNum("visca_ptzseqlist",1,8,1,"1");
  var visca_ptzcruiselist    = new Ctrl_SelectEx("visca_ptzcruiselist",GV("<%cruisename%>","1;2;3;4;5;6;7;8"),"1");
}
//--start 2012.11.6
if(g_supportZbc==1){
  var l_defspeed = "1;2;3;4;5;6;7;8;9;10;11;12;13;14;15;16";
  var g_autopanlist=GV("<%zbcapnname%>","1");
  var zbc_panspeed    = new Ctrl_SelectEx("zbc_panspeed",GV("<%panspeedname%>",l_defspeed),GV("<%panspeed%>",1),"setzbcpanspeed=","OnClickZbcSpeed('panspeed')");
  var zbc_tiltspeed    = new Ctrl_SelectEx("zbc_tiltspeed",GV("<%tiltspeedname%>",l_defspeed),GV("<%tiltspeed%>",1),"setzbctiltspeed=","OnClickZbcSpeed('tiltspeed')");
  var zbc_zoomspeed    = new Ctrl_SelectEx("zbc_zoomspeed",GV("<%zoomspeedname%>",l_defspeed),GV("<%zoomspeed%>",1),"setzbczoomspeed=","OnClickZbcSpeed('zoomspeed')");
  var zbc_focusspeed    = new Ctrl_SelectEx("zbc_focusspeed",GV("<%focusspeedname%>",l_defspeed),GV("<%focusspeed%>",1),"setzbcfocusspeed=","OnClickZbcSpeed('focusspeed')");
  var zbc_ptzpanlist    = new Ctrl_SelectEx("zbc_ptzpanlist",g_autopanlist,1);
  var zbc_ptzseqlist    = new Ctrl_SelectNum("zbc_ptzseqlist",1,4,1,"1");
  //var zbc_ptzcruiselist    = new Ctrl_SelectEx("visca_ptzcruiselist",GV("<%cruisename%>","1;2;3;4;5;6;7;8"),"1");
}
//--end 2012.11.6


//--start 2013.06.10 Hisi

	var l_presetNameAll = GV("<%longcctvhomelistname%>","--Preset List--");	//page list string

	var autopanspeed=parseInt(GV("<%autopanspeed%>",1));
	var l_apn_speed = GV("<%autopanspeedname%>","1;1;1;50");
	
	var l_rotatespeed=GV("<%longcctvdwelltimename%>","0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15");
	var g_longcctvdwelltime=parseInt(GV("<%longcctvdwelltime%>",1));
	
	var g_longcctvmovemode=parseInt(GV("<%longcctvmovemode%>",0)); // 0: cont. 1: step
	
	if(g_longcctvmovemode==0 && g_support_longcctv_cont==1){
		var g_longpanspeedname=GV("<%contpanspeedname%>","0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15");
		var g_longpanspeed=parseInt(GV("<%contpanspeed%>",1));
		var g_longtiltspeedname=GV("<%conttiltspeedname%>","0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15");
		var g_longtiltspeed=parseInt(GV("<%conttiltspeed%>",1));	
	}
	else{
		var g_longpanspeedname=GV("<%steppanstepname%>","0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15");
		var g_longpanspeed=parseInt(GV("<%steppanstep%>",1));
		var g_longtiltspeedname=GV("<%steptiltstepname%>","0;1;2;3;4;5;6;7;8;9;10;11;12;13;14;15");
		var g_longtiltspeed=parseInt(GV("<%steptiltstep%>",1));	
	
	}
	var o = 'CTRLARY = {';
	o+= 'hisi_panspeed  : new Ctrl_SelectEx("hisi_panspeed",g_longpanspeedname,g_longpanspeed,"panspeed=","OnClickHisiSpeed(\'panspeed\')")';
	o+= ',hisi_tiltspeed   : new Ctrl_SelectEx("hisi_tiltspeed",g_longtiltspeedname,g_longtiltspeed,"tiltspeed=","OnClickHisiSpeed(\'tiltspeed\')")';
	o+= '};';
	eval(o);
	
	
     var hisi_presetselect = new Ctrl_SelectEx("hisi_presetselect",l_presetNameAll,"",null,"GoToHiSiPreset()");	
	 var hisi_autopanspeed = new  Ctrl_SelectEx("setautopanspeed",l_apn_speed,autopanspeed,"autopanspeed=","OnClickHisiSpeed('autospeed')");
	 var hisi_seqspeed   = new Ctrl_SelectEx("hisi_seqspeed",l_rotatespeed,g_longcctvdwelltime,"","OnClickHisiSpeed('dwelltimespeed')");


//--end 2013.06.10
/* 2013.10.02 get status for preset icon*/
var g_longcctvseqstatus=parseInt(GV("<%longcctvseqstatus%>",0));
var g_longcctvapnstatus=parseInt(GV("<%longcctvapnstatus%>",0));
/* end */



var ptzselectstr = '';
if(g_isSupportVisca == 1)
{
    g_PTZMode = 3;      // g_PTZMode = 3 for visca
    ptzselectstr = "VISCA";
}
else
if(g_isShowRs485 == 1 && g_isSupportEPTZ == 1)
{
    g_PTZMode = 0;//2;      // g_PTZMode = 2 for future
    ptzselectstr = "RS-485;EPTZ";
}
else
{
    if(g_isSupportEPTZ == 1){
        g_PTZMode = 1;
        ptzselectstr = "EPTZ";
    }else{
        g_PTZMode = 0;
        ptzselectstr = "RS-485";
    }
}

var disModeArr=fish_mode_list.split(";");    
var g_ptzselect = new Ctrl_SelectEx("g_ptzselect",ptzselectstr,0,null,"SetPTZMode()");

function SetPTZMode()
{
  if(g_ptzselect.GV() == 'RS-485')
  {
    g_PTZMode = 0;
    //alert("rs485");
  }
  else if(g_ptzselect.GV() == 'EPTZ')
  {
    g_PTZMode = 1;
    //alert("eptz");
  }
};

var imagePT = new Object();
/*
* if background is dark then bg = "dark"
* else if background is white then bg= "white" 
*/
function PTimageArray(bg){
  if(bg=="white")
    Ext = "white-";
  else
    Ext = "";
  
  if(g_isShowPtzCtrl || g_supportFishEye || g_supportfish_v2)  
  {
	//var imagePT = new Object( );
    imagePT["way_control_n"] = new Image(110, 110);
    imagePT["way_control_n"].src  = Ext+"way_control.jpg";

    imagePT["home_f"] = new Image(110, 110);
    imagePT["home_f"].src = Ext+"way_control_center_f.jpg";
    imagePT["home_p"] = new Image(110, 110);
    imagePT["home_p"].src = Ext+"way_control_center_p.jpg";

    imagePT["down_f"] = new Image(110, 110);
    imagePT["down_f"].src = Ext+"way_control_down_f.jpg";
    imagePT["down_p"] = new Image(110, 110);
    imagePT["down_p"].src = Ext+"way_control_down_p.jpg";

    imagePT["left_f"] = new Image(110, 110);
    imagePT["left_f"].src = Ext+"way_control_left_f.jpg";
    imagePT["left_p"] = new Image(110, 110);
    imagePT["left_p"].src = Ext+"way_control_left_p.jpg";

    imagePT["left_down_f"] = new Image(110, 110);
    imagePT["left_down_f"].src = Ext+"way_control_left_down_f.jpg";
    imagePT["left_down_p"] = new Image(110, 110);
    imagePT["left_down_p"].src = Ext+"way_control_left_down_p.jpg";

    imagePT["left_up_f"] = new Image(110, 110);
    imagePT["left_up_f"].src = Ext+"way_control_left_up_f.jpg";
    imagePT["left_up_p"] = new Image(110, 110);
    imagePT["left_up_p"].src = Ext+"way_control_left_up_p.jpg";

    imagePT["right_f"] = new Image(110, 110);
    imagePT["right_f"].src = Ext+"way_control_right_f.jpg";
    imagePT["right_p"] = new Image(110, 110);
    imagePT["right_p"].src = Ext+"way_control_right_p.jpg";

    imagePT["right_down_f"] = new Image(110, 110);
    imagePT["right_down_f"].src = Ext+"way_control_right_down_f.jpg";
    imagePT["right_down_p"] = new Image(110, 110);
    imagePT["right_down_p"].src = Ext+"way_control_right_down_p.jpg";

    imagePT["right_up_f"] = new Image(110, 110);
    imagePT["right_up_f"].src = Ext+"way_control_right_up_f.jpg";
    imagePT["right_up_p"] = new Image(110, 110);
    imagePT["right_up_p"].src = Ext+"way_control_right_up_p.jpg";
    
    imagePT["up_f"] = new Image(110, 110);
    imagePT["up_f"].src = Ext+"way_control_up_f.jpg";
    imagePT["up_p"] = new Image(110, 110);
    imagePT["up_p"].src = Ext+"way_control_up_p.jpg";

    imagePT["zoom_in_f"] = new Image(110, 110);
    imagePT["zoom_in_f"].src = Ext+"way_control_zoom_in_f.jpg";
    imagePT["zoom_in_p"] = new Image(110, 110);
    imagePT["zoom_in_p"].src = Ext+"way_control_zoom_in_p.jpg";

    imagePT["zoom_out_f"] = new Image(110, 110);
    imagePT["zoom_out_f"].src = Ext+"way_control_zoom_out_f.jpg";
    imagePT["zoom_out_p"] = new Image(110, 110);
    imagePT["zoom_out_p"].src = Ext+"way_control_zoom_out_p.jpg";
  }
}

/*
 * if background is dark then bg = "dark"
 * else if background is white then bg= "white" 
*/
function PtzCtrlMap(bg){
  PTimageArray(bg);

  var w='';
  w+='<p></p><p style="display: inline;" id="displayPT1" align="center">';
  w+='<img usemap="#MapMap" src="'+imagePT["way_control_n"].src+'" name="PTControl" width="110" align="center" border="0" height="110">';
  w+='<map id="MapMap" name="MapMap">';
  w+=GetAREA("left up","left up","pt_left_up","pt_out","left_up","left_up","left_up","0,36,14,15,35,1,35,20,28,25,24,30,20,36","poly"); 
  w+=GetAREA("up","up","pt_up","pt_out","up","up","up","35,-7,73,-11,74,20,66,17,56,16,44,17,35,20","poly");
  w+=GetAREA("right up","right up","pt_right_up","pt_out","right_up","right_up","right_up","74,1,94,14,108,36,90,36,85,30,80,24,73,20","poly");		    
  w+=GetAREA("left ","left ","pt_left","pt_out","left","left","left","22,73,0,73,0,36,20,36,17,44,16,52,17,60,18,68","poly");		
  w+=GetAREA("home ","home","pt_home","pt_out","home","home","home","55,55,15","circle");
  w+=GetAREA("right ","right","pt_right","pt_out","right","right","right","113,36,113,73,88,73,93,64,94,55,94,46,91,36","poly");
  w+=GetAREA("left down ","left down","pt_left_down","pt_out","left_down","left_down","left_down","21,73,0,73,15,96,36,108,36,88,30,83,25,78","poly");
  w+=GetAREA("down ","down","pt_down","pt_out","down","down","down","36,87,36,111,74,114,74,86,66,90,55,91,44,90","poly");
  w+=GetAREA("right down ","right down","pt_right_down","pt_out","right_down","right_down","right_down","74,86,74,108,95,94,110,73,88,73,86,78,79,83","poly");
  w+=GetAREA("zoom in ","zoom in","pt_zoom_in","pt_out"  ,"zoom_in"  ,"zoom_in","zoom_in"  ,"55,39,55,15,41,17,27,27,19,39,16,56,21,73,30,84,42,89,55,91,55,69,44,65,40,53,44,44","poly");
  w+=GetAREA("zoom out ","zoom out","pt_zoom_out","pt_out","zoom_out","zoom_out","zoom_out","55,16,70,19,84,27,91,37,94,50,92,65,87,78,74,86,65,91,55,91,55,70,63,66,68,59,68,51,64,43,55,40","poly");
  w+='<area href="#" coords="18,22" shape="poly">';
  w+='</map></p>';
  
  return w;
}
//------Fish
function FishCtrl()
{
    
	var w='';
	w+='<tr align="center"><td>'+PtzCtrlMap("dark")+'</td></tr>';
	w+='<tr><td>&nbsp;</td></tr>';	
	w+='<tr><td align="center">';   
		if(g_fisheyeautopan==1)
			w+='<a href="javascript:ClickPan()"><img id="img_pan" alt="'+GL("auto_pan")+'" title="'+GL("auto_pan")+'" src="/pan-on_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
		else
            w+='<a href="javascript:ClickPan()"><img id="img_pan" alt="'+GL("auto_pan")+'" title="'+GL("auto_pan")+'" src="/pan-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
			
			w+='<a href="javascript:ClickStop()"><img id="img_stop" alt="'+GL("stop")+'" title="'+GL("stop")+'" src="/stop-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
		if(g_fisheyesequence==1)	
			w+='<a href="javascript:ClickSequence()"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-on_n.gif" width="32" height="32" border="0"/></a>';
		else
			w+='<a href="javascript:ClickSequence()"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-off_n.gif" width="32" height="32" border="0"/></a>';
		
	w+='</td></tr>'; 
	w+='<tr><td>&nbsp;</td></tr>';	
	w+='<tr><td><font color="#ffffff">'+GL("fish_display_mode")+'</font></td></tr>';			
	w+='<tr><td align="left">'+ShowDisplayMode()+'</td></tr>';	
 	w+='<tr><td>&nbsp;</td></tr>';	
	//20140515
	w+='<tr><td><div style="width:75px;margin:0;padding:0;float:left;color:white">'+((g_langName=="de_de")?CutString(GL("ptz_panspeed"),13):GL("ptz_panspeed"))+'</div>'+fish_panspeed.html+'</td></tr>';
	w+='<tr><td><div style="width:75px;margin:0;padding:0;float:left;color:white">'+((g_langName=="de_de")?CutString(GL("ptz_tiltespeed"),13):GL("ptz_tiltespeed"))+'</div>'+fish_tiltspeed.html+'</td></tr>';
	w+='<tr><td><div style="width:75px;margin:0;padding:0;float:left;color:white">'+((g_langName=="de_de")?CutString(GL("ptz_zoomspeed"),13):GL("ptz_zoomspeed"))+'</div>'+fish_zoomspeed.html+'</td></tr>';
	w+='<tr><td><div style="width:75px;margin:0;padding:0;float:left;color:white">'+((g_langName=="de_de")?CutString(GL("ptz_autopanspeed"),13):GL("ptz_autopanspeed"))+'</div>'+fish_panoramicspeed.html+'</td></tr>';
	w+='<tr><td><div style="width:75px;margin:0;padding:0;float:left;color:white">'+((g_langName=="de_de")?CutString(GL("ptz_sequencespeed"),13):GL("ptz_sequencespeed"))+'</div>'+fish_rotatespeed.html+'</td></tr>';		


	//2013.03.29 add williamchen
	w+='<tr><td>&nbsp;</td></tr>';	
	w+='<tr><td><div style="width:100px;margin:0;padding:0;float:left;color:white">'+GL("ptz_home_define")+'</div></td></tr>';
	w+='<tr><td>' + GetButtonHtml("fisheye_setHome", GL("ptz_sethome"), "SendSetHome()",90) + '</td></tr>';
	
	w+='<tr><td>&nbsp;</td></tr>';
  return w;
}

function SendSetHome()
{
	if(g_fisheyeusrdefhome==0)
		SendHttpPublic("/cgi-bin/fisheye.cgi?userdefine=1",false,sendUserdefine);
	else
		SendHttpPublic("/cgi-bin/fisheye.cgi?userdefine=0",false,sendUserdefine);
}
function sendUserdefine()
{
	if (g_SubmitHttpPublic.readyState == 4)
	{
		if (g_SubmitHttpPublic.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			SendHttpPublic("/vb.htm?paratest=fisheyeusrdefhome",false,changeHomedefine);	
			
		}
	}
	
}

function changeHomedefine()
{
	var list='';

	if (g_SubmitHttpPublic.readyState == 4)
	{
		if (g_SubmitHttpPublic.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			list = g_SubmitHttpPublic.responseText;
			list = list.substring(0,list.length-1);
			list = list.split("=");
			
			if(parseInt(list[1])==0)
				{
					GE("fisheye_setHome").style.backgroundColor="#FFFFFF";		
					g_fisheyeusrdefhome=0;
				}
			else
				{
					GE("fisheye_setHome").style.backgroundColor="#FFAA00";		
					g_fisheyeusrdefhome=1;
					
				}
		}
	}
}

function SaveFishValue(str)
{  
  switch (str)
  {
    case 'fishpanspeed' :	
		if(g_supportfish_v2)
			SendHttpPublic("/cgi-bin/fisheyespeed.cgi?"+fish_panspeed.setcmd+fish_panspeed.GV());
		else
			SendHttpPublic("vb.htm?"+fish_panspeed.setcmd+fish_panspeed.GV());
		break;
	case 'fishtiltspeed' :
		if(g_supportfish_v2)
			SendHttpPublic("/cgi-bin/fisheyespeed.cgi?"+fish_tiltspeed.setcmd+fish_tiltspeed.GV());
		else
			SendHttpPublic("vb.htm?"+fish_tiltspeed.setcmd+fish_tiltspeed.GV());
		break;
	case 'fishzoomspeed' :
		if(g_supportfish_v2)
			SendHttpPublic("/cgi-bin/fisheyespeed.cgi?"+fish_zoomspeed.setcmd+fish_zoomspeed.GV());
		else
			SendHttpPublic("vb.htm?"+fish_zoomspeed.setcmd+fish_zoomspeed.GV());
		break;
	case 'fish_panoramicspeed' :
		SendHttpPublic("vb.htm?"+fish_panoramicspeed.setcmd+fish_panoramicspeed.GV());
		break;
	case 'fish_rotatespeed' :
		SendHttpPublic("vb.htm?"+fish_rotatespeed.setcmd+fish_rotatespeed.GV());
		break;	
  }
  
};

function fishMode_title(txt){
	var _value;
	switch(txt)
	{
		case "1O":
			_value = "Fisheye View";
			break;
		case "1R":
			_value = "Normal View";
			break;
		case "1P2R":
			_value = "Multi-View with Panorama";
			break;
		case "2P":
			_value = "Panoramic View";
			break;
		case "1O3R":
			_value = "Mixed View";
			break;
		case "4R":
			_value = "Multi-View";
			break;	
		default:
			_value = "Panoramic View";
			break;	
	}
	
	return _value;
}

function ShowDisplayMode()
{
 var w=''; 
 
		for(var i=0;i<disModeArr.length;i++){
					 		 
			 if(i==3 || i==6)
			   w+='</td></tr><tr><td align="left">';
			   
			 if(disModeArr[i]==fish_mode){
       			 w+='<img id="mode_'+disModeArr[i]+'" src="'+disModeArr[i]+'-on.gif" width="32" height="32" onmousedown="sendDisplayMode(\''+disModeArr[i]+'\');" onmouseup="ChangeDisplayModePic(\''+disModeArr[i]+'\');" style="cursor:pointer;" alt="'+ fishMode_title(disModeArr[i]) +'">&nbsp;';			 
			 }
			 else
			     w+='<img id="mode_'+disModeArr[i]+'" src="'+disModeArr[i]+'-off.gif" width="32" height="32" onmousedown="sendDisplayMode(\''+disModeArr[i]+'\');" onmouseup="ChangeDisplayModePic(\''+disModeArr[i]+'\');" style="cursor:pointer;" alt="'+ fishMode_title(disModeArr[i]) +'">&nbsp;';			 
		}
		
return w;
}

function ChangeDisplayModePic(mode_name)
{ 
	fish_mode = mode_name;

	ChangeImg("img_pan","pan-off_n.gif");  //for fisheye	  
	ChangeImg("img_seq","seq-off_n.gif");  //for fisheye
		 
	for(var j=0;j<disModeArr.length;j++){
	
		if(disModeArr[j] == mode_name ){
		
			ChangeImg('mode_'+disModeArr[j],disModeArr[j]+'-on.gif')				
				
			
			if(disModeArr[j]=='1O' || disModeArr[j]=='2P')
				DisableObject("fisheyepresetlistname1",true);
			else
				DisableObject("fisheyepresetlistname1",false);
		}	
		else
			ChangeImg('mode_'+disModeArr[j],disModeArr[j]+'-off.gif')
	}
	
	
	 g_fisheyeautopan=0;
	 g_fisheyesequence=0;
		 
};


function sendDisplayMode(mode_name)
{
	clearTimeout(timerDisplayMode);
	if( timerDisplayMode != null)
		timerDisplayMode = null;
	
	SendHttpPublic("/cgi-bin/fisheye.cgi?displaymode=" + mode_name,false, reponseDisplayMode);	
	
}

function reponseDisplayMode()
{
	setTimeout(function(){ getDisplayMode(); }, 500);
}


//--End Fish

function PtzCtrl()
{
  var w='';
  w = '<tr align="center"><td>'+PtzCtrlMap("dark")+'</td></tr>';
  
  if(g_support_real_ptz==1 )
  {
	w+='<tr><td style="padding:0px">';
			w+='<table border="0">'; //
					w+='<tr><td colspan="2">&nbsp;</td></tr>';
					
				if(g_support_longcctv_cont){
					w+='<tr><td align="left"  colspan="2" height="35px" >';
				
						w+='<table style="margin:0px;padding:0px;border:0px solid;" cellpadding="3" cellspacing="1" ><tr>';
						w+='<td style="color:#ffffff;">'+ GL("mode");
						w+= '</td><td><a href="javascript:sendCont()"><img id="img_continue" alt="'+GL("cont")+'" title="'+GL("cont")+'" src="Continuous_off.gif" width="32" height="32" border="0"/></a>';
						w+='</td><td><a href="javascript:sendStep()"><img id="img_step" alt="'+GL("step")+'" title="'+GL("step")+'" src="step_off.gif" width="32" height="32" border="0"/></a>';
						w+='</tr></table>';

					w+='</td></tr>';				
				}
								
					w+='<tr><td align="center" colspan="2">';	  
	
						if(g_longcctvapnstatus)
							w+='<a href="javascript:ClickPan()"><img id="img_pan" alt="'+GL("auto_pan")+'" title="'+GL("auto_pan")+'" src="/pan-on_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
						else 
							w+='<a href="javascript:ClickPan()"><img id="img_pan" alt="'+GL("auto_pan")+'" title="'+GL("auto_pan")+'" src="/pan-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
						
						w+='<a href="javascript:ClickStop()"><img id="img_stop" alt="'+GL("stop")+'" title="'+GL("stop")+'" src="/stop-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
						
						if(g_longcctvseqstatus)
							w+='<a href="javascript:ClickSequence()"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-on_n.gif" width="32" height="32" border="0"/></a>';
						else 
//							w+='<a href="#" onMouseDown="javascript:ClickSequence()" onMouseUp="ChangeImg(\'img_seq\',\'seq-off_n.gif\')"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-off_n.gif" width="32" height="32" border="0"/></a>';
							w+='<a href="javascript:ClickSequence()"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-off_n.gif" width="32" height="32" border="0"/></a>';
					w+='</td></tr>';						
					w+='<tr><td colspan="2">&nbsp;</td></tr>';								
								
					w+='<tr><td id="gotopreset" colspan="2" style="color:#ffffff">'+GL("persetgoto")+'<br>'+hisi_presetselect.html+'</td></tr>';
					w+='<tr><td colspan="2">&nbsp;</td></tr>';
					
					w+='<tr><td valign="bottom" style="color:#ffffff"><div id="ptzpanSpeedtitle">'+(g_support_longcctv_cont?GL("ptz_panspeed") :GL("ptz_panstep"))+'</div></td><td>'+WH_DIV("hisi_panspeed","hisi_panspeedDiv")+'</td></tr>';
					w+='<tr><td valign="bottom" style="color:#ffffff"><div id="ptztiltSpeedtitle">'+ (g_support_longcctv_cont?GL("ptz_tiltespeed"):GL("ptz_tiltstep"))+'</div></td><td>'+WH_DIV("hisi_tiltspeed","hisi_tiltspeedDiv")+'</td></tr>';
					w+='<tr><td valign="bottom" style="color:#ffffff">'+GL("ptz_autopanspeed")+' </td><td>'+hisi_autopanspeed.html+'</td></tr>';
					w+='<tr><td valign="bottom" style="color:#ffffff">'+GL("input_preset_time")+' </td><td>'+hisi_seqspeed.html+'</td></tr>';
					w+='<tr><td colspan="2">&nbsp;</td></tr>';	
				
			w+='</table>';
		w+='</td></tr>';
  }
  
  
  
  
  if (g_isSupportVisca==1)
  {
    w+='<tr><td>&nbsp;</td></tr>';
    w+='<tr>';
   			w+='<td><a href="javascript:ClickAutoFocuse()"><img id="img_af" alt="'+GL("auto_focus")+'"src="/'+((g_focusmodeinq==1) ? 'v_af_on_n.gif':'v_af_off_n.gif')+'" width="38" height="20" border="0"/></a>';
   			w+='<font color="#ffffff">&nbsp;'+GL("mode")+'&nbsp;</font>';
   			w+='<a href="javascript:ClickManualFocuse()"><img id="img_mf" alt="'+GL("manual_focus")+'"src="/'+((g_focusmodeinq==0) ? 'v_mf_on_n.gif':'v_mf_off_n.gif')+'" width="38" height="20" border="0"/></a></td>';
   	w+='</tr><tr>';
		w+='<td><div id="mfctrl" style="display:'+( g_focusmodeinq==0 ? "block" : "none" )+';">';
    		w+='<img id="FocusNear" src="v_in_off_n.gif" width="38" height="20" onmouseup="ClickFocusStop();" onmousedown="ClickFocusNear();" style="cursor:pointer;">';
    		w+='<font color="#ffffff">&nbsp;'+GL("focus")+'&nbsp;</font>';
    		w+='<img id="FocusFar" src="v_out_off_n.gif" width="38" height="20" onmouseup="ClickFocusStop();" onmousedown="ClickFocusFar();" style="cursor:pointer;">';
		w+='</div></td>';
	w+='</tr>';
	
    w+='<tr><td>&nbsp;</td></tr>';
    w+='<tr><td>';
		w+='<table>';
				w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_panspeed")+' </font></td><td>'+visca_panspeed.html+'</td></tr>';
				w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_tiltespeed")+' </font></td><td>'+visca_tiltspeed.html+'</td></tr>';
				w+='<tr><td>&nbsp;</td></tr>';
			    w+='<tr><td><a href="javascript:ClickViscaPan()"><img id="img_pan" alt="'+GL("auto_pan")+'"src="/v_pan-off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+visca_ptzpanlist.html+'</td></tr>';
			    w+='<tr><td><a href="javascript:ClickViscaSequence()"><img id="img_seq" alt="'+GL("auto_sequence")+'"src="/v_seq-off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+visca_ptzseqlist.html+'</td></tr>';
			    w+='<tr><td><a href="javascript:ClickViscaCruise()"><img id="img_cruise" alt="'+GL("auto_cruise")+'"src="/v_cruise_off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+visca_ptzcruiselist.html+'</td></tr>';
		w+='</table>';
	w+='</td></tr>';
  }else{
//--start 2012.11.6 add for zbc speed dome
	  if (g_supportZbc==1)
	  {
		w+='<tr><td>&nbsp;</td></tr>';
		w+='<tr>';
				w+='<td><a href="javascript:ClickAutoFocuse()"><img id="img_af" alt="'+GL("auto_focus")+'"src="/'+((g_zbcfocusmode==4) ? 'v_af_on_n.gif':'v_af_off_n.gif')+'" width="38" height="20" border="0"/></a>';
				w+='<font color="#ffffff">&nbsp;'+GL("mode")+'&nbsp;</font>';
				w+='<a href="javascript:ClickManualFocuse()"><img id="img_mf" alt="'+GL("manual_focus")+'"src="/'+((g_zbcfocusmode==0) ? 'v_mf_on_n.gif':'v_mf_off_n.gif')+'" width="38" height="20" border="0"/></a></td>';
		w+='</tr><tr>';
			w+='<td><div id="mfctrl" style="display:'+( g_zbcfocusmode==0 ? "block" : "none" )+';">';
				w+='<img id="FocusNear" src="v_in_off_n.gif" width="38" height="20" onmouseup="ClickFocusStop();" onmousedown="ClickFocusNear();" style="cursor:pointer;">';
				w+='<font color="#ffffff">&nbsp;'+GL("focus")+'&nbsp;</font>';
				w+='<img id="FocusFar" src="v_out_off_n.gif" width="38" height="20" onmouseup="ClickFocusStop();" onmousedown="ClickFocusFar();" style="cursor:pointer;">';
			w+='</div></td>';
		w+='</tr>';
		
		w+='<tr><td>&nbsp;</td></tr>';
		w+='<tr><td>';
			w+='<table>';
					w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_panspeed")+' </font></td><td>'+zbc_panspeed.html+'</td></tr>';
					w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_tiltespeed")+' </font></td><td>'+zbc_tiltspeed.html+'</td></tr>';
					w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_zoomspeed")+' </font></td><td>'+zbc_zoomspeed.html+'</td></tr>';
					w+='<tr><td valign="bottom"><font color="#ffffff">'+GL("ptz_focusspeed")+' </font></td><td>'+zbc_focusspeed.html+'</td></tr>';
					w+='<tr><td>&nbsp;</td></tr>';
					w+='<tr><td><a href="javascript:ClickZbcPan()"><img id="img_pan" alt="'+GL("auto_pan")+'"src="/v_pan-off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+zbc_ptzpanlist.html+'</td></tr>';
					w+='<tr><td><a href="javascript:ClickZbcSequence()"><img id="img_seq" alt="'+GL("auto_sequence")+'"src="/v_seq-off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+zbc_ptzseqlist.html+'</td></tr>';
					//w+='<tr><td><a href="javascript:ClickViscaCruise()"><img id="img_cruise" alt="'+GL("auto_cruise")+'"src="/v_cruise_off_n.gif" width="38" height="20" border="0"/></a>'+'</td><td>'+visca_ptzcruiselist.html+'</td></tr>';
			w+='</table>';
		w+='</td></tr>';
	  }
//--end 2012.11.6
  }

  if(g_isSupportEPTZ == 1 && (!IsViewer()) )
  {
    w+='<tr><td>&nbsp;</td></tr>';	
		w+='<tr><td align="center">';	    
			w+='<a href="javascript:ClickPan()"><img id="img_pan" alt="'+GL("auto_pan")+'" title="'+GL("auto_pan")+'" src="/pan-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
			w+='<a href="javascript:ClickStop()"><img id="img_stop" alt="'+GL("stop")+'" title="'+GL("stop")+'" src="/stop-off_n.gif" width="32" height="32" border="0"/></a>&nbsp;&nbsp;';
			w+='<a href="javascript:ClickSequence()"><img id="img_seq" alt="'+GL("setup_auto_sequence_t")+'" title="'+GL("setup_auto_sequence_t")+'" src="seq-off_n.gif" width="32" height="32" border="0"/></a>';
		w+='</td></tr>';
	
    //w+='<tr><td>&nbsp;</td></tr>';
	//w+='<tr><td id="gotopreset"><img id="img_preset" src="/goto-off_p.gif" width="66" height="20" border="0"/>&nbsp;'+presetselect.html+'</td></tr>';
  }	
  
  //w+='<tr><td><a href="javascript:ClickSequence()" ><img id="img_sequence" alt="'+GL("setup_auto_sequence_t")+'"src="/sequence_off.gif" width="32" height="32" border="0"/></a></td></tr>';
  
  w+='<tr><td align="left"><p align="left" id="displayPT2" style="display: inline;"><br/>';
  if(g_isShowRs485 == 1 && g_isSupportEPTZ == 1)
  {
 
    w+='<font color="#ffffff">'+GL("ptz_control")+'</font><br/>';
    w+=g_ptzselect.html+'<br/><br/>';
	
  }
  //w+='<font color="#ffffff">'+GL("ptz_panspeed")+'</font><br/>';
  //w+=panspeed.html+'<br/><br/>';
  //w+='<font color="#ffffff">'+GL("ptz_tiltespeed")+'</font><br/>';
  //w+=tiltespeed.html+'</p></td></tr>';
  
  //w+=InputButton("PerformAF",GL("af_automatically"),"autofocus_1")+'<br/>';
  
  
  if(g_isSupportEPTZ == 1)
  {
    w+='<font color="#ffffff">'+GL("ptz_speed")+' : </font>';
    w+=ptzspeed.html+'</p></td></tr>';
    //w+='<tr><td><img id="img_speed" src="/speed-off_p.gif" width="66" height="20" border="0"/>&nbsp;'+ptzspeed.html+'</td></tr>';

    w+='<tr><td></br><a href="javascript:ChangeGlobalViewStatus()" style="text-decoration:none"><img id="globalview_img" src="global-off_n.gif" width="96" height="20" border="0"/></a></td></tr>';
    //w+='<tr><td><p><img id="showdms_2" src="/Load.jpg" width="120" height="90"/></p></td></tr>';  
    w+='<tr><td><div id="GlobalView">&nbsp;</div></td></tr>';  
	
  }	else{
    ////chunche[08/31]: ptzspeed need to respond speed value, when not suppoet EPTZ!!
    ptzspeed.GV = function (){ return _ptzspeed; };
  }
  //w+='<div></div><img id="sendPTZCmd" width="0" height="0" border="0" src="" />';
  return w;
};

//var g_GoToPreset;
function GoToPreset()
{
  var str = presetselect.GV();
  if(str=="--Preset List--") return;

  if(g_isSupportVisca == 1)
  {
    var sl =str.split("-");
    var name = sl[1];
    var num = parseInt(sl[0]);
		
    SendHttpPublic("cgi-bin/viscapreset.cgi?action=goto&name="+name+"&number="+num,false);
  }
  else if (g_supportFishEye || g_supportfish_v2)
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=goto&streamid="+mpMode+"&name="+fisheyepresetlistname.GV()+"&direction=point",false);
  else
  {
    SendHttpPublic("cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&name="+presetselect.GV()+"&direction=point",false);
	if(g_isEPTZviewer)
		setTimeout( function(){ SendEPTZPoint(mpMode,GetGoTo) } , (EptzPositonWorking ? 1100 : 300) );
  }
  /*
  g_GoToPreset = null;
  g_GoToPreset = InitXHttp();
  g_GoToPreset.onreadystatechange = GetGoTo;
  
  try
  {
    g_GoToPreset.open("GET", "cgi-bin/eptzpreset.cgi?action=goto&name="+presetselect.GV(), false);
    g_GoToPreset.setRequestHeader("If-Modified-Since","0");
    g_GoToPreset.send(null);
    WS(GL("sending_"));
  }catch(e){};  
  */
};

function GoToHiSiPreset()
{
	var str = hisi_presetselect.GV();
	if(str=="--Preset List--") return;

    var sl =str.split("-");
    var name = sl[1];
    var num = parseInt(sl[0]);
		
    SendHttpPublic("/cgi-bin/longcctvpst.cgi?action=goto&name="+name+"&number="+num,false,resetPanSeq);
};

function GoToZbcPreset()
{
	var str = zbcpresetselect.GV();
	if(str=="--Preset List--") return;

    var sl =str.split("-");
    var name = sl[1];
    var num = parseInt(sl[0]);
		
    SendHttpPublic("cgi-bin/zbcpreset.cgi?action=goto&number="+num,false);
};

function GoToFish()
{
  var str = fisheyepresetlistname1.GV();
  if(str=="--Preset List--") return;
 
  SendHttpPublic("/cgi-bin/fisheye.cgi?action=goto&streamid="+mpMode+"&name="+fisheyepresetlistname1.GV()+"&direction=point",false);
 
};


function GetGoTo()
{
    if(SendEPTZPointHttp.readyState==4)
	{
		WS("");
		if(SendEPTZPointHttp.status==200)
		{
			var txt=SendEPTZPointHttp.responseText;
			var vv=txt.split('=');
			if(vv.length>=2)
			{
			  if(mpMode == 1)
			  {
				g_EPTZ1x1 = parseInt(vv[1].substr(0,4)*1);
				g_EPTZ1y1 = parseInt(vv[1].substr(4,4)*1);
				//SendEPTZCmd(g_EPTZ1x1,g_EPTZ1y1);
			  }
              else if(mpMode == 2)
              {			  
				g_EPTZ2x1 = parseInt(vv[1].substr(0,4)*1);
				g_EPTZ2y1 = parseInt(vv[1].substr(4,4)*1);
				//SendEPTZCmd(g_EPTZ2x1,g_EPTZ2y1);
			  }
              else if(mpMode == 3)
              {			  
				g_EPTZ3x1 = parseInt(vv[1].substr(0,4)*1);
				g_EPTZ3y1 = parseInt(vv[1].substr(4,4)*1);
				//SendEPTZCmd(g_EPTZ3x1,g_EPTZ3y1);
			  }	
			  //SendEPTZPoint(profile.GV());
			  if(g_isEPTZviewer)
				MoveUvumiWin();
			}
			else
			{
				alert(GL("get_fail"));
			}
		}
		else
		{
			alert(GL("get_fail"));
		}
	}
	
};

function SendEPTZCmd(left,top)
{
  var str_x = '';
  var str_y = '';
  str_x += left;
  str_y += top;
  if(str_x.length < 4)
  {
	if(str_x.length == 1)
	  str_x='000'+str_x;
	else if(str_x.length == 2)
	  str_x='00'+str_x;
	else if(str_x.length == 3)  
	  str_x='0'+str_x;
  }
  if(str_y.length < 4)
  {
	if(str_y.length == 1)
	  str_y='000'+str_y;
	else if(str_y.length == 2)
	  str_y='00'+str_y;
	else if(str_y.length == 3)  
	  str_y='0'+str_y;
  }	  
  SendHttpEPTZ("/vb.htm?eptzcoordinate="+mpMode+str_x+str_y,false);
};

function ChangeImg(id,src)
{
  obj = GE(id);
  if(obj != null)
    obj.src = src;
};


function ClickPan()
{
  if(g_supportFishEye || g_supportfish_v2){
		
	  ChangeImg("img_seq","seq-off_n.gif");	  
	  ChangeImg("img_pan","pan-on_n.gif");
	  if(g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?panorama=1" + "&" + fish_panoramicspeed.setcmd+fish_panoramicspeed.GV(),false);	  
	  else
		SendHttpPublic("cgi-bin/fisheye.cgi?panorama=1",false);
	  
     g_fisheyeautopan=1;
	 
  }
  else if(g_support_real_ptz==1)
  {	ChangeImg("img_seq","seq-off_n.gif");
		ChangeImg("img_pan","pan-on_n.gif");
		SendHttpPublic("/cgi-bin/longcctvapn.cgi?action=go&speed="+hisi_autopanspeed.GV(),false);
		
		setTimeout(function(){
			CheckPanStop_SeqStop('pan');
		}, 2000);
  }
  else{
	  ChangeImg("img_pan","pan-on_n.gif");
	  //ChangeImg("img_seq","seq-off_p.gif");
	  SendHttpPublic("cgi-bin/eptzpreset.cgi?action=autopan&streamid="+mpMode,false);
	  //setTimeout('ChangeImg("img_pan","pan-off_n.gif")', 200);
  }
};

function ClickStop()
{
  if(g_supportFishEye || g_supportfish_v2){
	
	  g_fisheyeautopan=0;
	  g_fisheyesequence=0;
	  
	  ChangeImg("img_stop","stop-on_n.gif");
	  ChangeImg("img_pan","pan-off_n.gif");  //for fisheye
	  ChangeImg("img_seq","seq-off_n.gif");  //for fisheye
	  SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
	  setTimeout('ChangeImg("img_stop","stop-off_n.gif")', 200);
  }
  else if(g_support_real_ptz==1)
  {
	ChangeImg("img_pan","pan-off_n.gif");  
	ChangeImg("img_seq","seq-off_n.gif");  
	
	SendHttpPublic("/cgi-bin/longcctvapn.cgi?action=stop",false);
	SendHttpPublic("/cgi-bin/longcctvseq.cgi?action=stop");
	
	clearTimeout(clearCheckpan_seqStop);
  
  }
  else{
	  ChangeImg("img_stop","stop-on_n.gif");
	  //ChangeImg("img_pan","pan-off_p.gif");
	  //ChangeImg("img_seq","seq-off_p.gif");
	  SendHttpPublic("cgi-bin/eptzpreset.cgi?action=stop&streamid="+mpMode,false);
	  setTimeout('ChangeImg("img_stop","stop-off_n.gif")', 200);
  }
};

function ClickSequence()
{
  if(g_supportFishEye || g_supportfish_v2){
	 
	  ChangeImg("img_pan","pan-off_n.gif");	  
	  ChangeImg("img_seq","seq-on_n.gif");
	  
	  if(g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?rotate=1" + "&" + fish_rotatespeed.setcmd+fish_rotatespeed.GV(),false); 
	  else
		SendHttpPublic("cgi-bin/fisheye.cgi?rotate=1",false);
	  
	  g_fisheyesequence=1;	  
		
	  
  }
  else if(g_support_real_ptz==1)
  {
	   ChangeImg("img_pan","pan-off_n.gif");	
	  ChangeImg("img_seq","seq-on_n.gif");
	// SendHttpPublic("/cgi-bin/longcctvseq.cgi?action=go");
  	 SendHttpPublic("/cgi-bin/longcctvseq.cgi?action=stop",false);
	 
	 setTimeout(function(){	
		SendHttpPublic("/cgi-bin/longcctvseq.cgi?action=go",false);	 
		},500);
		
	setTimeout(function(){
			CheckPanStop_SeqStop('seq');
		}, 2000);
	 

  }
  else{
	  //ChangeImg("img_pan","pan-off_p.gif");
	  ChangeImg("img_seq","seq-on_n.gif");
	  SendHttpPublic("cgi-bin/eptzpreset.cgi?action=seq_go&streamid="+mpMode,false);
	  //setTimeout('ChangeImg("img_seq","seq-off_n.gif")', 200);
  }
};

var clearCheckpan_seqStop = null;
function CheckPanStop_SeqStop(txt){

	if(clearCheckpan_seqStop != null){
		clearTimeout(clearCheckpan_seqStop);
		clearCheckpan_seqStop = null;
	}	
	
	if( txt == 'pan')
		SendHttpPublic("/vb.htm?paratest=longcctvapnstatus",false,setpanIcon);			
	else if( txt == 'seq')
		SendHttpPublic1("/vb.htm?paratest=longcctvseqstatus",false,setseqIcon);
	
	clearCheckpan_seqStop = setTimeout(function(){
		CheckPanStop_SeqStop(txt);
	},3500);
}

//only for visca of ptz
function CheckImgMatch(id,img){
	var src = "";
	obj = GE(id);
	
	if(obj!=null){
		src = obj.src;
		if(src.match(img)==img)
			return true;
		else
			return false;
	}
}
function ClickViscaPan(){
	if (g_isSupportVisca==1){
		if(CheckImgMatch("img_pan", "v_pan-on_n.gif")){
			SendViscaCmdToDevice(CMD_AUTO_STOP);
			ChangeImg("img_pan", "v_pan-off_n.gif");
		}else{
			SendViscaCmdToDevice(CMD_AUTO_PAN);
			ChangeImg("img_pan", "v_pan-on_n.gif");
		}
		ChangeImg("img_seq", "v_seq-off_n.gif");
		ChangeImg("img_cruise", "v_cruise_off_n.gif");
	}
};
function ClickViscaSequence(){
	if (g_isSupportVisca==1){
		if(CheckImgMatch("img_seq", "v_seq-on_n.gif")){
			SendViscaCmdToDevice(CMD_AUTO_STOP);
			ChangeImg("img_seq", "v_seq-off_n.gif");
		}else{
			SendViscaCmdToDevice(CMD_AUTO_SEQUENCE);
			ChangeImg("img_seq", "v_seq-on_n.gif");
		}
		ChangeImg("img_pan", "v_pan-off_n.gif");
		ChangeImg("img_cruise", "v_cruise_off_n.gif");
	}
}
function ClickViscaCruise(){
	if (g_isSupportVisca==1){
		if(CheckImgMatch("img_cruise", "v_cruise_on_n.gif")){
			SendViscaCmdToDevice(CMD_AUTO_STOP);
			ChangeImg("img_cruise", "v_cruise_off_n.gif");
		}else{
			SendViscaCmdToDevice(CMD_AUTO_CRUISE);
			ChangeImg("img_cruise", "v_cruise_on_n.gif");
		}
		ChangeImg("img_pan", "v_pan-off_n.gif");
		ChangeImg("img_seq", "v_seq-off_n.gif");
	}
}
function ClickZbcPan(){
	if (g_supportZbc==1){
		if(CheckImgMatch("img_pan", "v_pan-on_n.gif")){
			SendHttpPublic("cgi-bin/zbcautopan.cgi?action=stop", false);
			ChangeImg("img_pan", "v_pan-off_n.gif");
		}else{
			SendHttpPublic("cgi-bin/zbcautopan.cgi?action=run", false);
			ChangeImg("img_pan", "v_pan-on_n.gif");
		}
		
		ChangeImg("img_seq", "v_seq-off_n.gif");
		ChangeImg("img_cruise", "v_cruise_off_n.gif");
	}
};
function ClickZbcSequence(){
	if (g_supportZbc==1){
		if(CheckImgMatch("img_seq", "v_seq-on_n.gif")){
			SendHttpPublic("/cgi-bin/zbcsequence.cgi?action=stop",false);
			ChangeImg("img_seq", "v_seq-off_n.gif");
		}else{
			SendHttpPublic("/cgi-bin/zbcsequence.cgi?action=run&line="+zbc_ptzseqlist.GV(),false);
			ChangeImg("img_seq", "v_seq-on_n.gif");
		}
		ChangeImg("img_pan", "v_pan-off_n.gif");
		ChangeImg("img_cruise", "v_cruise_off_n.gif");
	}
}
function ClickAutoFocuse(mode)
{
  if (g_isSupportVisca==1 && g_focusmodeinq==0){
	  SendViscaCmdToDevice("CMD_FOCUS_AUTO");
	  
	  ChangeImg("img_af", "v_af_on_n.gif");
	  ChangeImg("img_mf", "v_mf_off_n.gif");
	  //ChangeImg("FocusNear", "v_in_off_p.gif");
	  //ChangeImg("FocusFar", "v_out_off_p.gif");
	  GE("mfctrl").style.display = "none";
	  g_focusmodeinq = 1;
  }
  
  if(g_supportZbc==1 && g_zbcfocusmode==0){
	  var cmd = "vb.htm?setzbcfocusmode=4";
	  SendHttpPublic(cmd,false);
	  
	  ChangeImg("img_af", "v_af_on_n.gif");
	  ChangeImg("img_mf", "v_mf_off_n.gif");
	  //ChangeImg("FocusNear", "v_in_off_p.gif");
	  //ChangeImg("FocusFar", "v_out_off_p.gif");
	  GE("mfctrl").style.display = "none";
	  g_zbcfocusmode = 4;
  }
};

function ClickManualFocuse()
{
  if (g_isSupportVisca==1 && g_focusmodeinq==1){
	  SendViscaCmdToDevice("CMD_FOCUS_MANUAL");
	  
	  ChangeImg("img_af", "v_af_off_n.gif");
	  ChangeImg("img_mf", "v_mf_on_n.gif");
	  //ChangeImg("FocusNear", "v_in_off_n.gif");
	  //ChangeImg("FocusFar", "v_out_off_n.gif");
	  GE("mfctrl").style.display = "block";
	  g_focusmodeinq = 0;
  }
  
  if(g_supportZbc==1 && g_zbcfocusmode==4){
	  var cmd = "vb.htm?setzbcfocusmode=0";
	  SendHttpPublic(cmd,false);
	  
	  ChangeImg("img_af", "v_af_off_n.gif");
	  ChangeImg("img_mf", "v_mf_on_n.gif");
	  //ChangeImg("FocusNear", "v_in_off_n.gif");
	  //ChangeImg("FocusFar", "v_out_off_n.gif");
	  GE("mfctrl").style.display = "block";
	  g_zbcfocusmode = 0;
  }
};
function ClickFocusStop()
{
  if (g_isSupportVisca==1 && g_focusmodeinq==0)
	 SendViscaCmdToDevice("CMD_FOCUS_STOP");
	 
  if (g_supportZbc==1 && g_zbcfocusmode==0){
	 //SendViscaCmdToDevice("CMD_FOCUS_STOP");
	  var cmd = "vb.htm?setzbcstop=3";
	  SendHttpPublic(cmd,false);
  }
};
function ClickFocusFar()
{
  if (g_isSupportVisca==1 && g_focusmodeinq==0)
	 SendViscaCmdToDevice("CMD_FOCUS_FAR");
	 
  if (g_supportZbc==1 && g_zbcfocusmode==0){
	 //SendViscaCmdToDevice("CMD_FOCUS_FAR");
	  var cmd = "vb.htm?setzbcfz=4";
	  SendHttpPublic(cmd,false);
  }
};
function ClickFocusNear()
{
  if (g_isSupportVisca==1 && g_focusmodeinq==0)
	 SendViscaCmdToDevice("CMD_FOCUS_NEAR");
	 
  if (g_supportZbc==1 && g_zbcfocusmode==0){
	 //SendViscaCmdToDevice("CMD_FOCUS_NEAR");
	  var cmd = "vb.htm?setzbcfz=3";
	  SendHttpPublic(cmd,false);
  }
};
//end only for visca

function ChangeGlobalViewStatus(status)
{
  var viewer = false;
  var obj = GE("GlobalView");
  
  if(obj != null)
  {
    if(status != null)
	  viewer = !status;
	else
	  viewer = g_isEPTZviewer;
	  
    if(viewer)
	{
	  g_isEPTZviewer = false;
	  
	  if(EptzPositonWorking)
		StopGetEptzPostion();
		
	  clearTimeout(timerChangeImage);
	  
	  setTimeout(function(){
		  GE("globalview_img").src = "global-off_n.gif";
		  obj.innerHTML='';
	  }, 500);
	}
	else
	{
	  GE("globalview_img").src = "global-on_f.gif";
      obj.innerHTML='<img id="showdms_2" src="/Load.jpg" width="'+g_globalWidth+'" height="'+g_globalHeight+'"/>';
	  if(g_isSupportEPTZ == 1)
	    RunCropper();
		
	  if(!EptzPositonWorking)
		SendEPTZPoint(mpMode);
		
	  g_isEPTZviewer = true;
	}  
  }
};

function PerformAF()
{
  SubmitHttp = null;
  SubmitHttp = InitXHttp();
  
  try
  {
    SubmitHttp.open("GET", "cgi-bin/lencontrol.cgi?autofocus=1", false);
    SubmitHttp.setRequestHeader("If-Modified-Since","0");
    SubmitHttp.send(null);
    WS(GL("sending_"));
  }catch(e){};
  g_httpOK = true;
};

function GetAREA(title,alt,id,onmouseout,onmouseover,onmouseup,onmousedown,coords,type)
{
  var i=''; //
   
  if(g_support_real_ptz)  
	i+='<area title="'+title+'" alt="'+alt+'" id="'+id+'" onmouseout="outImage('+"'"+onmouseout+"'"+')" onmouseover="overImage('+"'"+onmouseover+"'"+')" onmousedown="move('+"'"+onmousedown+"'"+')" onmouseup="pressQueue('+"'"+onmouseup+"'"+')" coords="'+coords+'" shape="'+type+'">';
  else
    i+='<area title="'+title+'" alt="'+alt+'" id="'+id+'" onmouseout="outImage('+"'"+onmouseout+"'"+')" onmouseover="overImage('+"'"+onmouseover+"'"+')" onmouseup="move('+"'"+onmouseup+"'"+')" onmousedown="pressImage('+"'"+onmousedown+"'"+')" coords="'+coords+'" shape="'+type+'">';
  
  
  return i;
};
function overImage(type)
{
  if (type == "left_up")
	document.PTControl.src = imagePT["left_up_f"].src;
  if (type == "up")
	document.PTControl.src = imagePT["up_f"].src;
  if (type == "right_up")
	document.PTControl.src = imagePT["right_up_f"].src;
  if (type == "left")
	document.PTControl.src = imagePT["left_f"].src;
  if (type == "home")
	document.PTControl.src = imagePT["home_f"].src;
  if (type == "right")
	document.PTControl.src = imagePT["right_f"].src;
  if (type == "left_down")
	document.PTControl.src = imagePT["left_down_f"].src;
  if (type == "down")
	document.PTControl.src = imagePT["down_f"].src;
  if (type == "right_down")
	document.PTControl.src = imagePT["right_down_f"].src;
  if (type == "zoom_out")
	document.PTControl.src = imagePT["zoom_out_f"].src;
  if (type == "zoom_in")
	document.PTControl.src = imagePT["zoom_in_f"].src;
};
function outImage(type)
{
  if (type == "pt_out")
    document.PTControl.src = imagePT["way_control_n"].src;
};
//FIFO
var popQueueFlag=false;
var clearPressQueue = null;
function pressQueue(onmouseup)
{
	fifoQueue.push(onmouseup); 			
	popQueueFlag=false;
}

function popPressQueue()
{  
	if(popQueueFlag==false)
	{
		if(fifoQueue.length>0 )
		{		
			pressImage(fifoQueue.shift(),null);		
			clearPressQueue=setTimeout("popPressQueue()",1000);
		}
		else
			popQueueFlag=true;
	}

}

function pressImage(type,isMouse)
{
 
  if(g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc){//not visca,fisheye,zbc speed dome

		if(g_isSupportEPTZ == 1){
			num = 2*ptzspeed.GV();
			var x1 = g_EPTZmouseY;
			var y1 = g_EPTZmouseX;
		}
  } 
  
  
  if (type == "left_up")
  {
	if(isMouse==null)
      document.PTControl.src = imagePT["left_up_p"].src;	  
	  
	   //SendHttpPublic("/vb.htm?ipncvisca=0600" + Check0to9(parseInt(hisi_panspeed.GV(),10).toString(16)) + Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false);   	   
	   
     if(g_support_real_ptz)
	 {
	   var o='';
	   	if(g_longcctvmovemode==0  && g_support_longcctv_cont==1)
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=leftup&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	  else
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=leftup&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o, false,resetPanSeq);
	 }  
	 
	else if(g_PTZMode == 1  && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
		if(!g_isEPTZviewer && g_PTZMode!=3  && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.	
			SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=left_up");	   
	
	  x1 = parseInt(x1-num);
	  y1 = parseInt(y1-num);
	}
	
	

	
	if((g_PTZMode == 0 || g_PTZMode == 3) && !g_supportFishEye  && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_UP_LEFT");
	}

	
	
	
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?direction=left_up");
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=left_up" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	

	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=1");
  }

  if (type == "up")
  {
	if(isMouse==null)
      document.PTControl.src = imagePT["up_p"].src;
	  
	  //SendHttpPublic("/vb.htm?ipncvisca=010000" + Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false);  
	 
	

	 
	if(g_support_real_ptz)
	 {  
   	  var o='';
		if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panspeed="+  GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	  else
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panstep="+  GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o, false,resetPanSeq);
	 }
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
		if(!g_isEPTZviewer && g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
			SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=up");
	
	  y1 = parseInt(y1-num);
	}

	 
	  
	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_TILT_UP");
	}

	
	
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=tilt&direction=up");
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=tilt&direction=up" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
	
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=2");
  }

  if (type == "right_up")
  {
	if(isMouse==null)
      document.PTControl.src = imagePT["right_up_p"].src;
	  
	   //SendHttpPublic("/vb.htm?ipncvisca=0700" + Check0to9(parseInt(hisi_panspeed.GV(),10).toString(16)) + Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false);  
	   
 
	   
	if(g_support_real_ptz)
	 {   
	   var o='';
	   	if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=rightup&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	  else
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=rightup&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o, false,resetPanSeq);
	}
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
	
		if(!g_isEPTZviewer && g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=right_up");	  
	
      x1 = parseInt(x1+num);
	  y1 = parseInt(y1-num);
	}  
	
	  
	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_UP_RIGHT");
	}

	

		
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?direction=right_up");	
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=right_up" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
	
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=3");
  }

  if (type == "left")
  {
	if(isMouse==null)
	  document.PTControl.src = imagePT["left_p"].src;
	  
	 //  SendHttpPublic("/vb.htm?ipncvisca=0200" + Check0to9(parseInt(hisi_panspeed.GV(),10).toString(16)) + "0000",false);  
	 
	
 
	 
	 
	if(g_support_real_ptz)
	 { 
		var o='';	  
		  if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
				 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
		  else
				 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
			
		   SendHttpPublic(o, false,resetPanSeq);
	}  
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
	
		if(!g_isEPTZviewer && g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=left");	
	
      x1 = parseInt(x1-num);
	} 
	
	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_PAN_LEFT");
	}


		
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=left");	
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=left" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
	
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=4");
  }

  if (type == "home")
  {
	if(isMouse==null)
	  document.PTControl.src = imagePT["home_p"].src;
	  
	  //SendHttpPublic("/vb.htm?ipncvisca=0800000000",false); 
	  
	 if(g_support_real_ptz)
	 {  
	  SendHttpPublic("/cgi-bin/longcctvhome.cgi?action=gohome",false,resetPanSeq);
     }
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//EPTZ  
	{
	    
		  if(g_isEPTZviewer ) 
		  {
				if(l_profileresolution[mpMode-1] != l_profilereviewer[mpMode-1])
				{
				  //g_Cropper.moveToClick_EPTZ(64/(240/90),80/(320/120)); 
				  num = l_profileresolution[mpMode-1].split('x');
				  num2 = l_profilereviewer[mpMode-1].split('x');
				  ratew = num[0]/num2[0];
				  rateh = num[1]/num2[1];
				  
				  ratew2 = num2[0]/g_globalWidth;
				  rateh2 = num2[1]/g_globalHeight;
				  
				  halfW = g_globalWidth/2;
				  halfH = g_globalHeight/2;
				  half2W = (num2[0]/ratew2)/ratew/2;
				  half2H = (num2[1]/ratew2)/rateh/2;
				  
				  //alert(halfW);
				  //alert(half2W);
				  //alert(halfH - half2H);
				  //alert(halfW - half2W);
				  g_Cropper.moveToClick_EPTZ(halfH - half2H,halfW - half2W); 
				}  
		  }
		  else{ 
			SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=home");
		  }
		  
		  
		  
	 } 
	 var obj = GE(AxID);
      if (obj != null)
      {
	    g_ZoomSize = 0;
        obj.SetZoomSize(g_ZoomSize);
      }
	  

	if(g_PTZMode == 0 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz)//RS485
      SendDLinkPTZCmd2Device("CMD_HOME");
	else if(g_PTZMode == 3 && !g_supportZbc)//VISCA
		SendHttpPublic("cgi-bin/viscahome.cgi?action=gohome",false);
	 
	
	else if( (g_supportFishEye || g_supportfish_v2) && !g_supportZbc )// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=gohome");
	else if(g_supportZbc)
		SendHttpPublic("/cgi-bin/zbchome.cgi?action=gohome");
	
	popQueueFlag=false;		//20140428 add
    return 0;	
  }

  if (type == "right")
  {
	if(isMouse==null)
     document.PTControl.src = imagePT["right_p"].src;  
		
	if(g_support_real_ptz)
	 { 
		var o='';
	   
	   if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	   else
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o , true,resetPanSeq);  //
	}
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
		
	if(!g_isEPTZviewer && g_PTZMode!=3  && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=right");	
	
      x1 = parseInt(x1+num);
	}  
	

	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz)//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_PAN_RIGHT");
  

		
	if(g_supportFishEye )// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=right");	
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=right" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=6");
  }

  if (type == "left_down")
  {
	if(isMouse==null)
      document.PTControl.src = imagePT["left_down_p"].src;
	  
	 // SendHttpPublic("/vb.htm?ipncvisca=0400" + Check0to9(parseInt(hisi_panspeed.GV(),10).toString(16)) + Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false); 


	 
	 if(g_support_real_ptz)
	 {
	 var o='';
	  	if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			o="/cgi-bin/longcctvmove.cgi?action=move&direction=leftdown&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	  else
			o="/cgi-bin/longcctvmove.cgi?action=move&direction=leftdown&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o, false,resetPanSeq);
	}
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
	
	if(!g_isEPTZviewer && g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=left_down");	
	
      x1 = parseInt(x1-num);
	  y1 = parseInt(y1+num);      
	} 
	

	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz)//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_DOWN_LEFT");
 

		
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?direction=left_down");	
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=left_down" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	

	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=7");
  }

  if (type == "down")
  {
	if(isMouse==null)
      document.PTControl.src = imagePT["down_p"].src;
	  
	 // SendHttpPublic("/vb.htm?ipncvisca=000000" + Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false); 
	 


     if(g_support_real_ptz)
	 {
	 var o='';
		if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
	  else
			 o="/cgi-bin/longcctvmove.cgi?action=move&direction=" + type + "&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
	   SendHttpPublic(o, false,resetPanSeq);
	 }
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
	
	if(!g_isEPTZviewer && g_PTZMode!=3  && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=down");	
	
      y1 = parseInt(y1+num);
	}   
	 

	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz)//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_TILT_DOWN");
 

		
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=tilt&direction=down");	
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=tilt&direction=down" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
		
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=8");
  }

  if (type == "right_down")
  {
	if(isMouse==null)
	   document.PTControl.src = imagePT["right_down_p"].src;
	   
	//   SendHttpPublic("/vb.htm?ipncvisca=0500" + Check0to9(parseInt(hisi_panspeed.GV(),10).toString(16)) +  Check0to9(parseInt(hisi_tiltspeed.GV(),10).toString(16)) + "00",false); 
	
	

		
	if(g_support_real_ptz)
	 {
		var o='';
		  if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
				 o="/cgi-bin/longcctvmove.cgi?action=move&direction=rightdown&panspeed="+ GetCCV("hisi_panspeed") +"&tiltspeed="+ GetCCV("hisi_tiltspeed");
		  else
				 o="/cgi-bin/longcctvmove.cgi?action=move&direction=rightdown&panstep="+ GetCCV("hisi_panspeed") +"&tiltstep="+ GetCCV("hisi_tiltspeed"); 
		   SendHttpPublic(o, false,resetPanSeq);
	}
	else if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//eptz
	{
		
	  if(!g_isEPTZviewer && g_PTZMode!=3 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)//GlobalView is Visabled, and not Visca.
		SendHttpPublic("/cgi-bin/eptzpreset.cgi?action=goto&streamid="+mpMode+"&direction=right_down");		
	
	  x1 = parseInt(x1+num);
	  y1 = parseInt(y1+num);
	}
	

	if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz)//rs485 or visca
      SendDLinkPTZCmd2Device("CMD_DOWN_RIGHT");


		
	if(g_supportFishEye)// FishEye
		SendHttpPublic("/cgi-bin/fisheye.cgi?direction=right_down");
	if( g_supportfish_v2)	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=pan&direction=right_down" + "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV() + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
		
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcptdirection=9");
  }

  if (type == "zoom_out")
  {
	  if(!browser_IE)
	  {
			if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportZbc){//rs485 or visca
				
			  SendDLinkPTZCmd2Device("CMD_ZOOM_OUT");
			}
			else
				alert(GL("livev_zoom_alarm"));
	  }
	  else
	  {
			if(isMouse==null)
			  document.PTControl.src = imagePT["zoom_out_p"].src;
			  
			  
			 if(g_support_real_ptz)
			 { 
			  SendHttpPublic("/vb.htm?setlongcctvzoom=0",false);
			  }
			  else if(g_PTZMode == 1 &&  !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)
				{//eptz
				  
				}
			
			  var obj = GE(AxID);
			  if (obj != null)
			  {
				g_ZoomSize--;
				if(g_ZoomSize <= 0)
				  g_ZoomSize = 0;
				obj.SetZoomSize(g_ZoomSize);
			  }
			  
			if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
			  SendDLinkPTZCmd2Device("CMD_ZOOM_OUT");
			}
			
			
			//start 2010.11.8 add
			/*if(g_isSupportVisca == 1){
				g_ViscaZoomEn = true;
				clearTimeout(timerVisca);
				timerVisca = setTimeout("StartViscaWorker()", 0);
			}*/
			//end 2010.11.8
			
			if(g_supportFishEye)// FishEye
				SendHttpPublic("/cgi-bin/fisheye.cgi?action=zoom&direction=zoom_out");
			if( g_supportfish_v2)	
				SendHttpPublic("/cgi-bin/fisheye.cgi?action=zoom&direction=zoom_out"+ "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV()  + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
		
			if(g_supportZbc)//zbc speed dome
				SendHttpPublic("/vb.htm?setzbcfz=2");
	  }
	  
  }
  if (type == "zoom_in")
  {
	  if(!browser_IE)
	  {
			if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportZbc){//rs485 or visca
				
			  SendDLinkPTZCmd2Device("CMD_ZOOM_IN");
			}
			else
				alert(GL("livev_zoom_alarm"));
	  }
	  else
	  {
			if(isMouse==null)
			  document.PTControl.src = imagePT["zoom_in_p"].src;
			  
			if(g_support_real_ptz)
			{
			  SendHttpPublic("/vb.htm?setlongcctvzoom=1",false);
			 }
			else  if(g_PTZMode == 1 && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc)
			{//eptz
				  
			}

			 
			  var obj = GE(AxID);
				  if (obj != null)
				  {
					g_ZoomSize++;
					if(g_ZoomSize >=9)
					  g_ZoomSize = 9;
					  
					obj.SetZoomSize(g_ZoomSize);
				  }

			if(((g_PTZMode == 0)||(g_PTZMode == 3)) && !g_supportFishEye && !g_supportfish_v2 && !g_supportZbc && !g_support_real_ptz){//rs485 or visca
			  SendDLinkPTZCmd2Device("CMD_ZOOM_IN");
			}
			//start 2010.11.8 add
			/*if(g_isSupportVisca == 1){
				g_ViscaZoomEn = true;
				clearTimeout(timerVisca);
				timerVisca = setTimeout("StartViscaWorker()", 0);
			}*/
			//end 2010.11.8
			if(g_supportFishEye)// FishEye
				SendHttpPublic("/cgi-bin/fisheye.cgi?action=zoom&direction=zoom_in");
			if( g_supportfish_v2)	
				SendHttpPublic("/cgi-bin/fisheye.cgi?action=zoom&direction=zoom_in"+ "&" + fish_panspeed.setcmd+fish_panspeed.GV() + "&" + fish_tiltspeed.setcmd+fish_tiltspeed.GV()  + "&" + fish_zoomspeed.setcmd + fish_zoomspeed.GV());	
		
			if(g_supportZbc)//zbc speed dome
				SendHttpPublic("/vb.htm?setzbcfz=1");
		}		
  }
  
  if(g_PTZMode == 1)
  {//EPTZ
    if(y1 < 0)
	  y1 = 0;
	if(x1 < 0)
      x1 = 0;
	  
	w = parseInt(g_globalWidth-g_EPTZWidth);
	h = parseInt(g_globalHeight-g_EPTZHeight);
  
	if(y1 > h)	  
	  y1 = h;
	if(x1 > w)
      x1 = w; 
	if(g_isEPTZviewer)
      g_Cropper.moveToClick_EPTZ(y1,x1); 
  }	
  
  popQueueFlag=false;	//20140324 add
}

function resetPanSeq() 
{
	var list='';

	if (g_SubmitHttpPublic.readyState == 4)
	{
		if (g_SubmitHttpPublic.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			  resetPanSeqIcon();	  
			
		}
	}
		
}

function Check0to9(num)
{

	if(num.length<2)
		return "0" + num.toString();
	else 
		return num;
}

function move(type) 
{
  var action_type="";

  if (type=="left_up" || type=="up" || type=="right_up" || type=="left" ||
      type=="right" || type=="left_down" || type=="down" || type=="right_down")
  {
		if (g_isSupportVisca==1){
			SendDLinkPTZStopCmd(CMD_PANTILT_STOP);//CMD_PANTILT_STOP
		}
		else if(g_supportFishEye || g_supportfish_v2){// FishEye
			
			if(type=="left_up" || type=="right_up" || type=="left_down" || type=="right_down" ){
				SendHttpPublic("/cgi-bin/fisheye.cgi?direction=stop");
			}
			else{
				if(type=="up" || type=="down" )
					action_type="tilt";		
				else if(type=="left" || type=="right")
					action_type="pan";
				SendHttpPublic("/cgi-bin/fisheye.cgi?action="+action_type+"&direction=stop");
			}		
			
		}
		else if(g_supportZbc){//zbc speed dome
			SendHttpPublic("/vb.htm?setzbcstop=1");
		}
		else if(g_support_real_ptz==1  && g_support_longcctv_cont==1) 
		 {			
				SendHttpPublic("/cgi-bin/longcctvmove.cgi?action=move&direction=stop");
		 }
		else{
		
			 //Stop	  		  
			  if(g_support_real_ptz==0)
				SendDLinkPTZStopCmd();//stop 	=>rs485output
			
		}
	
	
  }
  else  if (type=="zoom_out" || type=="zoom_in")
  {
    if(g_support_real_ptz==1)
	  {
	//	SendHttpPublic("/vb.htm?ipncvisca=0800000000");
	  }
	  else 
		SendDLinkPTZStopCmd(); //stop 	=>rs485output
		
		
	//start 2010.11.8 add

	if (g_isSupportVisca==1)
		StartViscaWorker();//to update zoom ratio.
	//end 2010.11.8	
	if(g_supportFishEye || g_supportfish_v2){// FishEye	
		SendHttpPublic("/cgi-bin/fisheye.cgi?action=zoom&direction=stop");
		SendHttpPublic("/cgi-bin/fisheye.cgi?getzoom=1");	
	}	
		
	if(g_supportZbc)//zbc speed dome
		SendHttpPublic("/vb.htm?setzbcstop=2");
  }

  document.PTControl.src = imagePT["way_control_n"].src;
  
  popQueueFlag=false;		//20140324 add
}

var g_ResolutionX;
var g_ResolutionY;
var g_tempx1;
var g_tempy1;
var g_MouseNumX = 0;
var g_MouseNumY = 0;
var JOYSTICK_MIN = 0;
var JOYSTICK_MID = 32767;
var JOYSTICK_MAX = 65535; 
var JOYSTICK_FIXNUM = 3000;
var timerPTZ = null;
var g_EPTZ_type = "";
var g_EPTZ_type_Fish = "";
var g_EPTZ_type_FishTemp = "";
var g_PTZ_TimeInterval_Fish = 100;
var g_PTZ_TimeInterval = 100;
var boxNum=0;

function StartEPTZWorker()
{
  if(!IsMozilla())
  {
    var obj = GE(AxID);
    if(obj!=null)
    {   
	  if(obj.GetIsJoystick() == 1 || obj.GetIsJoystickFish() == 1)
	  {
			var cmd = ''; 
			
			if(g_supportFishEye == 1){	
				var x1 = parseInt( obj.GetJoystickFishX() );
				var y1 = parseInt( obj.GetJoystickFishY() );
			}
			else{
				var x1 = parseInt( obj.GetJoystickX() );
				var y1 = parseInt( obj.GetJoystickY() );
			}
			
			if(x1 < (JOYSTICK_MID - JOYSTICK_FIXNUM) )
			{//x-left
				if(y1 < (JOYSTICK_MID - JOYSTICK_FIXNUM) )
				{//y-top area
					//left-up
					if(g_EPTZ_type!="left_up"){
					  cmd = '';
					  for(i=0;i<CMD_UP_LEFT.length;i++)
						cmd += CMD_UP_LEFT[i]+',';
					  pressImage("left_up",cmd);
					  g_EPTZ_type = "left_up";
					}
					
				}
				else if(y1 >= (JOYSTICK_MID - JOYSTICK_FIXNUM) && y1 <= (JOYSTICK_MID + JOYSTICK_FIXNUM))
				{//y-middle area
					//left
					if(g_EPTZ_type!="left"){
					  cmd = '';
					  for(i=0;i<CMD_PAN_LEFT.length;i++)
						cmd += CMD_PAN_LEFT[i]+',';
					  pressImage("left",cmd);
					  g_EPTZ_type = "left";
					}
					
				}
				else if(y1 > (JOYSTICK_MID + JOYSTICK_FIXNUM) )
				{//y-bottom area
					//left-down
					if(g_EPTZ_type!="left_down"){
					  cmd = '';
					  for(i=0;i<CMD_DOWN_LEFT.length;i++)
						cmd += CMD_DOWN_LEFT[i]+',';
					  pressImage("left_down",cmd);
					  g_EPTZ_type = "left_down";
					}
					
				}
			}
			else if(x1 >= (JOYSTICK_MID - JOYSTICK_FIXNUM) && x1 <= (JOYSTICK_MID + JOYSTICK_FIXNUM))
			{//x-middle
				if(y1 < (JOYSTICK_MID - JOYSTICK_FIXNUM) )
				{//y-top area
					//up
					if(g_EPTZ_type!="up"){
					  cmd = '';
					  for(i=0;i<CMD_TILT_UP.length;i++)
						cmd += CMD_TILT_UP[i]+',';
					  pressImage("up",cmd);
					  g_EPTZ_type = "up";
					}
					
				}
				else if(y1 >= (JOYSTICK_MID - JOYSTICK_FIXNUM) && y1 <= (JOYSTICK_MID + JOYSTICK_FIXNUM))
				{//y-middle area
					if(g_EPTZ_type!=""){
						//to do stop
						if(g_PTZMode == 0)//PTZ
						{
							cmd = '';
							for(i=0;i<CMD_STOP.length;i++)
								cmd += CMD_STOP[i]+',';
							SendPTZCmdToDevice(cmd);
						}else
						if(g_PTZMode == 3){//VISCA
							SendDLinkPTZStopCmd(CMD_PANTILT_STOP);//CMD_PANTILT_STOP
						}
						g_EPTZ_type = "";
					}
					//g_EPTZnum = 1;
					//var obj = GE("PTControl");
					//obj.src = imagePT["ptz"].src;
				}
				else if(y1 > (JOYSTICK_MID + JOYSTICK_FIXNUM) )
				{//y-bottom area
					//down
					if(g_EPTZ_type!="down"){
					  cmd = '';
					  for(i=0;i<CMD_TILT_DOWN.length;i++)
						cmd += CMD_TILT_DOWN[i]+',';
					  pressImage("down",cmd);
					  g_EPTZ_type = "down";
					}
					
				}
			}
			else if(x1 > (JOYSTICK_MID + JOYSTICK_FIXNUM) )
			{//x-right
				if(y1 < (JOYSTICK_MID - JOYSTICK_FIXNUM) )
				{//y-top area
					//right-up
					if(g_EPTZ_type!="right_up"){
					  cmd = '';
					  for(i=0;i<CMD_UP_RIGHT.length;i++)
						cmd += CMD_UP_RIGHT[i]+',';
					  pressImage("right_up",cmd);
					  g_EPTZ_type = "right_up";
					}
					
				}
				else if(y1 >= (JOYSTICK_MID - JOYSTICK_FIXNUM) && y1 <= (JOYSTICK_MID + JOYSTICK_FIXNUM))
				{//y-middle area
					//right
					if(g_EPTZ_type!="right"){
					  cmd = '';
					  for(i=0;i<CMD_PAN_RIGHT.length;i++)
						 cmd += CMD_PAN_RIGHT[i]+',';
					  pressImage("right",cmd);
					  g_EPTZ_type = "right";
					}
					
				}
				else if(y1 > (JOYSTICK_MID + JOYSTICK_FIXNUM) )
				{//y-bottom area
					//right-down
					if(g_EPTZ_type!="right_down"){
					  cmd = '';
					  for(i=0;i<CMD_DOWN_RIGHT.length;i++)
					  {
						cmd += CMD_DOWN_RIGHT[i]+',';
					  }
					  pressImage("right_down",cmd);
					  g_EPTZ_type = "right_down";
					}
					
				}
			}
			
		
	  }
      else
      {	  
	    
		if(g_supportFishEye == 1 ||  g_supportfish_v2 == 1){		
			g_MouseNumX = parseInt(obj.GetJoystickFishMouseX());
			g_MouseNumY = (-1)*parseInt(obj.GetJoystickFishMouseY());
				   
			
			if(boxNum==0 && (g_MouseNumX!=0 && g_MouseNumY!=0) ) {
				boxNum=obj.GetBoxNumber();	
				
				SendHttpPublic("/cgi-bin/fisheye.cgi?direction=stop");
				if( g_supportfish_v2 == 1)
					SendHttpPublic("/cgi-bin/fisheye.cgi?winid=3&KeepDown=true&streamid=" + mpMode);
				else
					SendHttpPublic("/cgi-bin/fisheye.cgi?LmousedownX="+g_MouseNumX+"&LmousedownY="+g_MouseNumY+"&KeepDown=true&streamid="+mpMode);
			}						
			else{
			   		 	
					 
					if( boxNum!=obj.GetBoxNumber()  && (g_MouseNumX!=0 && g_MouseNumY!=0)  ){	
						
						SendHttpPublic("/cgi-bin/fisheye.cgi?direction=stop");

					   	 var org_x=0;
						 var org_y=0;
										   
						   boxNum=obj.GetBoxNumber();  //Change to new Boxnumber, do it first;
						   var resolu = l_profileresolution[mpMode-1].split('x');				
						 
						  if(boxNum==2){
								 
								if( fish_mode=="1O3R"|| fish_mode=="4R" || fish_mode=="1P2R" ){						
								 
									org_x=g_MouseNumX +(parseInt(resolu[0])/2)/2;
									org_y=(-1)*g_MouseNumY+(parseInt(resolu[1])/2)/2;						
									
								//	alert(org_x+","+org_y);
								}
								else if( fish_mode=="1R" || fish_mode=="2P"){
								
									org_x=g_MouseNumX +parseInt(resolu[0]/2);
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2);
								}
															
						   }
						
						   else if(boxNum==1){
						   
								if( fish_mode=="4R" || fish_mode=="1P2R" || fish_mode=="1O3R"){
								
									org_x=g_MouseNumX +parseInt(resolu[0]/2)*1.5;
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2)/2;
								}
								else if( fish_mode=="1R" ||  fish_mode=="2P"){
								
									org_x=g_MouseNumX +parseInt(resolu[0]/2);
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2);
								}																	
								
						   }  
						   else if(boxNum==4){
								if( fish_mode=="1O3R" || fish_mode=="4R" || fish_mode=="1P2R"){
								
									org_x= g_MouseNumX +parseInt(resolu[0]/2)*1.5;
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2)*1.5;
								}
								else if( fish_mode=="1R" ||  fish_mode=="2P"){
								
									org_x= g_MouseNumX +parseInt(resolu[0]/2);
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2);
								}								
													   
						   }
						   else if(boxNum==3){
								if( fish_mode=="1O3R" || fish_mode=="4R" ||  fish_mode=="1P2R"){
								
									org_x= g_MouseNumX +parseInt(resolu[0]/2)/2;
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2)*1.5;
								}
								else if( fish_mode=="1R" ||  fish_mode=="2P"){
								
									org_x= g_MouseNumX +parseInt(resolu[0]/2);
									org_y=(-1)*g_MouseNumY+parseInt(resolu[1]/2);
								}
													   
						   }								   					  
					    if( (boxNum==3 || boxNum==4)  && fish_mode=="1P2R"){
							g_MouseNumX=0;
							g_MouseNumY=0;
						}	
						else{
							if( g_supportfish_v2 == 1)
								SendHttpPublic("/cgi-bin/fisheye.cgi?winid=3&KeepDown=true&streamid=" + mpMode);
							else
								SendHttpPublic("/cgi-bin/fisheye.cgi?LmousedownX="+org_x+"&LmousedownY="+org_y+"&KeepDown=true&streamid="+mpMode);				  
						}	
						
					  	
					}   
					else if(boxNum==obj.GetBoxNumber()  && (g_MouseNumX!=0 && g_MouseNumY!=0) )
					{					  
					   
						if(boxNum==1 && fish_mode=="1O3R"){
							g_MouseNumX=0;
							g_MouseNumY=0;
						}	
						else if( (boxNum==3 || boxNum==4)  && fish_mode=="1P2R"){
							g_MouseNumX=0;
							g_MouseNumY=0;
						}
					}
					
			}			
			
		}		
		else{	  
			if(g_supportZbc==1)
				chkAXfocus();//  alt + mousewheel
			
			g_MouseNumX = parseInt(obj.GetJoystickMouseX());
			g_MouseNumY = (-1)*parseInt(obj.GetJoystickMouseY());
			//window.status = "MouseNumX="+g_MouseNumX+" MouseNumY="+g_MouseNumY;
        }
		
	    if(g_MouseNumX != 0 && g_MouseNumY != 0)
		{  
				
			if(g_supportFishEye == 1 || g_supportfish_v2 == 1){		
				//alert(g_EPTZ_type_FishTemp +","+ g_EPTZ_type_Fish);
				if(g_EPTZ_type_FishTemp != g_EPTZ_type_Fish){
				
					g_EPTZ_type_FishTemp = g_EPTZ_type_Fish;
					pressImage(g_EPTZ_type_Fish, true);
				}	
				else	
					EPTZMouseEventFish( g_MouseNumX, g_MouseNumY );			
			    	
			}	
			else
				EPTZMouseEvent( g_MouseNumX/4, g_MouseNumY/4 );
		}
	    else
		{
	    	if(g_EPTZ_type!="" || g_EPTZ_type_Fish!="")
			{ 
		      if (g_isSupportVisca==1  ){
		   		SendDLinkPTZStopCmd(CMD_PANTILT_STOP);//CMD_PANTILT_STOP, not include zoom stop			 				
			  }else{
				if(g_supportFishEye == 1 || g_supportfish_v2 == 1){			  			  				
					SendHttpPublic("/cgi-bin/fisheye.cgi?direction=stop");
				}else{
					if(g_supportZbc==1){
						SendHttpPublic("/vb.htm?setzbcstop=1");
					}else{
						SendDLinkPTZStopCmd();//stop
					}
				}
			  }
				
		   	  g_EPTZ_type = "";
			  g_EPTZ_type_Fish="";
		   	}
	    }
	  }
	  
	  if(g_supportFishEye == 1 || g_supportfish_v2 == 1)	
	  timerEPTZJoystick = setTimeout("StartEPTZWorker()",g_PTZ_TimeInterval_Fish);
	  else
	  timerEPTZJoystick = setTimeout("StartEPTZWorker()",g_PTZ_TimeInterval);
	}
  }
  else
  {
	//not IE
  }  
  
};

function EPTZMouseEventFish(x,y){
//calculate direct
	cmdtype = "";
	s = y/x;
	a = Math.atan(s)*180/3.14;
	//window.status = 'x= '+x+' y= '+y+ ' y/x= '+s+' angle= '+a;
	//var resolu = l_profileresolution[mpMode-1].split('x');
//	alert(x+","+y+","+s+","+a);
	if( x>0 )
	{
		if( fish_mode=="2P"){
			if(a>-90 && a<90){
				cmdtype = "right";			
			}	
		}		
		else{		
			//1
			if(a>0 && a<22.5)
				cmdtype = "right";
			else if(a>=22.5 && a<67.5)
				cmdtype = "right_up";
			else if(a>=67.5 && a<90)
				cmdtype = "up";
			//4
			else if(a<0 && a>-22.5)
				cmdtype = "right";
			else if(a<=-22.5 && a>-67.5)
				cmdtype = "right_down";
			else if(a<=-67.5 && a>-90)
				cmdtype = "down";		
		}	
		
	}
	else
	{
		if( fish_mode=="2P"){
			if(a>-90 && a<90)
				cmdtype = "left";
		}		
		else{		
			//3
			if(a>0 && a<22.5)
				cmdtype = "left";
			else if(a>=22.5 && a<67.5)
				cmdtype = "left_down";
			else if(a>=67.5 && a<90)
				cmdtype = "down";
			//2
			else if(a<0 && a>(-22.5))
				cmdtype = "left";
			else if(a<=-22.5 && a>-67.5)
				cmdtype = "left_up";
			else if(a<=-67.5 && a>-90)
				cmdtype = "up";
		}		
	}	
	g_EPTZ_type_Fish = cmdtype;

};

function EPTZMouseEvent(x,y){
//calculate direct
	cmdtype = "";
	s = y/x;
	a = Math.atan(s)*180/3.14;
	//window.status = 'x= '+x+' y= '+y+ ' y/x= '+s+' angle= '+a;
	
	if(x>0)
	{
		//1
		if(a>0 && a<22.5)
			cmdtype = "right";
		else if(a>=22.5 && a<67.5)
			cmdtype = "right_up";
		else if(a>=67.5 && a<90)
			cmdtype = "up";
		//4
		else if(a<0 && a>-22.5)
			cmdtype = "right";
		else if(a<=-22.5 && a>-67.5)
			cmdtype = "right_down";
		else if(a<=-67.5 && a>-90)
			cmdtype = "down";
	}
	else
	{
		//3
		if(a>0 && a<22.5)
			cmdtype = "left";
		else if(a>=22.5 && a<67.5)
			cmdtype = "left_down";
		else if(a>=67.5 && a<90)
			cmdtype = "down";
		//2
		else if(a<0 && a>(-22.5))
			cmdtype = "left";
		else if(a<=-22.5 && a>-67.5)
			cmdtype = "left_up";
		else if(a<=-67.5 && a>-90)
			cmdtype = "up";
	}
	
//--2010.12.29 calculate speed
	if (g_isSupportVisca==1)
	{
		rateX = Math.floor(g_viewXSize/320);
		rateY = Math.floor(g_viewYSize/240);
		oX = Math.floor(g_viewXSize/2/rateX/4);
		oY = Math.floor(g_viewYSize/2/rateY/4);
		psRateX = oX/15;//pan speed rate
		tsRateY = oY/15;//tile speed rate
		pspeed = Math.abs(Math.floor(x/psRateX));//pan speed
		tspeed = Math.abs(Math.floor(y/tsRateY));//tile speed
		
		//window.status = 'rateX= '+rateX+' rateY= '+rateY;
		//window.status = 'oX= '+oX+' oY= '+oY;
		window.status = 'pspeed= '+pspeed+' tspeed= '+tspeed;
		if(visca_panspeed!=null)
		{
			visca_panspeed.SV( pspeed<=15 ? pspeed : 15 );
			OnClickSpeed("panspeed");		
		}
		if(visca_tiltspeed!=null)
		{
			visca_tiltspeed.SV( tspeed<=15 ? tspeed : 15 );
			OnClickSpeed("tiltspeed");
		}
	}
//--2010.12.29
	
//--start 2011.4.18 modified, send command
	if (g_isSupportVisca==1)
	{
		if (cmdtype!=g_EPTZ_type)
			pressImage(cmdtype, true);
	}
	else
	{
		pressImage(cmdtype, true);
	}
	g_EPTZ_type = cmdtype;
//--end 2011.4.18
};

function OnClickSpeed(type)
{
	if(type=="panspeed")
	{
		SendHttpPublic(c_iniUrl+"&setvspanspeed="+visca_panspeed.GV());
	}
	else
	if(type=="tiltspeed")
	{
		SendHttpPublic(c_iniUrl+"&setvstiltspeed="+visca_tiltspeed.GV());
	}
}

function OnClickZbcSpeed(type)
{
	
	if(type=="panspeed")
	{
		SendHttpPublic(c_iniUrl+"&"+zbc_panspeed.setcmd+zbc_panspeed.GV());
	}
	else
	if(type=="tiltspeed")
	{
		SendHttpPublic(c_iniUrl+"&"+zbc_tiltspeed.setcmd+zbc_tiltspeed.GV());
	}
	else
	if(type=="zoomspeed")
	{
		SendHttpPublic(c_iniUrl+"&"+zbc_zoomspeed.setcmd+zbc_zoomspeed.GV());
	}
	else
	if(type=="focusspeed")
	{
		SendHttpPublic(c_iniUrl+"&"+zbc_focusspeed.setcmd+zbc_focusspeed.GV());
	}
}

function OnClickHisiSpeed(type)
{
	
	if(type=="panspeed")
	{ 
			if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
				SendHttpPublic("/cgi-bin/longcctvspdstp.cgi?" + CTRLARY["hisi_panspeed"].setcmd + CTRLARY["hisi_panspeed"].GV(),false);
			else
				SendHttpPublic("/cgi-bin/longcctvspdstp.cgi?panstep="  + CTRLARY["hisi_panspeed"].GV(),false);	
	}		
	else
	if(type=="tiltspeed")
	{
		if(g_longcctvmovemode==0 && g_support_longcctv_cont==1)
			SendHttpPublic("/cgi-bin/longcctvspdstp.cgi?" + CTRLARY["hisi_tiltspeed"].setcmd + CTRLARY["hisi_tiltspeed"].GV(),false);
		else
			SendHttpPublic("/cgi-bin/longcctvspdstp.cgi?tiltstep="+ CTRLARY["hisi_tiltspeed"].GV(),false);
	}	
	else
	if(type=="autospeed")
	{
		SendHttpPublic("cgi-bin/longcctvspdstp.cgi?" + hisi_autopanspeed.setcmd+  hisi_autopanspeed.GV(),false);
	}
	else
	if(type=="dwelltimespeed")
	{
		SendHttpPublic("/cgi-bin/longcctvseq.cgi?action=set&dwelltime="+hisi_seqspeed.GV(),false);
	}
}

function sendCont()
{
	SendHttpPublic("/cgi-bin/longcctvmovemode.cgi?mode=0",false,onChangeSpeedMode);
	g_longcctvmovemode=0;
	
	GE("ptzpanSpeedtitle").innerHTML=GL("ptz_panspeed");
	GE("ptztiltSpeedtitle").innerHTML=GL("ptz_tiltespeed");
	 ChangeImg("img_continue","Continuous_on.gif");   
	 ChangeImg("img_step","step_off.gif");

}

function sendStep()
{
	SendHttpPublic("/cgi-bin/longcctvmovemode.cgi?mode=1",false,onChangeSpeedMode);
	g_longcctvmovemode=1;
	
	GE("ptzpanSpeedtitle").innerHTML=GL("ptz_panstep");
	GE("ptztiltSpeedtitle").innerHTML=GL("ptz_tiltstep");
	ChangeImg("img_continue","Continuous_off.gif"); 
    ChangeImg("img_step","step_on.gif");

}

var g_SubmitHttpPublic=null;
function onChangeSpeedMode()
{
	  if (g_SubmitHttpPublic.readyState == 4)
	  {
		if (g_SubmitHttpPublic.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else 
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			
			if(g_longcctvmovemode==0)
				SendHttpPublic("vb.htm?paratest=contpanspeedname", false, onChangeContPanSpeedName);
			else
				SendHttpPublic("vb.htm?paratest=steppanstepname", false, onChangeContPanSpeedName);
		}
	  }

}

function onChangeContPanSpeedName(){
  var list;

  if (g_SubmitHttpPublic.readyState == 4)
  {
  	if (g_SubmitHttpPublic.status != 200)
	{
  		alert(GL("err_submit_fail"));
  		g_httpOK = false;
  		WS(GL("fail_"));
  	}
  	else 
	{
  		g_httpOK = true;
  		WS(GL("ok_"));
  		
		list = g_SubmitHttpPublic.responseText;
		list = list.substring(0,list.length-1);
		list = list.split("=");
  		g_longpanspeedname = list[1];		  		
		
		if(g_longcctvmovemode==0)
			SendHttpPublic("vb.htm?paratest=contpanspeed", false, onChangeContPanSpeed);
		else
			SendHttpPublic("vb.htm?paratest=steppanstep", false, onChangeContPanSpeed);
  	}
  }
}

function onChangeContPanSpeed(){
  var list;

  if (g_SubmitHttpPublic.readyState == 4)
  {
  	if (g_SubmitHttpPublic.status != 200)
	{
  		alert(GL("err_submit_fail"));
  		g_httpOK = false;
  		WS(GL("fail_"));
  	}
  	else 
	{
  		g_httpOK = true;
  		WS(GL("ok_"));
  		
		list = g_SubmitHttpPublic.responseText;
		list = list.substring(0,list.length-1);
		list = list.split("=");
  		g_longpanspeed = list[1];		
  		
		onChangePanSpeedList();
  	}
  }
}



function onChangePanSpeedList()
{  
		
	var divObj = GE("hisi_panspeedDiv");
	if(divObj!=null)
		divObj.innerHTML = CTRLARY["hisi_panspeed"].rehtml(g_longpanspeedname,g_longpanspeed);	
		
		if(g_longcctvmovemode==0)
			SendHttpPublic("vb.htm?paratest=conttiltspeedname", false, onChangeContTiltSpeedName);
		else
			SendHttpPublic("vb.htm?paratest=steptiltstepname", false, onChangeContTiltSpeedName);
			
}

function onChangeContTiltSpeedName(){
  var list;

  if (g_SubmitHttpPublic.readyState == 4)
  {
  	if (g_SubmitHttpPublic.status != 200)
	{
  		alert(GL("err_submit_fail"));
  		g_httpOK = false;
  		WS(GL("fail_"));
  	}
  	else 
	{
  		g_httpOK = true;
  		WS(GL("ok_"));
  		
		list = g_SubmitHttpPublic.responseText;
		list = list.substring(0,list.length-1);
		list = list.split("=");
  		g_longtiltspeedname = list[1];		  		
		
		if(g_longcctvmovemode==0)
			SendHttpPublic("vb.htm?paratest=conttiltspeed", false, onChangeContTiltSpeed);
		else
			SendHttpPublic("vb.htm?paratest=steptiltstep", false, onChangeContTiltSpeed);
  	}
  }
}

function onChangeContTiltSpeed(){
  var list;

  if (g_SubmitHttpPublic.readyState == 4)
  {
  	if (g_SubmitHttpPublic.status != 200)
	{
  		alert(GL("err_submit_fail"));
  		g_httpOK = false;
  		WS(GL("fail_"));
  	}
  	else 
	{
  		g_httpOK = true;
  		WS(GL("ok_"));
  		
		list = g_SubmitHttpPublic.responseText;
		list = list.substring(0,list.length-1);
		list = list.split("=");
  		g_longtiltspeed = list[1];		
  		
		onChangeTiltSpeedList();
  	}
  }
}



function onChangeTiltSpeedList()
{  
		
	var divObj = GE("hisi_tiltspeedDiv");
	if(divObj!=null)
		divObj.innerHTML = CTRLARY["hisi_tiltspeed"].rehtml(g_longtiltspeedname,g_longtiltspeed);	
}

function resetPanSeqIcon()
{
	if( g_supportfish_v2 ){
		SendHttpPublic("/vb.htm?paratest=fisheyepanstatus",false,setpanIcon);	
		SendHttpPublic1("/vb.htm?paratest=fisheyeseqstatus",false,setseqIcon);
	}	
	else{
	
		GE("img_pan").src="pan-off_n.gif"; 
		GE("img_seq").src="seq-off_n.gif";
	}	
}

function setpanIcon()
{
	var list='';

	if (g_SubmitHttpPublic.readyState == 4)
	{
		if (g_SubmitHttpPublic.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			list = g_SubmitHttpPublic.responseText;
			list = list.substring(0,list.length-1);
			list = list.split("=");
			
			
			if(parseInt(list[1])==0 && GE("img_pan")!=null){
				GE("img_pan").src="pan-off_n.gif"; 			
				clearTimeout(clearCheckpan_seqStop);
			}	
		}
	}
}


function setseqIcon()
{
	var list='';

	if (g_SubmitHttpPublic1.readyState == 4)
	{
		if (g_SubmitHttpPublic1.status != 200)
		{
			alert(GL("err_submit_fail"));
			g_httpOK = false;
			WS(GL("fail_"));
		}
		else
		{
			g_httpOK = true;
			WS(GL("ok_"));
			
			list = g_SubmitHttpPublic1.responseText;
			list = list.substring(0,list.length-1);
			list = list.split("=");
			
			if(parseInt(list[1])==0 && GE("img_seq")!=null){
				GE("img_seq").src="seq-off_n.gif";
				clearTimeout(clearCheckpan_seqStop);
			}	
		}
	}
}




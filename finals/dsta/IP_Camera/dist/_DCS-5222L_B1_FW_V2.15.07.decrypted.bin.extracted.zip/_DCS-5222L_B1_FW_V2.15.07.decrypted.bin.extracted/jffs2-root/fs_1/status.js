var MENU_ITEM_STATUS = new Array(
"status_menu_decive","status_info.htm",1,
"status_menu_log",(g_supportlogv2==0?"status_log.htm":"status_log2.htm"),1,
"checkout","checkout.htm",1);
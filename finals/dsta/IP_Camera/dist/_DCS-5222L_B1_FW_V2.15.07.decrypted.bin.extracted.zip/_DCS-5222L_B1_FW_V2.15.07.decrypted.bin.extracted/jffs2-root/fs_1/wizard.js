//wizard_internet_setup2.htm 
var t_lanRadio=GV("<%dhcpenable%>",0);
var g_dhcpen = t_lanRadio;//temp dhcp status
var t_lanipaddress="<%netip%>";
var g_lanipaddress=t_lanipaddress;//temp ip
var t_lansubnetmask="<%netmask%>";
var t_defaultgateway="<%gateway%>";
var t_primarydns="<%dnsip%>";
var t_secondarydns="<%secondarydnsip%>";
//wizard_internet_setup3.htm
var t_enpppoe="<%pppoeenable%>";
var g_enpppoe=t_enpppoe;//temp pppoe
var t_pppoeusername="<%pppoeaccount%>";
var t_pppoepassword="";
var t_repassword='';
//wizard_internet_setup4.htm
var t_enddns="<%ddnsenable%>";
var t_serveraddress='';
var t_serveraddress2="<%ddnstype%>";
var t_hostname="<%ddnshostname%>";
var t_ddnsusername="<%ddnsaccount%>";
var t_ddnspassword="";
var t_verifypassword='';
var t_timeout="<%ddnsinterval%>";
var t_provider = GV("<%ddnsprovider%>","www.dlinkddns.com");		//2014.08.07
var t_servername = GV("<%ddnsservername%>","");		//2014.08.07
//wizard_internet_setup5.htm
var v_deviceName=GV("<%title%>","VideoServer");
//wizard_internet_setup6.htm
var t_timezone="<%wintimezone%>";
var t_endaylight=GV("<%daylight%>");

//wizard_ipcam_setup2.htm
var t_envideomotion=parseInt(GV("<%motionenable%>"));
var t_sensitivitytxt=parseInt(GV("<%motioncvalue%>",12));
var t_percentagetxt=parseInt(GV("<%motionpercentage%>",0));
var t_createmediatxt;
var t_typeradio;
var t_motion;
//wizard_ipcam_setup3.htm
var t_createeventtxt;
var t_daylist;
var t_schedulemode;
var t_timelist;
//wizard_ipcam_setup4.htm
var t_servertype;
var t_createservertxt;
function WizardSarat(width)
{
	var g_titleNameSub = CutString(g_titleName, 55);
  var o='';
  o+='<table id="header_container" align="center" cellpadding="5" cellspacing="0" width="900" ><tr>';
  o+='<td><span id="header_text" >'+GL("product")+':'+g_titleNameSub+'</span></td>';
  o+='<td align="right" nowrap="nowrap" >&nbsp;</td>';
  o+='<td align="right" nowrap="nowrap" ><span id="header_text" >'+GL("firmware_version")+': '+g_softwareversion+'</span></td>';
  o+='</tr></table>';
  if(g_oemname=='etisalat' )
	o+='<table style="width:900;" align="center" bgcolor="#ffffff" ><td align="center" ><img src="Egypt92.gif" width="896" height="92" ></table>'
  else
	o+='<table style="width:900;" align="center" bgcolor="#ffffff" ><td align="center" ><img src="dlink.gif" width="896" height="92" ></table>'
  o+='<table style="width:900;height:450;"  align="center" bgcolor="#ffffff"><tr><td valign="top" align="center" >';
  return o;
};
function WizardEnd()
{
  var o='';
  o+='</td></tr><table id="footer_container" width="900" align="center"><tr>';
  o+='<td width="155" align="center">&nbsp;&nbsp;<img src="wireless_bottom.gif" width="114" height="35"></td>';
  //o+='<td width="10">&nbsp;</td>';
  o+='<td>&nbsp;</td>';
  o+='</tr></table>';
  o+='<br><div align="center">Copyright &copy; '+ CopyrightYear +' D-Link Corporation.</div><br>';
  return o;
};

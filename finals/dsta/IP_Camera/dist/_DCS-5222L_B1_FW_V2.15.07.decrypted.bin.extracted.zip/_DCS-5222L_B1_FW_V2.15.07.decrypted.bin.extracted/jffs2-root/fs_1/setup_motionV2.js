
function MotionFetcher(){
	var selfMotion = this;
	this.width;
	this.height;

	this.xBlock = 32;
	this.yBlock = 16;

	this.totalBlock = this.xBlock*this.yBlock;
	this.maxWindow = 1;
	this.BlockArry = new Array();
	this.DrawBoxXY_WH = new Array(); // x0:y0, w,h
	this.OriginalBlock = new Array();
	
	this.blockWidth;
	this.blockHeight;	
	//image canvas
	this.cv;
	this.ctx;
	this.image;
	//draw canvas
	this.canvas;
	this.context;
	this.canvaso;
	this.contexto;
	// The active tool instance.
	this.tool;
	this.timer;
	this.timerStatus;
	this.nowWindowId = 0;
	
	this.initEvent = function() {
		this.blockWidth = this.width / this.xBlock;
		this.blockHeight = this.height / this.yBlock;
		
		var img  = document.getElementById("motionView");  //add 2012.06.12
		// Add the temporary canvas.
		var container = img.parentNode;   //add 2012.06.12
		//var container = this.cv.parentNode;
		
		//temporary canvas
		this.canvaso = document.createElement('canvas');
		if (!this.canvaso) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvaso.id     = 'motionTemp';
		//this.canvaso.width  = this.cv.width;
		//this.canvaso.height = this.cv.height;
		this.canvaso.width  = this.width;
		this.canvaso.height = this.height;
		container.appendChild(this.canvaso);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvaso);//==================================<<<ie only 
		this.contexto = this.canvaso.getContext('2d');
		
		
	//temporary canvas1.
		this.canvas = document.createElement('canvas');
		if (!this.canvas) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvas.id     = 'motionTemp1';
		//this.canvas.width  = this.cv.width;
		//this.canvas.height = this.cv.height;
		this.canvas.width  = this.width;
		this.canvas.height = this.height;
		container.appendChild(this.canvas);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvas);//=====================================<<<ie only 
		this.context = this.canvas.getContext('2d');		
		this.context.lineWidth = "1";
		this.context.strokeStyle = "rgb(124, 252, 0)";//Lawn Green

		// rect tool instance.
		this.tool = new this.toolMotion();
		
		// Attach the mousedown, mousemove and mouseup event listeners.
		if(this.canvas.addEventListener)
		{	// all browsers except IE before version 9
			this.canvas.addEventListener('mousedown', this.ev_canvas, false);
			this.canvas.addEventListener('mousemove', this.ev_canvas, false);
			this.canvas.addEventListener('mouseup',   this.ev_canvas, false);
			this.canvas.addEventListener('mouseout',  this.ev_canvas, false);
		}
		else
		{
			if (this.canvas.attachEvent)
			{	 // IE before version 9 
			
				this.canvas.attachEvent('onmousedown', this.ev_canvas);
				this.canvas.attachEvent('onmousemove', this.ev_canvas);
				this.canvas.attachEvent('onmouseup',   this.ev_canvas);
				this.canvas.attachEvent('onmouseleave',  this.ev_canvas);
			}
		}
	};
	// The general-purpose event handler. This function just determines the mouse 
	// position relative to the canvas element.
	this.ev_canvas = function(ev) {

		if(browser.FireFox){
			ev._x = ev.layerX;
			ev._y = ev.layerY;		
		}			
		else {
			ev._x = ev.offsetX;
			ev._y = ev.offsetY;
		}		// Call the event handler of the tool.
		var eventfunc = selfMotion.tool[ev.type];
		if (eventfunc) {
			eventfunc(ev);
		}
	};
	
	// This function draws the #motionTemp canvas on top of #motionView, after which 
	// #motionTemp is cleared. This function is called each time when the user 
	// completes a drawing operation.
	this.updateCanvas = function() {
		this.contexto.drawImage(this.canvas, 0, 0);		
		
	};	
	
	this.drawBlock = function(blockx, blocky){
		var x1 = blockx * this.blockWidth,
			y1 = blocky * this.blockHeight,
			x2 = x1 + this.blockWidth,
			y2 = y1 + this.blockHeight;
			
		this.context.strokeRect(x1, y1, this.blockWidth, this.blockHeight);
		this.context.beginPath();
		this.context.moveTo(x1, y1);
		this.context.lineTo(x2, y2);
		this.context.stroke();
		this.context.closePath();
	};
	this.initialWindowSize = function(num){	
		
		this.maxWindow = num;	
		
		this.BlockArry = new Array(num);
		for(var i = 0; i<num; i++)
			this.BlockArry[i] = new Array(this.xBlock);
			
		for(var i = 0; i < num; i++)
			for(var j = 0; j < this.xBlock; j++)
				this.BlockArry[i][j] = new Array(this.yBlock);

	};
	
	// The motion tool.
	this.toolMotion = function() {
		var selfTool = this;
		this.started = false;		

		this.mousedown = function (ev) {
			if (ev.button == 2 || ev.button == 3) 
				return false;

				selfTool.started = true;

			selfTool.x0 = Math.floor(ev._x / selfMotion.blockWidth);
			selfTool.y0 = Math.floor(ev._y / selfMotion.blockHeight);			
			selfMotion.drawBlock(selfTool.x0, selfTool.y0); 
						
		};

		this.mousemove = function (ev) {
			if (!selfTool.started) {
				return;
			}
			
			selfTool.x1 = Math.floor(ev._x / selfMotion.blockWidth);
			selfTool.y1 = Math.floor(ev._y / selfMotion.blockHeight);
			
			var x = Math.min(selfTool.x1,  selfTool.x0),
				y = Math.min(selfTool.y1,  selfTool.y0),
				w = Math.abs(selfTool.x1 - selfTool.x0)+1,
				h = Math.abs(selfTool.y1 - selfTool.y0)+1;
			if (w==0 && h==0) {
				return;
			}
			
			
			var i,j;
			for(i=0; i<w; i++){
				for(j=0; j<h; j++){
					selfMotion.drawBlock(x+i, y+j); 
					
				}
			}
		};

		this.mouseup = function (ev) {
			if (selfTool.started) {
				selfTool.mousemove(ev);
				selfTool.started = false;
				selfMotion.updateCanvas(); 
				
				selfTool.x1 = Math.floor(ev._x / selfMotion.blockWidth);
				selfTool.y1 = Math.floor(ev._y / selfMotion.blockHeight);
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
	
				
				var _w = ((selfTool.x1 - selfTool.x0 ) == 0 ? 1 : (selfTool.x1 - selfTool.x0 +1) );
				var _h = ((selfTool.y1 - selfTool.y0 ) == 0 ? 1 : (selfTool.y1 - selfTool.y0 +1) )				
								
				selfMotion.nowWindowId++;
				
				if( selfMotion.nowWindowId > selfMotion.maxWindow ){		
				
					var Idnum = (selfMotion.nowWindowId % selfMotion.maxWindow) ;				
					
					if( Idnum == 0)
						Idnum = selfMotion.maxWindow;
						
						
					selfMotion.ClearSingleBlockFlag(Idnum - 1);
					//reset Array data
					selfMotion.DrawBoxXY_WH[Idnum - 1] = Idnum + ":" + selfTool.x0 + ":" + selfTool.y0 + ':' + _w + ':' + _h;
					
					//redraw Block
					
					for(var j = 0; j < selfMotion.maxWindow; j++)
						selfMotion.windowModeSetBlock(j);
						
				}
				else
					selfMotion.DrawBoxXY_WH[selfMotion.nowWindowId - 1 ] = selfMotion.nowWindowId + ":" + selfTool.x0 + ":" + selfTool.y0 + ':' + _w + ':' + _h;
				
			}			
			
		};
		
		this.mouseout = function (ev) {
			if (selfTool.started) {
				selfTool.started = false;
				selfMotion.updateCanvas(); 
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
				
				var i,j;
				for(i=0; i<w; i++){
					for(j=0; j<h; j++){
						selfMotion.BlockArry[(y+j)*selfMotion.xBlock+(x+i)] = 1;
					}
				}
			}
		};
	};
	
	this.Loop = function(){
		selfMotion.image.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();
	};
	
//Those are public function

	this.GenHtml = function(width, height){
		o = '';
		o += '<div id="MotionContainer">';   // oncontextmenu="return false;" change
			o += '<img id="motionView" width="'+width+'" height="'+height+'" src="/Loading.gif"/>'; //add 2012.06.12
			//o += '<canvas id="motionView" width="'+width+'" height="'+height+'"></canvas>';
		o += '</div>';		
		this.width = width;
		this.height = height;	
		return o;
	};	
	
	this.Start = function(){	
		this.timerStatus = true;		
		this.image = new Image();
		this.image.onload = function(){
			if(!selfMotion.timerStatus)
				return;
				
			var imgobj = GE("motionView");  

			imgobj.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();	  //add 2012.06.12
			
			
			selfMotion.timer = setTimeout(selfMotion.Loop, 4000);
		};
		this.Loop();
		
		this.initEvent();
		
	};
	
	this.Stop = function() {
		
		this.BlockArry = [];
		this.DrawBoxXY_WH = []; // x0:y0, w,h
		this.OriginalBlock = [];
		
		this.timerStatus = false;
		clearTimeout(this.timer);
	};

	this.setData = function(data){
		
		var sp_window = data.split("*");		
				
		for(var i = 0; i < sp_window.length; i++){	

			if( sp_window[i] == "")
				continue;
				
			this.DrawBoxXY_WH.push(sp_window[i]);
			this.OriginalBlock.push(sp_window[i]);
		}	
	
		for(var j = 0; j < sp_window.length; j++){ // draw block;
		
			if( sp_window[j] == "")
				continue;
			this.windowModeSetBlock(j);
		}	
	};	
	
	this.setOriginalBlcok = function(){
		this.ClearBlockFlag();
		
		for(var i = 0; i < this.OriginalBlock.length; i++){
			this.DrawBoxXY_WH[i] = this.OriginalBlock[i];			
			this.windowModeSetBlock (i);
		}	
	
	};
	this.windowModeSetBlock = function(Id){
		
		var sp_pos = this.DrawBoxXY_WH[Id].split(":");
		
		var _x_start = sp_pos[1];
		var _x_end = parseInt(sp_pos[1], 10) + parseInt(sp_pos[3], 10) ;
		var _y_start = sp_pos[2];
		var _y_end = parseInt(sp_pos[2], 10) + parseInt(sp_pos[4], 10);
	
	
		for(var m = _x_start; m < _x_end; m++)
			for(var n = _y_start; n < _y_end; n++)
				this.BlockArry[Id][m][n] = 1;
		
		
		for(var m = _x_start; m < _x_end; m++)
			for(var n = _y_start; n < _y_end; n++)
				this.drawBlock(m, n);			
			
		selfMotion.nowWindowId++;	
				
		
		this.updateCanvas();
	};
	
	
	this.windowModeGetBlockFlag = function(){
		var o = "";
		for(var i = 0; i < this.DrawBoxXY_WH.length; i++){
		
			if(this.DrawBoxXY_WH[i] == "" || this.DrawBoxXY_WH[i] == "undefined" || this.DrawBoxXY_WH[i] == null)
				continue;
				
			if( i == 0)
				o+= this.DrawBoxXY_WH[i];	
			else
				o+= "*" + this.DrawBoxXY_WH[i];	
		}
					
		return o;
	};

	
	this.ClearBlockFlag = function(){
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		
		for(var i=0; i<this.maxWindow; i++){
			for(var j=0; j<this.xBlock; j++)
				for(var k=0; k<this.yBlock; k++)
					this.BlockArry[i][j][k] = 0;
		}
		
		for(var q=0; q<this.maxWindow; q++)
			this.DrawBoxXY_WH[q] = null;
			
		this.nowWindowId = 0;	
		
	};
	
	this.ClearSingleBlockFlag = function(Id){	
		
		var sp_pos = this.DrawBoxXY_WH[Id].split(":");
		//-----------------------------------------------------------
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		
		//-----------------------------------------------------------
		var _x_start = sp_pos[1];
		var _x_end = parseInt(sp_pos[1], 10) + parseInt(sp_pos[3], 10) ;
		var _y_start = sp_pos[2];
		var _y_end = parseInt(sp_pos[2], 10) + parseInt(sp_pos[4], 10);
	
	
		for(var m = _x_start; m < _x_end; m++)
			for(var n = _y_start; n < _y_end; n++){
				this.BlockArry[Id][m][n] = 0;
				
			}
		
		this.updateCanvas();
	};
	
	this.SelectAllBlockFlag = function(){
	
		this.ClearBlockFlag();
	
		for(var i=0; i<this.maxWindow; i++){
		
			for(var j=0; j<this.xBlock; j++){
				for(var k=0; k<this.yBlock; k++){
					this.BlockArry[i][j][k] = 1;					
				
					if( i == 0)
						this.drawBlock(j, k);
				}
			}	
		}	
		
		
		this.DrawBoxXY_WH[0] = "1:0:0:32:16";
		
		this.updateCanvas();
	} 
};

//var motionlive = new MotionFetcher();

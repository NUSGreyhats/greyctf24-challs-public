var Focuslive = new FocusFetcher();

function FocusFetcher(){
	var m_IsSupportHisi;
	var m_autofocusmode;
	var selfFocus = this;
	this.width;
	this.height;

	//image canvas
	this.cv;
	this.ctx;
	this.image;
	//draw canvas
	this.canvas;
	this.context;
	this.canvaso;
	this.contexto;
	// The active tool instance.
	this.tool;
	this.timer;
	this.timerStatus;
	var mwidth0	,mheight0 ,mwidth1	,mheight1 ,mwidth2,mheight2;
	var mFlag=0;	
	var isUsed="0";	
	
	this.initEvent = function() {
	mwidth0 =	this.width;
	mheight0 = this.height;
	mwidth1 = Math.floor(this.width / 3);
	mheight1 = Math.floor(this.height / 3);
	mwidth2 = Math.floor(this.width / 3 * 2);
	mheight2 = Math.floor(this.height / 3 * 2);
	

	
		var img  = document.getElementById("FocusView");  //add 2012.06.12
		// Add the temporary canvas.
		var container = img.parentNode;   //add 2012.06.12
		//var container = this.cv.parentNode;
		
		//temporary canvas
		this.canvaso = document.createElement('canvas');
		if (!this.canvaso) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvaso.id     = 'FocusTemp';
		this.canvaso.width  = this.width;
		this.canvaso.height = this.height;
		container.appendChild(this.canvaso);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvaso);//==================================<<<ie only 
		this.contexto = this.canvaso.getContext('2d');
		this.contexto.lineWidth = "3";
		//this.contexto.strokeStyle = "rgb(124, 252, 0)";//Lawn Green
		this.contexto.strokeStyle = "red";//Lawn Green
		
		
	//temporary canvas1.
		this.canvas = document.createElement('canvas');
		if (!this.canvas) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvas.id     = 'FocusTemp1';
		//this.canvas.width  = this.cv.width;
		//this.canvas.height = this.cv.height;
		this.canvas.width  = this.width;
		this.canvas.height = this.height;
		container.appendChild(this.canvas);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvas);//=====================================<<<ie only 
		this.context = this.canvas.getContext('2d');		
		this.context.lineWidth = "3";
		//this.context.strokeStyle = "rgb(124, 252, 0)";//Lawn Green
		this.context.strokeStyle = "red";//Lawn Green

		// rect tool instance.
		this.tool = new this.toolFocus();
		
		// Attach the mousedown, mousemove and mouseup event listeners.
		if(this.canvas.addEventListener)
		{	// all browsers except IE before version 9
			this.canvas.addEventListener('mousedown', this.ev_canvas, false);
		//	this.canvas.addEventListener('mousemove', this.ev_canvas, false);
		//	this.canvas.addEventListener('mouseup',   this.ev_canvas, false);
		//	this.canvas.addEventListener('mouseout',  this.ev_canvas, false);
		}
		else
		{
			if (this.canvas.attachEvent)
			{	 // IE before version 9 
			
				this.canvas.attachEvent('onmousedown', this.ev_canvas);
			//	this.canvas.attachEvent('onmousemove', this.ev_canvas);
			//	this.canvas.attachEvent('onmouseup',   this.ev_canvas);
			//	this.canvas.attachEvent('onmouseleave',  this.ev_canvas);
			}
		}
	};
	// The general-purpose event handler. This function just determines the mouse 
	// position relative to the canvas element.
	this.ev_canvas = function(ev) {	
			if(browser.FireFox){
				ev._x = ev.layerX;
				ev._y = ev.layerY;		
			}			
			else {
				ev._x = ev.offsetX;
				ev._y = ev.offsetY;
			}
		// Call the event handler of the tool.
		var eventfunc = selfFocus.tool[ev.type];
		if (eventfunc) {
			eventfunc(ev);
		}
	};
	
	// This function draws the #FocusTemp canvas on top of #FocusView, after which 
	// #FocusTemp is cleared. This function is called each time when the user 
	// completes a drawing operation.
	this.updateCanvas = function() {
		this.contexto.drawImage(this.canvas, 0, 0);		
	};	
	
	this.drawBlock = function(x,y,x1,y1){
		this.context.strokeRect(x,y,x1,y1);
	};	
	// The Focus tool.
	this.toolFocus = function() {
		var selfTool = this;
		this.started = false;
		
		this.mousedown = function (ev) {
		
		if(isUsed=="1")
		  return false;
		selfFocus.ClearBlockFlag();
		
		if (ev.button == 2 || ev.button == 3) {
			return false;
        }
		//alert(m_autofocusmode);
		if(m_autofocusmode==0)
			return false;
			
			selfTool.started = true;

			selfTool.x0 = Math.floor(ev._x );
			selfTool.y0 = Math.floor(ev._y);	

			var x,y,w,h;
			
			if(selfTool.x0 < mwidth2)
			{
				if(selfTool.x0 < mwidth1)
				{
					x=0;
					w=mwidth1;
					
					if(selfTool.y0 < mheight2)
					{
						if(selfTool.y0 < mheight1)
						{
							y=0;
							h= mheight1;
							mFlag = 1;
						}
						else
						{
							y=mheight1;
							h = mheight2 - mheight1 ;
							mFlag = 4;
						}
					}
					else
					{
						y=mheight2;
						h = mheight0 - mheight2 ;
						
						mFlag = 7;
					}
				}
				else
				{
					x=	mwidth1;
					w=	mwidth2 - mwidth1;
					if(selfTool.y0 < mheight2)
					{
						if(selfTool.y0 < mheight1)
						{
							y=0;
							h= mheight1;
							mFlag = 2;
						}
						else
						{
							y=mheight1;
							h = mheight2 - mheight1 ;
							mFlag = 5;
						}
					}
					else
					{
						y=mheight2;
						h = mheight0 - mheight2 ;
						mFlag = 8;
					}
				}
			}
			else
			{
				x=	mwidth2;
				w=	mwidth0 - mwidth2;
				if(selfTool.y0 < mheight2)
				{
					if(selfTool.y0 < mheight1)
					{
						y=0;
						h= mheight1;
						mFlag = 3;
					}
					else
					{
						y=mheight1;
						h = mheight2 - mheight1 ;
						mFlag = 6;
					}
				}
				else
				{
					y=mheight2;
					h = mheight0 - mheight2 ;
					mFlag = 9;
				}
			}			
			selfFocus.drawBlock(x, y,w,h); 	
			//SendHttp2("cgi-bin/lencontrol.cgi?autofocuslocation="+	mFlag);
		};

};
	
	this.Loop = function(){
		selfFocus.image.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();
	};
	
//Those are public function
	
	this.GenHtml = function(width, height){
		o = '';
		o += '<div id="FocusContainer">';   // oncontextmenu="return false;" change
			o += '<img id="FocusView" width="'+width+'" height="'+height+'" src="/Loading.gif"/>'; //add 2012.06.12
		o += '</div>';		
		this.width = width;
		this.height = height;	
		
		return o;
	};	
	
	this.Start = function(){	
		this.timerStatus = true;
		
		this.image = new Image();
		this.image.onload = function(){
			if(!selfFocus.timerStatus)
				return;
				
			var imgobj = GE("FocusView");  //add 2012.06.12
//			imgobj.src = selfFocus.image.src;	  //add 2012.06.12
			imgobj.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();	  //add 2012.06.12
					
			selfFocus.timer = setTimeout(selfFocus.Loop, 330);
		};
		this.Loop();
		
		this.initEvent();
		
	};
	
	this.Stop = function() {
		this.timerStatus = false;
		clearTimeout(this.timer);
	};
	
	this.GetBlockFlag = function(){
		return mFlag;
	};
	this.SetBoxFlag = function(flag){
		var x,y,w,h;
		var swidth0 = this.canvaso.width;
		var sheight0 = this.canvaso.height;
		var swidth1 = Math.floor(this.canvaso.width / 3);
		var sheight1 = Math.floor(this.canvaso.height / 3);
		var swidth2 = Math.floor(this.canvaso.width / 3 * 2);
		var sheight2 = Math.floor(this.canvaso.height / 3 * 2);

		if(flag==1){
			x= 0;
			y= 0;
			w= swidth1;
			h= sheight1;
		}
		else if(flag==2){
			x= swidth1;
			y= 0;
			w= swidth2 - swidth1;
			h= sheight1;		
		}
		else if(flag==3){
			x= swidth2;
			y= 0;
			w= swidth0 - swidth2;
			h= sheight1;	
		}
		else if(flag==4){
			x= 0;
			y= sheight1;
			w= swidth1;
			h= sheight2 - sheight1;
		}
		else if(flag==5){
			x= swidth1;
			y= sheight1;
			w= swidth2 - swidth1;
			h= sheight2 - sheight1;
		}
		else if(flag==6){
			x= swidth2;
			y= sheight1;
			w= swidth0 - swidth2;
			h= sheight2 - sheight1;
		}
		else if(flag==7){	
			x= 0;
			y= sheight2;
			w= swidth1;
			h= sheight0 -sheight2;
		}
		else if(flag==8){
			x= swidth1;
			y= sheight2;
			w= swidth2 - swidth1;
			h= sheight0 -sheight2;
		}
		else if(flag==9){
			x= swidth2;
			y= sheight2;
			w= swidth0 - swidth2;
			h= sheight0 -sheight2;
		}		
		selfFocus.drawBlock(x, y,w,h); 	
	};	
	this.SetBlockFlag = function(){
		mFlag=0;
	};
	this.ClearBlockFlag = function(){
	
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
	};
	
	this.ClearBlockFlag_su = function(){
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
	};
		
	this.setSupportHisi = function(flag) {
	    m_IsSupportHisi = flag;
		return	m_IsSupportHisi;
	}
	this.autofocusmode = function(flag) {
	    m_autofocusmode = flag;
		//return	m_IsSupportHisi;
	}
	this.setisUsed = function(flag) {
	    isUsed = flag;
		//return	m_IsSupportHisi;
	}		
};
function GV(v,df)
{
  return ((v.indexOf("<%") > -1 || v.indexOf("<@") > -1) ? df : v).toString().replace(/>/gi,"&gt;").replace(/</gi,"&lt;").replace(/&amp;/gi,"&").replace(/&#47;/gi,"/").replace(/&#37;/gi,"%").replace(/&quot;/gi,'"').replace(/&#39;/gi,"'");
}

var AxVer = "2,0,0,101";			//ActiveX Version.
var DigSignName = "D-Link";		//The name of the digital signature
var webVersion = "2.2";
var webPageVersion = DigSignName + webVersion;	//HTML version.
var webPageSubVersion = "15_min";			//HTML sub version, the "b" is beta version.
var webVer = webVersion+"."+webPageSubVersion;

var g_isSupMpeg4=GV("<%supportmpeg4%>",1);
var g_videoFormat=GV("<%format%>",0);
var g_isPal=(GV("<%imagesource%>",1) == "1");
var g_deviceName=GV("<%devicename%>","VideoServer");
var g_defaultStorage=GV("<%defaultstorage%>",1); // 0: cf, 1:sd 255:no card
//var g_SDInsert=parseInt(GV("<%sdinsert%>",0));
var g_CFInsert=GV("<%cfinsert%>",0);
var g_cardGetLink=GV("<%defaultcardgethtm%>","sdget.htm");
var g_brandUrl=GV("<%brandurl%>",null);
var g_titleName=GV("<%title%>","IPCAM");
// 20090202 Netpool Add for D-Link Style
var g_softwareversion=GV("<%SoftwareVersion%>","1.00");
var g_fullversion=GV("<%fullversion%>","1.00.00");
//var g_brandName=GV("<%brandname%>".toLowerCase(),"nobrand");
var g_brandName="nobrand";
var g_supportTStamp=GV("<%supporttstamp%>",0);
var g_ZoomSize = 0;
var g_p1XSize=parseInt(GV("<%profile1xsize%>",320));
var g_p1YSize=parseInt(GV("<%profile1ysize%>",240));
var g_p2XSize=parseInt(GV("<%profile2xsize%>",320));
var g_p2YSize=parseInt(GV("<%profile2ysize%>",240));
var g_p3XSize=parseInt(GV("<%profile3xsize%>",320));
var g_p3YSize=parseInt(GV("<%profile3ysize%>",240));
var g_p4XSize=parseInt(GV("<%profile4xsize%>",320));
var g_p4YSize=parseInt(GV("<%profile4ysize%>",240));
var g_isSupP1=(parseInt(GV("<%supportprofile1%>",0)) >= 1);
var g_isSupP2=(parseInt(GV("<%supportprofile2%>",0)) >= 1);
var g_isSupP3=(parseInt(GV("<%supportprofile3%>",0)) >= 1);
var g_isSupP4=(parseInt(GV("<%supportprofile4%>",0)) >= 1);
var g_isSupAJAX1=(parseInt(GV("<%supportajax1%>",0)) >= 1);
var g_isSupAJAX2=(parseInt(GV("<%supportajax2%>",0)) >= 1);
var g_isSupAJAX3=(parseInt(GV("<%supportajax3%>",0)) >= 1);
var g_RTSPName1 = GV("<%rtspaccessname1%>","live1.sdp");
var g_RTSPName2 = GV("<%rtspaccessname2%>","live2.sdp");
var g_RTSPName3 = GV("<%rtspaccessname3%>","live3.sdp");
var g_RTSPPort = GV("<%rtspport%>",554);
var g_socketAuthority=parseInt(GV("<%socketauthority%>",3));  //0:admin,1:operator,2:viewer
var g_isAuthorityChange=(parseInt(GV("<%authoritychange%>",0)) == 1);
var g_isSupMotion=(parseInt(GV("<%supportmotion%>",0)) >= 1);
var g_isSupWireless=(parseInt(GV("<%supportwireless%>",0)) == 1);
var g_serviceFtpClient=parseInt(GV("<%serviceftpclient%>",0));
var g_serviceSmtpClient=parseInt(GV("<%servicesmtpclient%>",0));
var g_servicePPPoE=parseInt(GV("<%servicepppoe%>",0));
var g_serviceSNTPClient=parseInt(GV("<%servicesntpclient%>",0));
var g_serviceDDNSClient=parseInt(GV("<%serviceddnsclient%>",0));
//20081212 chirun add virtualserver
var g_serviceVirtualSClient=parseInt(GV("<%servicevirtualclient%>",0));

var g_s_maskarea=GV("<%supportmaskarea%>",0);
var g_machineCode="<%machinecode%>";
var g_maxCH=GV("<%maxchannel%>",1);
var g_isSupportRS485 = ("<%supportrs485%>"==1);
var g_isSupportRS232 = ("<%supportrs232%>"==1);
var g_useActiveX=GV("<%layoutnum.0%>",1);
var g_ptzID=GV("<%layoutnum.1%>",1);
var g_s_mui=GV("<%supportmui%>",1);
var g_mui=GV("<%mui%>",-1);
var g_isSupportSeq=("<%supportsequence%>"==1);
var g_isSupportMQ=(parseInt("<%quadmodeselect%>") >= 0);
var g_quadMode=GV("<%quadmodeselect%>",1); //default is 1:quad
//var g_isSupportSmtpAuth=(g_machineCode!="1290");
var g_isSupportSmtpAuth=true;
var g_isSupportIPFilter=("<%serviceipfilter%>"==1);
var g_oemFlag0=(parseInt(GV("<%oemflag0%>",0)));
var g_s_daynight=(parseInt(GV("<%supportdncontrol%>",0)) == 1);//ICR
var s_irled = parseInt(GV("<%supportirled%>",0));//IR
var s_power = parseInt(GV("<%supportdcpower%>",0));//power
//start--2010.11.15
var g_isIpcam = (parseInt(GV("<%machinetype%>",0))==0);//0/1=true/false=IpCam/VideoServer
//end--2010.11.15
var g_is264=(parseInt(GV("<%supportavc%>",0)) == 1);
var g_isSelMpeg4=(parseInt(GV("<%supportavc%>",0)) == 1);
var g_isSupportD2N=false;
var g_isSupportN2D=false;
var g_isSupportAudio=(parseInt(GV("<%supportaudio%>",0)) >= 1); // for audiovideoPage audioin
var g_isSupportTwoWayAudio=(parseInt(GV("<%supporttwowayaudio%>",0)) >= 1);// for live mic and audiovideoPage audioout
var g_isSupportptzpage=(parseInt(GV("<%supportptzpage%>",1)) == 1);
//var g_isShowPtzCtrl=((g_machineCode=="1670") && (g_socketAuthority < 2));
var g_isShowPtzCtrl=false;
//20090206 chirun add for 7313
var g_IMGStatus=1;
// 20090210 Netpool add to fix Img_htm
var g_stream1name = GV("<%stream1name%>","");
var g_stream2name = GV("<%stream2name%>","");
var g_stream3name = GV("<%stream3name%>","");
var g_stream4name = GV("<%stream4name%>","");

//Multi profile Case 1 --> for 7228,7227 Supprot H.264 and MJPEG
var g_isMP1 = (g_machineCode==1671 || g_machineCode==1771);
//Multi Profile for 73xx
var g_isMP73 = (g_machineCode==2001 || g_machineCode==2100 || g_machineCode==1679 || g_machineCode==1677 || g_machineCode==2000);
var g_enpantilt = (parseInt(GV("<%rs485enable%>",0)) == 1);
var g_supgioin = parseInt(GV("<%supportgioin%>",2));
var g_supgioout = parseInt(GV("<%supportgioout%>",1));//2012.3.22 added by Nell.
var g_numAllProfile=parseInt(GV("<%numprofile%>",4));//2011.3.22 added
var g_numProfile = parseInt(GV("<%webprofilenum%>",3));
var g_preset_profile_name= parseInt(GV("<%preset_profile_name%>",3));
var g_IsSupportProfile4 = (parseInt(GV("<%getprofile4uistatus%>",0)) == 1);
var mpMode = 1;
var g_motionBlock;
var g_maxmotionarea_window;
var g_MotionAmount = 3;
var g_audioType = GV("<%audiotype%>","G.726");
var g_viewXSize;
var g_viewYSize;
var g_GetFPS = 15;
var g_GetProFileFPS = "getprofile1fps";
var g_isRunMotion = parseInt(GV("<%motionwizardconfig%>",1));
var g_modelname=GV("<%OEMModel%>","DCS-3710");
// 0 is non , 1 is for 355
var g_profileCheckMode = parseInt(GV("<%profilecheckmode%>",0));
var g_isSupportEPTZ =parseInt(GV("<%supporteptz%>",1));
var g_isShowRs485 = parseInt(GV("<%rs485enable%>",0));
var g_isSupportVisca = parseInt(GV("<%supportvisca%>",0));
var g_supportFishEye=parseInt(GV("<%supportfisheye%>",0)); //support fisheye
//--start 2012.11.6 for zbc Speed Dome
var g_supportZbc = parseInt(GV("<%supportzbc%>", 0));
//start--2013.04.19
var g_supportHisi=parseInt(GV("<%supporthisi%>",0));
//end--2013.04.19
//start--2013.06.10
var g_support_real_ptz=parseInt(GV("<%support_real_ptz%>",0));
//end--2013.06.10


//--end
var g_isShowPtzCtrl= (( g_support_real_ptz == 1 || g_isShowRs485 || g_isSupportVisca || g_isSupportEPTZ || g_supportZbc) == 1 );
var g_EPTZ1 = "<%profile1eptzcoordinate%>";
var g_EPTZ2 = "<%profile2eptzcoordinate%>";
var g_EPTZ3 = "<%profile3eptzcoordinate%>";
var g_EPTZ1x1 = parseInt(g_EPTZ1.substr(0,4)*1);
var g_EPTZ1y1 = parseInt(g_EPTZ1.substr(4,4)*1);
var g_EPTZ2x1 = parseInt(g_EPTZ2.substr(0,4)*1);
var g_EPTZ2y1 = parseInt(g_EPTZ2.substr(4,4)*1);
var g_EPTZ3x1 = parseInt(g_EPTZ3.substr(0,4)*1);
var g_EPTZ3y1 = parseInt(g_EPTZ3.substr(4,4)*1);
//fisheye 2012.5.02
var fish_mode_list=GV("<%fisheyedisplaymodename%>","1O;1R;2P;1O3R;4R");//fish_mode_list
var fish_mode=GV("<%fisheyedisplaymode%>","1O");
var g_fish_panspeedname=GV("<%panspeedname%>","0");//fish_panspeedname
var g_fish_tiltspeedname=GV("<%tiltspeedname%>","0");//fish_tiltspeedname
var g_fish_zoomspeedname=GV("<%zoomspeedname%>","0");//fish_zoomspeedname
var g_fish_panoramicspeedname=GV("<%panoramicspeedname%>","0");//fish_panoramicspeedname
var g_fish_rotatespeedname=GV("<%rotatespeedname%>","0");//fish_rotatespeedname
var g_fisheyepresetlistname=GV("<%fisheyepresetlistname%>","ccc;bbb;aaa;ccc;bbb");
var g_fisheyerotatelistname=GV("<%fisheyerotatelistname%>","ccc;bbb;aaa;ccc;bbb").split(";"); //only 20 sets
var g_fisheyeautopan=GV("<%fisheyeautopan%>",0);
var g_fisheyesequence=GV("<%fisheyesequence%>",0);
//--start 2011.4.18 modified
//var g_SupportJoystick = (g_isSupportVisca==1) ? 1 : 0;
var g_SupportJoystick = 1;
//--end 2011.4.18

var l_profileresolution = new Array("<%profile1resolution%>","<%profile2resolution%>","<%profile3resolution%>","<%profile4resolution%>");
var l_profilereviewer = new Array("<%profile1viewres%>","<%profile2viewres%>","<%profile3viewres%>");
//--start 2011.4.7 add for aspect ratio
var g_globalWidth = 120;
var g_globalHeight = 90;
var g_baseX = 320;
var g_baseY = 240;
var g_GlobalRateX = 0;
var g_GlobalRateY = 0;
var g_ViewerWidth = 320;
var g_ViewerHeight = 240;
//--end 2011.4.7
// 0 is RS485 , 1 is EPTZ, 2 is Rs485&EPTZ, 3 is visca&eptz
var g_PTZMode = 0;
var g_isSupportFan = (GV("<%supportfancontrol%>",0) == 1);
var g_EPTZmouse = new Object;
g_EPTZmouse.page = {x:0,y:0};
var g_KeepFocusWindow = 1;
var g_isSupportAF = parseInt(GV("<%supportaf%>",1));
var g_EPTZmouseX;
var g_EPTZmouseY;
var g_EPTZWidth = null;
var g_EPTZHeight = null;
var g_isEPTZviewer =false;
var g_ZoomPosition = parseInt(GV("<%afzoomposition%>",0));
var g_MaxZoomStep = parseInt(GV("<%afmaxzoomstep%>",0));
var g_ResolutionX;
var g_ResolutionY;
var g_tempx1 = null;
var g_tempy1 = null;
var g_SelectIndex = 0;
var timerChangeImage = null;
var timerMoveUvumiWin = null;
var FocusbusyTimer = null;
var g_IsPan1 = 0;
var g_IsPan2 = 0;
var g_IsPan3 = 0;
var g_IsPreset1 = 0;
var g_IsPreset2 = 0;
var g_IsPreset3 = 0;
//--start 2010.12.27 added for QoS
var g_supportqos = parseInt(GV("<%supportqos%>", 0));
var g_supportcos = parseInt(GV("<%supportcos%>", 0));
var g_supportbwc = parseInt(GV("<%supportbwc%>", 1));
//--end 2010.12.27
//--start 2010.12.30 added for ddns
var DDNS_TIMEOUT_MIN = 24;
var DDNS_TIMEOUT_MAX = 65535;
//--end 2010.12.30
//--start 2011.1.14 add for wifi
var g_supportWifi = parseInt(GV("<%supportwifi%>", 0));
//--end 2011.1.14
//--start 2011.1.27 add for visca 6815
var g_supportsdhide = parseInt(GV("<%sddisplay%>",0));  // 0 :must display, 1: insert sd card just display
//--end 2011.1.27
//--start 2011.2.17 add for visca 6815
var g_suptvout = parseInt(GV("<%supporttvout%>",1));//visca=0
var g_suptLed  = parseInt(GV("<%supportled%>",1));	//visca=0
//--end 2011.2.17
//--start 2011.6.21 add for test

//if(g_supportFishEye==1 && (g_audioType == "G.726" || g_audioType == "G.711") )
//	var g_audioAmplifyRatio=5;	
//else
	var g_audioAmplifyRatio = parseFloat(GV("<%audioamplifyratio%>", 1));
	
//--end 2011.6.21
//--start 2011.10.19 add for ipv6
var g_netip = GV("<%netip%>","127.0.0.1");
var g_host = location.hostname;	//Initial IPv6 in common.js.
var g_Port = location.port;
var g_supportIPv6 = parseInt(GV("<%supportipv6%>", 0))==1;	//debug is 1.
var g_isIPv6 = false;
//--end 2011.10.19
//--start 2011.10.19 add for multicast
var g_isSupportMulticast = parseInt(GV("<%supportmulticast%>",0))!=0;	//multicast
var g_pf1mcen = parseInt(GV("<%profile1_mc_enable%>",0));
var g_pf2mcen = parseInt(GV("<%profile2_mc_enable%>",0));
var g_pf3mcen = parseInt(GV("<%profile3_mc_enable%>",0));
var g_pf4mcen = parseInt(GV("<%profile4_mc_enable%>",0));	//20140605
var g_StreamType = 3;	//stream type: 0=UDP unincast, 1=UDP multicast, 2=TCP, 3=HTTP(default)
//--end 2011.10.19
//--start 2012.05.10 SNMP
var g_isSupportsnmp=GV("<%support_snmp%>",0);
//--end
//--start 2012.06.21 newtimezone
var g_supportnewtimezone = parseInt(GV("<%supportnewtimezone%>",0));
var g_timezonetable = GV("<%timezonetable%>","");
var g_timezoneindex=GV("<%timezoneindex%>","");
//--end

//start--2012.12.24
var g_supportirledcolor=parseInt(GV("<%supportirledcolor%>",0));
//end --2012.12.24

//start--2013.01.22
var g_oemname=GV("<%oemname%>","dlink");
//end--2013.01.22

//start--2013.03.20
var g_firstlogin=parseInt(GV("<%firstlogin%>",0));
//end--2013.03.20

//start--2013.04.12
var g_supportwhitelightled=parseInt(GV("<%supportwhitelightled%>",0));
//end--2013.04.12

//start--2013.04.19
var g_supportafinterval=parseInt(GV("<%supportafinterval%>",0));
//end--2013.04.19

//start --2013.08.29 privacy
var g_supportprivacycontrol=parseInt(GV("<%privacymode%>",0));
var g_getprivacycontrol=parseInt(GV("<%privacycontrol%>",0));
var g_getprivacystate=parseInt(GV("<%privacystate%>",0));
//end 

var g_supportcalibration=parseInt(GV("<%support_calibration%>",0));
//start--2013.06.03
var g_supporttamper=parseInt(GV("<%supporttamper%>",0));
//end--2013.06.03

//start--2013.07.31
var g_supportlogv2=parseInt(GV("<%supportlogv2%>",0));
//end--2013.07.31

var g_support_longcctv_cont=parseInt(GV("<%support_longcctv_cont%>",0));


// support  remote log
var g_supportremotelog=parseInt(GV("<%supportremotelog%>",0));

var g_supportsound_detection=parseInt(GV("<%supportsounddetection%>",0));

var g_supportHisi=parseInt(GV("<%supporthisi%>",0));

//support pir 2014.01.18
var g_supportpir=parseInt(GV("<%supportpir%>",0));

//support HttpServer 2014.03.12
var g_supporthttpserver=parseInt(GV("<%supporthttpserver%>",0));
//support FTP over SSL 2014.03.12
var g_supportftps=parseInt(GV("<%supportftps%>",0));
//support notification 2014.03.13
var g_supporteventhttp=parseInt(GV("<%supporteventhttp%>",0));
//support BONJOUR  2014.06.11
var g_supportbonjour=parseInt(GV("<%support_bonjour%>",0));

//support pir 2014.07.11
var g_supportpirsen =  parseInt(GV("<%supportpirsen%>",0));
//support supportddnsv2 2014.08.01
var g_supportddnsv2 =  parseInt(GV("<%supportddnsv2%>",0));

var g_support_wps_conf = parseInt(GV("<%support_wps_conf%>",0));

//2015.01.14 support CBR to 6M??M,
//+/-Value', + => '>=', - => '<', +0 => '6M', 8M => all open, -0 => '6M??M' not open, default => '+0'
var g_support_cbrdecision = GV("<%cbrdecision%>","+0");
var g_supportmotion_windowmode = parseInt(GV("<%supportmotion_windowmode%>","0")); // for nvrbase
var g_supportfish_v2  = parseInt(GV("<%supportfisheye_v2%>", 0)); 
var g_supportmounttype  = parseInt(GV("<%supportmounttype%>", 0)); 
var g_powerlinedisplay  = parseInt(GV("<%powerlinedisplay%>", 0)); // use powerline char
var g_supportnvrbased = parseInt(GV("<%supportnvrbased%>", 0));
var g_support_wpa_enterprise = parseInt(GV("<%support_wpa_enterprise%>", 0));
var g_support_csrf_ref = parseInt(GV("<%support_csrf_ref%>", 0));
var g_supportgoplength = parseInt(GV("<%supportgoplength%>",0)); // for intra frame
var g_motionBlock_Width = parseInt(GV("<%motionBlock_Width%>","32"), 10);
var g_motionBlock_Height = parseInt(GV("<%motionBlock_Height%>","16"), 10);
var g_motionwindowarea = GV("<%motionwindowarea%>","1:2:3:5:5*2:4:4:9:9*3:5:5:8:8");//for fish motion num:x1:y1:x2:y2*num:x1:y1:x2:y2 
var g_maxmotionarea_window = parseInt(GV("<%maxmotionarea_window%>","12"));
var g_support_aes = GV("<%supportpwdaes%>",0);
var g_start_aes = 1;

function loadJS(url)
{
	document.write('<sc'+'ript language="javascript" type="text/javascript" src="' + url + '?'+webVer+'"></script>');
}
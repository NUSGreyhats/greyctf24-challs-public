﻿var masklive = new MaskFetcher();

var maskIndex = 0;
var maskuseIndex = 0;
	Blockbuffer = new Array(3);
	for(i=0 ; i < 3 ;i++){
		Blockbuffer.push("00" + i.toString() + "000000000000");		
	}

function MaskFetcher(){
	var m_IsSupportHisi;	
	var m_aspectratio;
	var selfMask = this;
	this.width;
	this.height;

	this.xBlock = 64;
	this.yBlock = 36;

	this.totalBlock = this.xBlock*this.yBlock;
			
	this.BlockArry = new Array(this.totalBlock);
	this.blockWidth;
	this.blockHeight;
	//image canvas
	this.cv;
	this.ctx;
	this.image;
	//draw canvas
	this.canvas;
	this.context;
	this.canvaso;
	this.contexto;
	// The active tool instance.
	this.tool;
	this.timer;
	this.timerStatus;
	
	this.hexhead;
	
	this.supportfish = false;
	
	
	var overflag=0;
	var intindex=0;
	var tempBlockbuffer = new Array(3);
	for(i=0 ; i < 3 ;i++){
		tempBlockbuffer.push(i.toString());		
	}	
	
	this.initEvent = function() {
		this.blockWidth = this.width / this.xBlock;
		this.blockHeight = this.height / this.yBlock;
				
		var img  = document.getElementById("maskView");  //add 2012.06.12
		// Add the temporary canvas.
		var container = img.parentNode;   //add 2012.06.12
		//var container = this.cv.parentNode;
		
		//temporary canvas
		this.canvaso = document.createElement('canvas');
		if (!this.canvaso) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}
		for(i=0; i< 3 ; i++)
		{
		 Blockbuffer[i]= "10" + i.toString() + "000000000000";
		 tempBlockbuffer[i]="0";
		}
		maskuseIndex = 0;
		maskIndex =0;
		
		this.canvaso.id     = 'maskTemp';
		this.canvaso.width  = this.width;
		this.canvaso.height = this.height;
		container.appendChild(this.canvaso);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvaso);//==================================<<<ie only 
		this.contexto = this.canvaso.getContext('2d');
		this.contexto.lineWidth = "1";
		this.contexto.strokeStyle = "rgb(124, 252, 0)";//Lawn Green
		
		
	//temporary canvas1.
		this.canvas = document.createElement('canvas');
		if (!this.canvas) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvas.id     = 'maskTemp1';
		//this.canvas.width  = this.cv.width;
		//this.canvas.height = this.cv.height;
		this.canvas.width  = this.width;
		this.canvas.height = this.height;
		container.appendChild(this.canvas);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvas);//=====================================<<<ie only 
		this.context = this.canvas.getContext('2d');		
		this.context.lineWidth = "1";
		this.context.strokeStyle = "rgb(124, 252, 0)";//Lawn Green

		// rect tool instance.
		this.tool = new this.toolMask();
		
		
		// Attach the mousedown, mousemove and mouseup event listeners.
		if(this.canvas.addEventListener && !this.supportfish)
		{	// all browsers except IE before version 9
			this.canvas.addEventListener('mousedown', this.ev_canvas, false);
			this.canvas.addEventListener('mousemove', this.ev_canvas, false);
			this.canvas.addEventListener('mouseup',   this.ev_canvas, false);
			this.canvas.addEventListener('mouseout',  this.ev_canvas, false);
		}
		else
		{
			if (this.canvas.attachEvent && !this.supportfish)
			{	 // IE before version 9 
			
				this.canvas.attachEvent('onmousedown', this.ev_canvas);
				this.canvas.attachEvent('onmousemove', this.ev_canvas);
				this.canvas.attachEvent('onmouseup',   this.ev_canvas);
				this.canvas.attachEvent('onmouseleave',  this.ev_canvas);
			}
		}
	};
	// The general-purpose event handler. This function just determines the mouse 
	// position relative to the canvas element.
	this.ev_canvas = function(ev) {	
			if(browser.FireFox){
			ev._x = ev.layerX;
			ev._y = ev.layerY;		
			}			
			else {
			ev._x = ev.offsetX;
			ev._y = ev.offsetY;
			}
		// Call the event handler of the tool.
		var eventfunc = selfMask.tool[ev.type];
		if (eventfunc) {
			eventfunc(ev);
		}
	};
	
	// This function draws the #maskTemp canvas on top of #maskView, after which 
	// #maskTemp is cleared. This function is called each time when the user 
	// completes a drawing operation.
	this.updateCanvas = function() {
		this.contexto.drawImage(this.canvas, 0, 0);		
		//this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);	
	};	
	
	this.drawBlock = function(x,y,x1,y1){
		this.context.fillStyle="rgb(124, 252, 0)";//Lawn Green
		this.context.fillRect(x,y,x1,y1);
	};	
	this.drawBlock1 = function(x,y,x1,y1){
		this.contexto.fillStyle="rgb(124, 252, 0)";//Lawn Green
		this.contexto.fillRect(x,y,x1,y1);
	};
	// The mask tool.
	this.toolMask = function() {
		var selfTool = this;
		this.started = false;
		var tr  = document.getElementById("privacymasken");  //add 2012.06.12
		if(tr != null){
			if(tr.checked==true)
				hexhead='10';
			else
				hexhead='00';
		}
		
		this.mousedown = function (ev) {
		
		if (ev.button == 2 || ev.button == 3) {
			return false;
        }

			if( maskIndex > 2){
			  maskIndex=0;			  
			}
			  if( maskuseIndex > 2 && maskIndex < 3)
			  {
				var str1 = tempBlockbuffer[maskIndex];
				var tmp = str1.split(",");
				
				selfMask.contexto.clearRect(parseFloat(tmp[0]),parseFloat(tmp[1]),parseFloat(tmp[2]),parseFloat(tmp[3]));
				for (j=0 ; j < 3 ; j++){
					if (j!=maskIndex){
						str1 = tempBlockbuffer[j];
						tmp = str1.split(",");
					
						selfMask.drawBlock1(parseFloat(tmp[0]),parseFloat(tmp[1]),parseFloat(tmp[2]),parseFloat(tmp[3]));
					}
				}
			  }
			selfTool.started = true;

			selfTool.x0 = Math.floor(ev._x );
			selfTool.y0 = Math.floor(ev._y);			
			
			maskIndex++;
			maskuseIndex++;
			
		};

		this.mousemove = function (ev) {
			if (!selfTool.started) {
				return;
			}
			
			selfTool.x1 = Math.floor(ev._x );
			selfTool.y1 = Math.floor(ev._y );
			
			var x = Math.min(selfTool.x1,  selfTool.x0),
				y = Math.min(selfTool.y1,  selfTool.y0),
				w = Math.abs(selfTool.x1 - selfTool.x0)+1,
				h = Math.abs(selfTool.y1 - selfTool.y0)+1;

			if (w==0 && h==0) {
				return;
			}
			
			selfMask.context.clearRect(0, 0, selfMask.canvas.width, selfMask.canvas.height);
			selfMask.drawBlock(x, y,w,h); 						
		};

		this.mouseup = function (ev) {
			if (selfTool.started) {
				selfTool.mousemove(ev);
				selfTool.started = false;
				selfMask.updateCanvas(); 
				
				selfTool.x1 = Math.floor(ev._x);
				selfTool.y1 = Math.floor(ev._y);
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
				
				var mx,my,mx1,my1,m_rate,m_ratey;

				if (m_IsSupportHisi=="1"){
					if(m_aspectratio == "169"){
						m_rate = 4;  // 1280 : 720 = 320 : 180;
						m_ratey = 4;
					}	
					else{
						m_rate = 4; // 1280 : 720 = 320 : 240;					
						m_ratey = 3;
					}	
				}
				else{
					if(m_aspectratio == "169")
						m_rate = 2; // T1 machine
					else
						m_rate = 2;
                } 
						
					
				mx = x ;	
				my = y ;	
				
				mx1= Math.max(selfTool.x1,  selfTool.x0);      
				my1 = Math.max(selfTool.y1,  selfTool.y0);	
				
				tempBlockbuffer[maskIndex-1]= x + "," + y + "," + w + "," + h;
				
				if(m_IsSupportHisi=="1")
					Blockbuffer[maskIndex-1]= hexhead + (maskIndex-1).toString() + Hex(mx * m_rate) + Hex(my * m_ratey) + Hex(mx1 * m_rate) + Hex(my1 * m_ratey);	
				else
					Blockbuffer[maskIndex-1]= hexhead + (maskIndex-1).toString() + Hex(mx * m_rate) + Hex(my * m_rate) + Hex(mx1 * m_rate) + Hex(my1 * m_rate);
					
				intindex=0;
	
			}
		};
		
		this.mouseout = function (ev) {
			if (selfTool.started) {
				selfTool.started = false;
				selfMask.updateCanvas(); 
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
					
				var mx,my,mx1,my1,m_rate;
				
				mx = x ;		
				my = y;		
						
				mx1= Math.max(selfTool.x1,  selfTool.x0) ;      
				my1 = Math.max(selfTool.y1,  selfTool.y0);   
				
				if (m_IsSupportHisi=="1")
					m_rate = 4;
				else
					m_rate = 2; // T1 machine

					
				if(mx < 0)
					mx=0;
				if (my < 0)	
					my=0;
					
				tempBlockbuffer[maskIndex-1]= x + "," + y + "," + w + "," + h;
				
				Blockbuffer[maskIndex-1]= hexhead + (maskIndex-1).toString() + Hex(mx * m_rate) + Hex( my * m_rate) + Hex(mx1 * m_rate) + Hex(my1 * m_rate);
				intindex=0;
/*				selfMask.updateCanvas();
				var i,j;
				for(i=0; i<w; i++){
					for(j=0; j<h; j++){
						selfMask.BlockArry[(y+j)*selfMask.xBlock+(x+i)] = 1;
					}
				}
*/			}
		};
		Hex = function (str){
			var maskX01="";
			if(str.toString(16).length <3 && str.toString(16).length > 1)
			  maskX01='0'+str.toString(16);
			else if(str.toString(16).length <2 && str.toString(16).length > 0)  
				maskX01='00'+str.toString(16);
			else 
			  maskX01=str.toString(16);
			  
			  return maskX01;
		}
	};
	
	this.Loop = function(){
		selfMask.image.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();
	};
	
//Those are public function
	
	this.GenHtml = function(width, height){
		o = '';
		o += '<div id="MaskContainer">';  
			o += '<img id="maskView" width="'+width+'" height="'+height+'" src="/Loading.gif"/>'; //add 2012.06.12
			
		o += '</div>';		
		this.width = width;
		this.height = height;	
		return o;
	};	
	
	this.Start = function(){	
		this.timerStatus = true;
		
		this.image = new Image();
		this.image.onload = function(){
			if(!selfMask.timerStatus)
				return;
				
			var imgobj = GE("maskView");  //add 2012.06.12
			imgobj.src = selfMask.image.src;	  //add 2012.06.12
//			imgobj.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();	  //add 2012.06.12
			
			//selfMask.ctx.drawImage(selfMask.image, 0, 0, selfMask.width, selfMask.height);
			
			selfMask.timer = setTimeout(selfMask.Loop, 330);
		};
		this.Loop();
		
		this.initEvent();
		
	};
	
	this.Stop = function() {
		this.timerStatus = false;
		clearTimeout(this.timer);
	};
	
	this.SetBlockFlag = function(flag){
		this.ClearBlockFlag();
		overflag=0;
		var index = 0;
		for( i=0; i<flag.length; i++ ){
			var hex = parseInt(flag.charAt(i), 16);
			for( j=0; j<4; j++ ){
				if((hex & 0x1)==0x1)
					this.BlockArry[index] = 1;
				else
					this.BlockArry[index] = 0;
				
				if( this.BlockArry[index] == 1 ){
					var yy = parseInt(index / this.xBlock),
						xx = index - (yy * this.xBlock);
					this.drawBlock(xx, yy);
				}
				hex = hex >> 1;
				index++;
			}
		}
		
		this.updateCanvas();
	};
	
	this.GetBlockFlag = function(){
		var flag = "";
		for(i=0; i<3; i++){
			var hex = 0;
			if(Blockbuffer[i]!=undefined)
				flag += Blockbuffer[i];
			else
				flag += hexhead + i.toString() + "000000000000";
			if(i<2)
				flag +=";";
		}
		return flag;
	};
	
	this.ClearBlockFlag = function(){
		for(i=0; i< 3 ; i++)
		{
		 Blockbuffer[i]=hexhead + i.toString() + "000000000000";
		}
		maskIndex=0;
		maskuseIndex=0;
		
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		for(i=0; i<this.totalBlock; i++)
			this.BlockArry[i] = 0;
	};
	this.ClearBlockFlag_su = function(){
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		maskuseIndex=0;
		for(i=0; i<this.totalBlock; i++)
			this.BlockArry[i] = 0;
	};
		
	this.SelectAllBlockFlag = function(){
		for(i=0; i<this.totalBlock; i++){
			this.BlockArry[i] = 1;
			var yy = parseInt(i / this.xBlock),
				xx = i - (yy * this.xBlock);
			this.drawBlock(xx, yy);
		}
		this.updateCanvas();
	} 

	this.setSupportHisi = function(flag) {
	    m_IsSupportHisi = flag;
		return	m_IsSupportHisi;
	}
	
	this.setSupportFish = function(flag) {
	    this.supportfish = flag;		
	}
	
	this.setAspectratio = function(rate) {
			
	    m_aspectratio = rate;		
	}
	
};
var motionlive = new MotionFetcher();

function MotionFetcher(){
	var selfMotion = this;
	this.width;
	this.height;
//	if(g_supporttimotion==1){
//		this.xBlock = 8;
//		this.yBlock = 6;
//	}else{
		this.xBlock = 32;
		this.yBlock = 16;
//	}
	this.totalBlock = this.xBlock*this.yBlock;
	
	this.BlockArry = new Array(this.totalBlock);
	this.blockWidth;
	this.blockHeight;
	//image canvas
	this.cv;
	this.ctx;
	this.image;
	//draw canvas
	this.canvas;
	this.context;
	this.canvaso;
	this.contexto;
	// The active tool instance.
	this.tool;
	this.timer;
	this.timerStatus;

	this.initEvent = function() {
		this.blockWidth = this.width / this.xBlock;
		this.blockHeight = this.height / this.yBlock;
		
		var img  = document.getElementById("motionView");  //add 2012.06.12
		// Add the temporary canvas.
		var container = img.parentNode;   //add 2012.06.12
		//var container = this.cv.parentNode;
		
		//temporary canvas
		this.canvaso = document.createElement('canvas');
		if (!this.canvaso) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvaso.id     = 'motionTemp';
		//this.canvaso.width  = this.cv.width;
		//this.canvaso.height = this.cv.height;
		this.canvaso.width  = this.width;
		this.canvaso.height = this.height;
		container.appendChild(this.canvaso);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvaso);//==================================<<<ie only 
		this.contexto = this.canvaso.getContext('2d');
		
		
	//temporary canvas1.
		this.canvas = document.createElement('canvas');
		if (!this.canvas) {
			alert('Error: I cannot create a new canvas element!');
			return;
		}

		this.canvas.id     = 'motionTemp1';
		//this.canvas.width  = this.cv.width;
		//this.canvas.height = this.cv.height;
		this.canvas.width  = this.width;
		this.canvas.height = this.height;
		container.appendChild(this.canvas);
		if(check_IE7or8())//add 2012.06.12
			G_vmlCanvasManager.initElement(this.canvas);//=====================================<<<ie only 
		this.context = this.canvas.getContext('2d');		
		this.context.lineWidth = "1";
		this.context.strokeStyle = "rgb(124, 252, 0)";//Lawn Green

		// rect tool instance.
		this.tool = new this.toolMotion();
		
		// Attach the mousedown, mousemove and mouseup event listeners.
		if(this.canvas.addEventListener)
		{	// all browsers except IE before version 9
			this.canvas.addEventListener('mousedown', this.ev_canvas, false);
			this.canvas.addEventListener('mousemove', this.ev_canvas, false);
			this.canvas.addEventListener('mouseup',   this.ev_canvas, false);
			this.canvas.addEventListener('mouseout',  this.ev_canvas, false);
		}
		else
		{
			if (this.canvas.attachEvent)
			{	 // IE before version 9 
			
				this.canvas.attachEvent('onmousedown', this.ev_canvas);
				this.canvas.attachEvent('onmousemove', this.ev_canvas);
				this.canvas.attachEvent('onmouseup',   this.ev_canvas);
				this.canvas.attachEvent('onmouseleave',  this.ev_canvas);
			}
		}
	};
	// The general-purpose event handler. This function just determines the mouse 
	// position relative to the canvas element.
	this.ev_canvas = function(ev) {
/*		if (ev.layerX || ev.layerX == 0) { // Firefox
			ev._x = ev.layerX;
			ev._y = ev.layerY;
		} else if (ev.offsetX || ev.offsetX == 0) { // Opera
			ev._x = ev.offsetX;
			ev._y = ev.offsetY;
		}
*/
		if(browser.FireFox){
			ev._x = ev.layerX;
			ev._y = ev.layerY;		
		}			
		else {
			ev._x = ev.offsetX;
			ev._y = ev.offsetY;
		}		// Call the event handler of the tool.
		var eventfunc = selfMotion.tool[ev.type];
		if (eventfunc) {
			eventfunc(ev);
		}
	};
	
	// This function draws the #motionTemp canvas on top of #motionView, after which 
	// #motionTemp is cleared. This function is called each time when the user 
	// completes a drawing operation.
	this.updateCanvas = function() {
		this.contexto.drawImage(this.canvas, 0, 0);		
		//this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);	
	};	
	
	this.drawBlock = function(blockx, blocky){
		var x1 = blockx * this.blockWidth,
			y1 = blocky * this.blockHeight,
			x2 = x1 + this.blockWidth,
			y2 = y1 + this.blockHeight;
			
		this.context.strokeRect(x1, y1, this.blockWidth, this.blockHeight);
		this.context.beginPath();
		this.context.moveTo(x1, y1);
		this.context.lineTo(x2, y2);
		this.context.stroke();
		this.context.closePath();
	};
	
	// The motion tool.
	this.toolMotion = function() {
		var selfTool = this;
		this.started = false;

		this.mousedown = function (ev) {
			if (ev.button == 2 || ev.button == 3) 
				return false;
		
		//	if(ev.which!=1) return;//not left button   

			selfTool.started = true;

			selfTool.x0 = Math.floor(ev._x / selfMotion.blockWidth);
			selfTool.y0 = Math.floor(ev._y / selfMotion.blockHeight);			
			selfMotion.drawBlock(selfTool.x0, selfTool.y0); 
			
		};

		this.mousemove = function (ev) {
			if (!selfTool.started) {
				return;
			}
			
			selfTool.x1 = Math.floor(ev._x / selfMotion.blockWidth);
			selfTool.y1 = Math.floor(ev._y / selfMotion.blockHeight);
			
			var x = Math.min(selfTool.x1,  selfTool.x0),
				y = Math.min(selfTool.y1,  selfTool.y0),
				w = Math.abs(selfTool.x1 - selfTool.x0)+1,
				h = Math.abs(selfTool.y1 - selfTool.y0)+1;
			if (w==0 && h==0) {
				return;
			}
			
			selfMotion.context.clearRect(0, 0, selfMotion.canvas.width, selfMotion.canvas.height);
			
			var i,j;
			for(i=0; i<w; i++){
				for(j=0; j<h; j++){
					selfMotion.drawBlock(x+i, y+j); 
					
				}
			}
		};

		this.mouseup = function (ev) {
			if (selfTool.started) {
				selfTool.mousemove(ev);
				selfTool.started = false;
				selfMotion.updateCanvas(); 
				
				selfTool.x1 = Math.floor(ev._x / selfMotion.blockWidth);
				selfTool.y1 = Math.floor(ev._y / selfMotion.blockHeight);
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
				
				var i,j;
				for(i=0; i<w; i++){
					for(j=0; j<h; j++){
						selfMotion.BlockArry[(y+j)*selfMotion.xBlock+(x+i)] = 1; 						
					}
				}
			}
		};
		
		this.mouseout = function (ev) {
			if (selfTool.started) {
				selfTool.started = false;
				selfMotion.updateCanvas(); 
				
				var x = Math.min(selfTool.x1,  selfTool.x0),
					y = Math.min(selfTool.y1,  selfTool.y0),
					w = Math.abs(selfTool.x1 - selfTool.x0)+1,
					h = Math.abs(selfTool.y1 - selfTool.y0)+1;
				
				var i,j;
				for(i=0; i<w; i++){
					for(j=0; j<h; j++){
						selfMotion.BlockArry[(y+j)*selfMotion.xBlock+(x+i)] = 1;
					}
				}
			}
		};
	};
	
	this.Loop = function(){
		selfMotion.image.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();
	};
	
//Those are public function

	this.GenHtml = function(width, height){
		o = '';
		o += '<div id="MotionContainer">';   // oncontextmenu="return false;" change
			o += '<img id="motionView" width="'+width+'" height="'+height+'" src="/Loading.gif"/>'; //add 2012.06.12
			//o += '<canvas id="motionView" width="'+width+'" height="'+height+'"></canvas>';
		o += '</div>';		
		this.width = width;
		this.height = height;	
		return o;
	};	
	
	this.Start = function(){	
		this.timerStatus = true;
	//	this.cv = document.getElementById("motionView");
	//	this.ctx = this.cv.getContext("2d");
		
		this.image = new Image();
		this.image.onload = function(){
			if(!selfMotion.timerStatus)
				return;
				
			var imgobj = GE("motionView");  //add 2012.06.12
//			imgobj.src = selfMotion.image.src;	  //add 2012.06.12
			imgobj.src = "/dms?nowprofileid="+g_numAllProfile+"&"+Math.random();	  //add 2012.06.12
			
			//selfMotion.ctx.drawImage(selfMotion.image, 0, 0, selfMotion.width, selfMotion.height);
			
			selfMotion.timer = setTimeout(selfMotion.Loop, 330);
		};
		this.Loop();
		
		this.initEvent();
		
	};
	
	this.Stop = function() {
		this.timerStatus = false;
		clearTimeout(this.timer);
	};
	
	this.SetBlockFlag = function(flag){
		this.ClearBlockFlag();
		var index = 0;
		for( i=0; i<flag.length; i++ ){
			var hex = parseInt(flag.charAt(i), 16);
			for( j=0; j<4; j++ ){
				if((hex & 0x1)==0x1)
					this.BlockArry[index] = 1;
				else
					this.BlockArry[index] = 0;
				
				if( this.BlockArry[index] == 1 ){
					var yy = parseInt(index / this.xBlock),
						xx = index - (yy * this.xBlock);
					this.drawBlock(xx, yy);
				}
				hex = hex >> 1;
				index++;
			}
		}
		
		this.updateCanvas();
	};
	
	this.GetBlockFlag = function(){
		var flag = "";
		for(i=0; i<this.totalBlock; i+=4){
			var hex = 0;
			for(j=0; j<4; j++){
				if(this.BlockArry[i+j]==1)
					hex += (1<<j);
			}
			flag += hex.toString(16).toUpperCase();
		}
		return flag;
	};
	
	this.ClearBlockFlag = function(){
		this.contexto.clearRect(0, 0, this.canvaso.width, this.canvaso.height);
		this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
		for(i=0; i<this.totalBlock; i++)
			this.BlockArry[i] = 0;
	};
	
	this.SelectAllBlockFlag = function(){
		for(i=0; i<this.totalBlock; i++){
			this.BlockArry[i] = 1;
			var yy = parseInt(i / this.xBlock),
				xx = i - (yy * this.xBlock);
			this.drawBlock(xx, yy);
		}
		this.updateCanvas();
	} 
};
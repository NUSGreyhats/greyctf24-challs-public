//define the check alarm timer interval.
var g_AlarmCheckTime = 1500;
var g_AlarmApi = "getalarmstatus";
var timerID=null;
var timerID2=null;
var timerIDAlarm = null;
var timerChangeImage = null;
var timerEPTZ = null;
var timerEPTZJoystick = null;
var timerDisplayMode = null;
var timerPTZ = null;	//2012.12.24 added for Speed Dome
var clearPressQueue = null;
//var timerVisca = null;
//var g_ViscaZoomEn = false;
//var g_ViscaInterval = 500;
var l_profileformat = new Array("<%profile1format%>","<%profile2format%>","<%profile3format%>","<%profile4format%>");
var g_entriggerout = parseInt(GV("<%allgiooutenable%>",0));
var g_h264Status = parseInt(GetCookie("VideoMode"));
var g_enmute = parseInt(GV("<%audioinenable%>",0));

// White light LED
if(g_supportwhitelightled){
	var g_isFocusbusy = false;
	var g_seleAutoMode=parseInt(GV("<%whitelightledsensitivity%>",0));
	var g_whitelightledmode=GV("<%whitelightledmode%>","none");
	var g_whitelightledtime=parseInt(GV("<%whitelightledtime%>",0));
	
	var g_MaxLightStep = 100;
	var g_LightOneStepSize = parseInt(g_MaxLightStep)/80;

	var g_LightPosition = 20;
	g_LightPosition = parseInt(g_LightPosition)/((g_MaxLightStep)/80);
	var g_loadpagefinish = false;
	
}
	
if (isNaN(g_h264Status))
{
  g_h264Status = 1;
}
//g_h264Status = UpdateGSize(g_h264Status);
var DCL_1 = {
zoom : "1",
width  : "<%jpegxsize.1%>",
height : "<%jpegysize.1%>"
};
var DCL_2 = {
zoom : "1",
width  : "<%jpegxsize.2%>",
height : "<%jpegysize.2%>"
};
var DCL_3 = {
zoom : "1",
width  : "<%jpegxsize.3%>",
height : "<%jpegysize.3%>"
};
var DCL_4 = {
zoom : "1",
width  : "<%jpegxsize.4%>",
height : "<%jpegysize.4%>"
};

if (browser_IE)
{
  mpMode=GetCookieInt("MP_MODE", 1);
  if (isNaN(mpMode))
  {
    mpMode = 1;
  }
  mpMode = UpdateGSize(mpMode);
}
else
{
  number = 1;
  if(!g_isSupAJAX1 && !g_isSupAJAX2 && !g_isSupAJAX3)
    number = 1 ; 
  else
  {
    if(!g_isSupAJAX1)
      number = 2;
    else if(!g_isSupAJAX2)
      number = 3
    else if(!g_isSupAJAX3)
      number = 1 ;
  }
     
  mpMode=GetCookieInt("MP_MODE", number);
  SetCookie("MP_MODE", mpMode);
}
  //var savePath=GetCookieInt("SAVE_PATH","");
var savePath=GetCookieStr("SAVE_PATH","");

//MJPEG
var DCL_MP1_1 = {
  codec : V_JPEG,
  zoom : "1",
  width : "<%jpegxsize%>",
  height : "<%jpegysize%>"
};
//H.264
var DCL_MP1_2 = {
  codec : V_JPEG,
  zoom : "1",
  width : "<%jpegxsize%>",
  height : "<%jpegxsize%>"
};

//73XX
var DCL_MP1_3 = {
  codec : V_JPEG,
  zoom : "1",
  width : "<%jpegxsize%>",
  height : "<%jpegxsize%>"
};
var DCL_MP1_4 = {
  codec : V_JPEG,
  zoom : "1",
  width : "<%jpegxsize%>",
  height : "<%jpegxsize%>"
};
var DCL_MP1_5 = {
  codec : V_JPEG,
  zoom : "1",
  width : "<%jpegxsize%>",
  height : "<%jpegxsize%>"
};

var g_isMP73 = true;
//return the preference codec
//if not mulit profile will return 0
function GetCodec()
{
  var res = 0;
  if (g_isMP1 || g_isMP73)
  {
    res = eval("DCL_MP1_"+mpMode+".codec");
  }
  return res;                
};

//start 2010.12.27 modified
//var i18nStr = "English;\u7e41\u9ad4\u4e2d\u6587".split(";");
//var i18nStr = "English;\u7b80\u4f53\u4e2d\u6587;\u7e41\u9ad4\u4e2d\u6587;\u010ce\u0161tina;Nederlands;Suomi;Fran\u00e7ais;Deutsch;Italiano;Polski;Portugu\u00eas;Espa\u00f1ol;Svenska;Magyar;Rom\u00e2n\u0103;Turkey".split(";");
var i18nStr = "English;\u7b80\u4f53\u4e2d\u6587;\u7e41\u9ad4\u4e2d\u6587;\u010ce\u0161tina;Nederlands;Suomi;Fran\u00e7ais;Deutsch;Italiano;Polski;Portugu\u00eas;Espa\u00f1ol;Svenska;Magyar;Rom\u00e2n\u0103;Turkey;;;\ud55c\uad6d\uc5b4;;;\u65e5\u672c\u8a9e".split(";");	//20140514 add japanese
//			   English;Chinese Simplified;      Chinese Traditional;     Czech;            Dutch;     Finnish;French;     German; Italian; Polish;Portuguese;    ;Spanish;    Swedish;Hungarian;Romanian;     Turkish     Korean                Japanese
//--end 2010.12.27
var langList = '';
var langIDList;
var g_langID;
{
  var o='';
  var m='';
  var t=g_s_mui;
  var i=0;
  while (t > 0)
  {
    if (t%2 == 1)
    {
      o+=""+i18nStr[i]+";";
      m+=(i+";");
    }
    t = Math.floor(t/2);
    i++;
  }
  langList = o.substring(0,o.length-1);
  langIDList = m.substring(0,m.length-1).split(";");
  
  if ( g_mui == 255){  // 255 -> 0xff
	
		for(var i=0; i<g_langFullNameList.length ;i++){		
			if( _os_language.toLowerCase().replace(/-/gi,"_") == g_langFullNameList[i]){
				g_langID = i;
				break;
			}
				
		}	
  }
  else{
  
	  for (i=0;i<langIDList.length;i++)
	  {
		if (langIDList[i]==g_mui)
		{
		  g_langID = i;
		  break;
		}
	  }
  }  
}

var c_langSel = new Ctrl_Select("langSel",langList,g_langID,"","ChangeLanguage()");
var mySize = new SIZE(g_viewXSize,g_viewYSize);
function SIZE(w,h)
{
  this.w=parseInt(w,10);
  this.h=parseInt(h,10);
};

//=========CALL BACK========
function MY_CH_CHANGE()
{
};

function StartAX()
{  
  if (IsVS())//Check is Video-Server
  {
	for (i=1;i<=g_maxCH;i++)
	{
	  StartActiveXEx(0,0,null,i,i,0);
	}	
  }
  else
  {  
  //--start 2011.9.30 modified
    if(g_isSupportEPTZ == 1 || g_isSupportVisca==1 )
		
		StartActiveXEx(0,1,null,null,null,5);
	else if(g_supportFishEye == 1)
	      
	    StartActiveXEx(0,1,null,null,0,9); 
	else if(g_supportfish_v2 == 1){		
		StartActiveXEx(0,1,null,null,0,13); 
	}	
	else if(g_supportZbc==1)
		StartActiveXEx(0,1,null,null,0,11);  	
	else if(g_isSupportEPTZ == 0)
	      
	    StartActiveXEx(0,1,null,null,0,0);  	

  //--end 2011.9.30
  }  
}

function MY_ONLOAD()
{

  if( browser.Chrome || browser.Spartan ){		
			
		if( GetCookie("chromeVerAlert") == "false"){
			alert(GL("_chrome_ver_alert"));
			SetCookie("chromeVerAlert", "true");
		}	
	}		

  mpMode=GetCookieInt("MP_MODE",1);
  mpMode=UpdateGSize(mpMode);

  if(g_getprivacystate!=1 || g_getprivacycontrol!=1)
  ChangeIndexWidthSize('profile'+mpMode);
  
  SetLiveBoxStr();
  SetDLinkLightValue("gpOutputButton",g_entriggerout);

  clearTimeout(timerIDAlarm);
  clearTimeout(timerEPTZJoystick);
  clearTimeout(timerEPTZ);
  clearTimeout(timerPTZ);
  clearTimeout(clearPressQueue);
  timerEPTZ = null;
  timerPTZ = null;
  clearPressQueue =null;
  
  
  //This is read alarm status.
  timerIDAlarm = setTimeout("StartAlarmWorker()",g_AlarmCheckTime);
  if(g_isSupportEPTZ == 1)
  {
	//This is to read auto-pan or sequence status.
    timerEPTZ = setTimeout("SendEPTZWorker()",500);
	//This is to read Joystick status from ActiveX.
	timerEPTZJoystick = setTimeout("StartEPTZWorker()",1000);
  }else
  if(g_isSupportVisca==1)	//for speed dome
  {
	//This is to read auto-pan and sequence and Cruise status.
    timerPTZ = setTimeout("SendPTZWorker()",500);
	//This is to read Joystick status from ActiveX.
	timerEPTZJoystick = setTimeout("StartEPTZWorker()",100);
  }
  else
  if(g_supportFishEye==1 || g_supportfish_v2)
  {
	//This is to read Joystick status from ActiveX.
	timerEPTZJoystick = setTimeout("StartEPTZWorker()",100);
	
	
  }
  else
  if(g_supportZbc==1)
  {
	//This is to read Joystick status from ActiveX.
	timerEPTZJoystick = setTimeout("StartEPTZWorker()",100);
  }
  
  
  SetAllLight();
  
  //This is read EPTZ coordinate.
  SendEPTZPoint(mpMode);
  
  //set main button status
  switch (mpMode)
  {
  case 1:
    SetDLinkLightValue("profile1",1);
    break;
  case 2:
    SetDLinkLightValue("profile2",1);
    break;
  case 3:
    SetDLinkLightValue("profile3",1);
    break;
  case 4:
    SetDLinkLightValue("profile4",1);
    break;
  default:
    SetDLinkLightValue("profile4",1);
    break;
  }
 
  if (browser_IE)
  {
    var obj = GE(AxID);
    if (obj != null)
    {
      try
      {
        obj.width = g_viewXSize;
        obj.height= g_viewYSize;
      }
	  catch (e){}
	  
	  if(g_supportfish_v2)
		getDisplayMode(); 
	 
	}
  }
  else
  {
    //o = CheckBrowser();
	//if(o == 'Firefox' || o == 'Chrome')
	if(l_profileformat[mpMode-1]!="JPEG" && l_profilereviewer[mpMode-1]!="2048x1536") 		//20140922 modify || -> &&
	{
	  try
      {
        //obj.width = g_viewXSize;
        //obj.height= g_viewYSize;
		var obj = GE("QuickTimeLayer");
        obj.innerHTML= CreateQuickTime(mpMode, "UDP");
		
		if(g_supportFishEye || g_supportfish_v2)
			motionlive.Start();		
      }
	  catch (e){}
	}
	else
	{
	  var obj = GE("showdms_0");
	  if (obj != null)
	  {
	    obj.width = g_viewXSize;
		obj.height= g_viewYSize;
	  }
		ChangeToUseAjax(); 		//20140922 add
	}
  }
  
   
  
  if (browser_IE)
  {	
	//------2012.04.25
	if( !IsViewer() &&  g_supportZbc==1){
	//	EventRMouseClick();	
		
		EventMouseDown();
		EventMouseUp();
		
		EventMouseWheel();	
	}
			
	if( !IsViewer() &&  (g_supportFishEye == 1 )){
		EventMouseDown();
	//  EventMouseUp();
	//  EventMouseMove();
	}
	if( !IsViewer() &&  (g_supportfish_v2 == 1)){
	//	EventMouseDown();
	  EventMouseUp();
	//  EventMouseMove();
	}
	//---end 2012.04.25
	
    StartAX(); 
  }
  else
  {
    //o = CheckBrowser();
	//if(o == 'Firefox')
	if(l_profileformat[mpMode-1]!="JPEG" && l_profilereviewer[mpMode-1]!="2048x1536") 		//20140922 modify || -> &&
	{
		qt_counter = 0;
		setTimeout("CheckQuickTimeStatus()", 1000);
	}
	else
	{ 
	  imgFetcher.RunDms();
	}
  }

  
  if(g_supportwhitelightled)
	{
		if(g_whitelightledmode=="None")
			GE("whitelightLivebox").innerHTML="";
		else if(g_whitelightledmode=="Pulse") // pluse
			GE("whitelightLivebox").innerHTML=ShowWhiteLightLiveBox(g_whitelightledmode);
		else if(g_whitelightledmode=="Active") // active/ inactive
			GE("whitelightLivebox").innerHTML=ShowWhiteLightLiveBox(g_whitelightledmode);
		else if(g_whitelightledmode=="Slider") // slider
			GE("whitelightLivebox").innerHTML=ShowWhiteLightLiveBox(g_whitelightledmode);
		
	
	}
	
		// for ptz live page, pan and seq button 
	if( g_longcctvseqstatus ){
		CheckPanStop_SeqStop('seq');	
	}	
	else if( g_longcctvapnstatus ){
		CheckPanStop_SeqStop('pan');		
	}
  
  LoadAllImage();	
  g_lockLink = false;
  g_loadpagefinish = true;
  
  FixStatus(); 
	
};

function MY_ONUNLOAD()
{
	var qt = GE("qt_embed");
	if(qt!=null)
	{
		qt.Stop();
	}
	
  clearTimeout( timerID );
  clearTimeout( timerID2 );
  clearTimeout( timerIDAlarm );
  clearTimeout( timerEPTZ);
  clearTimeout( timerPTZ);	//2012.12.24 add
  clearTimeout( timerIDTalk );
  clearTimeout( timerDisplayMode);
  //--2010.12.27 added
  StopGetEptzPostion();
  //--2010.12.27
  
   clearTimeout(clearPressQueue);
   clearPressQueue=null;
   
   if (browser_IE){
   
   }
   else{
	SetCookie("chromeVerAlert", "false");
   }
   
   
};


function FixStatus()
{   
  if(g_supportFishEye || g_supportfish_v2){  
	if(fish_mode=='1O' || fish_mode=='2P')
		DisableObject("fisheyepresetlistname",true);	
		
	if(g_fisheyeusrdefhome)
			GE("fisheye_setHome").style.backgroundColor="#FFAA00";		

  }	 
  
  GE("langSel").style.width="90px";

  if(g_longcctvmovemode==0)
	  ChangeImg("img_continue","Continuous_on.gif"); 
  else
	 ChangeImg("img_step","step_on.gif");

}

var tmp_displayMode;
function getDisplayMode()
{
	clearTimeout(timerDisplayMode);
	if( timerDisplayMode != null)
		timerDisplayMode = null;
				
	var obj = GE(AxID);		
	if( obj.DisplayMode != tmp_displayMode && obj.DisplayMode != ""){		
		tmp_displayMode = obj.DisplayMode; 
		ChangeDisplayModePic(obj.DisplayMode);
	}	
		
	timerDisplayMode = setTimeout(function(){ getDisplayMode(); },1000);
}


function ShowWhiteLightLiveBox(mode)
{

	var o='';
  o+='<table width="125px" border="0" cellpadding="2" cellspacing="1" ><tr>'; 
    

  if(mode=="Pulse"){  // pulse
	o+='<td  align="right"><font color="#ffffff">' + GL("light") + '</font></td>'; 	
	o+='<td ><div id="pulse" style="width:26px; height:26px; border:0px solid;cursor:pointer;" onmousedown="ChangeBtn2WhiteLed(this,\'pulseimg\',\'down\');" onmouseup="ChangeBtn2WhiteLed(this,\'pulseimg\',\'up\');" ><image id="pulseimg" src="Pulse_off-26x26.gif"  width="26px" height="26px" title="' + GL("pulse_tip",{1:g_whitelightledtime}) + '"></div></td>';  
  
  }
  else if(mode=="Active"){ // active / inactive
	o+='<td  align="right"><font color="#ffffff">' + GL("light") + '</font></td>';	
	o+='<td ><div id="active" style="width:26px; height:26px; border:0px solid;cursor:pointer;"  onmousedown="ChangeBtn2WhiteLed(this,\'activeimg\',\'down\');"><image id="activeimg"  src="Light_off-26x26.gif" width="26px" height="26px" title="' + GL("active") + ' ' + GL("light") + '"></div></td>';
 
  
  }
  else if(mode=="Slider"){ // slider
	o+='<td  align="center" colspan="3"><font color="#ffffff">' + GL("light") + '</font></td>';
	o+='</tr><tr align="center">';
   
    o+='<td>'+'<img src="/slider_left.gif" width="14" height="14" onclick="NearProcess(2)" style="cursor:pointer;"/>'+'</td>';
    o+='<td width="84px">';
    o+='<img src="/slider_bg_84x8px.gif" id="bar" width="84" height="8" onclick="BarControl(event,\'pic\')" onload="GetPosition(this,\'pic\');" style="background-position: 0pt -3px;" />';
    o+='<img src="/slider_handle.gif" id="pic" style="display: inline; position: absolute; left: 50px;" >';
    o+='</td>';
    o+='<td>'+'<img src="/slider_right.gif" width="14" height="14" onclick="FarProcess(2)"  style="cursor:pointer;"/>'+'</td>';

  
  }
  else if(mode=="Auto"){
		o+='<td  align="right"><font color="#ffffff">' + GL("light") + '</font></td>'; 
		o+='<td ><div id="auto" style="width:26px; height:26px; border:0px solid;cursor:pointer;" onmousedown="ChangeBtn2WhiteLed(this,\'autoimg\',\'down\');">';
       switch(g_seleAutoMode)
		{
			case 0:
				o+='<image id="autoimg"  src="low_light_L.gif" width="26px" >';  
			break;
			case 1:
				o+='<image id="autoimg"  src="low_light_M.gif" width="26px" >';  
			break;
			case 2:
				o+='<image id="autoimg"  src="low_light_S.gif" width="26px">';  
			break;

		}	   
		
		o+='</div></td>';
    	
  }
    
  o+='</tr><tr><td>&nbsp;</td>';		
  o+='</tr></table>';  
  return o;
   
}


var resizetimer = null;
function MY_ONRESIZE()
{

	if(g_loadpagefinish)
	{
		if(resizetimer==null)
			resizetimer = setTimeout("myresize()", 300);
	}
}

function myresize()
{
	var obj = GE("pic");

	if(obj!= null  && g_ePosition!= null)
	{
		count = 2;	
		g_LightPosition = g_LightPosition - g_l;

		GetPosition(g_ePosition,'pic');	
	}

	resizetimer = null;
}


var g_l;
var g_BarPosition;
var g_MaxBarPosition;

function BarControl(e,id)
{
  if(!g_isFocusbusy)
  {
    var addiv = document.getElementById(id); 
    e=e||event;
	//addiv.style.left = e.clientX+"px";
    //alert("parseInt(e.offsetX)"+parseInt(e.offsetX));
	
    if(id == 'pic')
    {
	
		if(browser_IE)
			{
				g_LightPosition = parseInt(e.offsetX) + parseInt(g_l);
				gv = Math.round( parseInt(e.offsetX)*((g_MaxLightStep)/80));
			}
			else{
				g_LightPosition = parseInt(e.clientX);
				gv = Math.round( parseInt(g_LightPosition - g_l)*((g_MaxLightStep)/80));
			}		
	  
	  if(g_LightPosition > g_MaxBarPosition)
	    g_LightPosition= g_MaxBarPosition;
		
      gv = Math.round( parseInt(e.offsetX)*((g_MaxLightStep)/80));
	  
	  if(gv > g_MaxLightStep)
	    gv= g_MaxLightStep;
	  SendHttpPublic('/cgi-bin/light_ctrl.cgi?action=on&active='+gv);
	  
      if(browser_IE)
	    addiv.style.left = g_LightPosition+"px";
	  else
        addiv.style.left = e.clientX+"px"; 		
    }
    //p = parseInt(g_l) + parseInt(e.offsetX);
    //addiv.style.left = p+"px";
  }
  
};

var g_ePosition = null;
var count = 2;
function GetPosition(e,id)
{  //alert("a1");
  //why run 4's ? so to this count--
  if(count <= 0)
    return;
  count--;
  //alert("a2");
  g_ePosition = e;
  var t=e.offsetTop;
  var l=e.offsetLeft;
  while(e=e.offsetParent)
  {  
    t+=e.offsetTop  
    l+=e.offsetLeft;  
  } 
  g_l = parseInt(l);
 
  g_BarPosition = parseInt(l);
  g_MaxBarPosition = parseInt(l)+parseInt(80);
  
  //alert('g_MaxBarPosition:'+g_MaxBarPosition);
  var addiv = document.getElementById(id); 
  if(id == 'pic')
  {
    g_LightPosition = parseInt(g_LightPosition)+parseInt(l);
	if(g_LightPosition > g_MaxBarPosition)
	  g_LightPosition= g_MaxBarPosition;

	addiv.style.left = g_LightPosition+"px";
  }
};

function NearProcess(value)
{
  if(browser_IE)
  {
    var obj = GE(AxID);
    if(obj!=null)
    {
	  
	}  
  }
  else
  {
  
  }
  if(!g_isFocusbusy)
  {
    if(value == 1)
      g_LightPosition -= 5;
    else if(value == 2)
      g_LightPosition -= parseInt(ptzspeed.GV());
		
    if(g_LightPosition < g_BarPosition)
      g_LightPosition = g_BarPosition;
  
    GE("pic").style.left = g_LightPosition+"px";
  
    SendHttpPublic('/cgi-bin/light_ctrl.cgi?action=on&active=' + Math.round( parseInt(g_LightPosition - g_l)*((g_MaxLightStep)/80)));
  }	
};

function FarProcess(value)
{
  if(browser_IE)
  {
    var obj = GE(AxID);
    if(obj!=null)
    {
	  
	}  
  }
  else
  {
  
  }
  if(!g_isFocusbusy)
  {
    if(value ==1)
      g_LightPosition += 5;
    else if(value == 2)
	  g_LightPosition += parseInt(ptzspeed.GV());
        
    if(g_LightPosition > g_MaxBarPosition)
	  g_LightPosition = g_MaxBarPosition;	
	  
//	  alert(g_LightPosition);
    GE("pic").style.left = g_LightPosition+"px";
	  
    SendHttpPublic('/cgi-bin/light_ctrl.cgi?action=on&active=' +Math.round( parseInt(g_LightPosition - g_l)*g_LightOneStepSize));
  }	
};


var qt_counter = 0;
var qt_times = 10;
function CheckQuickTimeStatus()
{
	var qt = GE("qt_embed");
	if(qt!=null)
	{
	//--start 2011.10.6 added
		try{
			var status = qt.GetPluginStatus();				
		}catch(e){
			//Quicktime plugin not support.
			ChangeToUseAjax();
		}
	//--end 2011.10.6 added	
	
		//alert("1: >"+status+"<");	
		if(status.indexOf("Complete")!=-1)
		{
		//	alert("5: "+status);
			var msg = status.split(",");
			if(msg.length>1)
			{
				var err = msg[1].split(":"); 				
				if(err.length>1)
				{//error
					if(QtProtocol=="UDP")
					{
						//alert("protocol: "+QtProtocol);
						var obj = GE("QuickTimeLayer");
						obj.innerHTML= CreateQuickTime(mpMode, "TCP");	
                        						
						setTimeout("CheckQuickTimeStatus()", 1000);
					}
					//--start 2011.10.6 added
					else
					{
						//change to use AJAX
						//alert("use ajax!");
						ChangeToUseAjax();
					}
					//--end 2011.10.6 added	
				}
				else
				{	
					//Completed, for Chrome, Opera, Safari.
					//alert("chrome");					
				}
			}
			else
			{       					
				//Completed, for Chrome, Opera, Safari.
				//alert("firefox");
			}
		}
	//--start 2011.10.6 added
		else
		if(status.indexOf("Waiting")!=-1)
		{
			//alert("Waiting");
			qt_counter++;
			if(qt_counter<qt_times)
				setTimeout("CheckQuickTimeStatus()", 1000);
			else
				//alert("timeout");
				ChangeToUseAjax();
		}
		else
		if(status.indexOf("Loading")!=-1)
		{
			//alert("3: "+status);
		}
		else
		if(status.indexOf("Playable")!=-1)
		{
			//alert("4: "+status);
		}
		else
		if(status.indexOf("Error")!=-1)
		{
			//this is for iPhone
			//alert("6: "+status);
			ChangeToUseAjax();
		}
		else
		{
			//alert("7: unknow message! ---> "+status);
			qt_counter++;
			if(qt_counter<qt_times)
				setTimeout("CheckQuickTimeStatus()", 1000);
			else
				ChangeToUseAjax();
		}
	//--end 2011.10.6 added	
	}
}



function ChangeBtn2WhiteLed(obj,img_name,action)
{
	if(obj!=null){
	//	alert(obj.id);
		if(obj.id=="pulse"){
			if(action=="down"){				
				GE(img_name).src="Pulse_on-26x26.gif";				
				GE(img_name).title= GL("pulse_tip",{1:g_whitelightledtime});
			}	
			else if(action=="up"){
				GE(img_name).src="Pulse_off-26x26.gif";
				GE(img_name).title= GL("pulse_tip",{1:g_whitelightledtime});
				
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?action=on"  );
			}	
		}
		else if(obj.id=="active")
		{
			if(action=="down")				
			 {				
			    if( GE(img_name).src.indexOf("Light_on-26x26.gif") >0)
				{
					GE(img_name).src="Light_off-26x26.gif";				
					GE(img_name).title=GL("active") + ' ' + GL("light");
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?action=off" );
				}	
				else if( GE(img_name).src.indexOf("Light_off-26x26.gif")>0 )
				{
					GE(img_name).src="Light_on-26x26.gif";	
					GE(img_name).title=GL("inactive") + ' ' + GL("light");
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?action=on" );
				
				}
			 }
		}
		else if(obj.id=="auto")
		{
			if(action=="down")				
			 {
				 if( GE(img_name).src.indexOf("low_light_L.gif") >0)
				{
					GE(img_name).src="low_light_M.gif";	
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?sensitivity=1");
				}
				else if(GE(img_name).src.indexOf("low_light_M.gif") >0)
				{
					GE(img_name).src="low_light_S.gif";	
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?sensitivity=2");
				}
				else if( GE(img_name).src.indexOf("low_light_S.gif") >0)
				{
					GE(img_name).src="low_light_L.gif";	
					SendHttpPublic("/cgi-bin/light_ctrl.cgi?sensitivity=0");
				}
			 }
		
		}
		
		
	}

}


//--start 2011.10.7 added
//When Quicktime is not supprot, then switch to use ajax.
function ChangeToUseAjax()
{
	var livebox = GE("QuickTimeLayer");
	if(livebox!=null)
	{
		livebox.innerHTML = imgFetcher.GetDmsImgStr(g_viewXSize, g_viewYSize);
		var obj = GE("showdms_0");
		if (obj != null)
		{
			obj.width = g_viewXSize;
			obj.height= g_viewYSize;
		}
		imgFetcher.RunDms();
	}
}
//--end 2011.10.7

function LoadAllImage()
{
  if(g_PTZMode == 1 &&(!IsViewer()))
  {
	  GE("img_seq").src = "";
      GE("img_seq").src="seq-off_n.gif";
	  GE("img_stop").src = "";
      GE("img_stop").src="stop-off_n.gif";
	  GE("img_pan").src="";
      GE("img_pan").src="pan-off_n.gif";  
	  
	  
      //GE("img_preset").src="goto-off_p.gif";
	  GE("globalview_img").src = "";
      if(g_isEPTZviewer)
        GE("globalview_img").src = "global-on_f.gif";
      else	
        GE("globalview_img").src="global-off_n.gif";
  }
  
   if( (g_supportFishEye || g_supportfish_v2) && (!IsViewer())){
	
	   disModeArr=fish_mode_list.split(";");    
     
		for(var j=0;j<disModeArr.length;j++){
		
		    if(disModeArr[j]!=fish_mode)
				GE("mode_"+disModeArr[j]).src=disModeArr[j]+"-off.gif";		 		  						   
		}
  }	 
  
  
  var i;
  for(i=0;i<g_supgioin;i++){
	GE("LIGHT_PIC_gpInputIcon"+(i+1)).src = "";
	if(g_isSupportVisca==1)
		GE("LIGHT_PIC_gpInputIcon"+(i+1)).src= "v_digital_input_off_"+(i+1)+".gif";
	else
		GE("LIGHT_PIC_gpInputIcon"+(i+1)).src= "digital_input_off_"+(i+1)+".gif";
  }
  GE("LIGHT_PIC_motionIcon").src="";
  GE("LIGHT_PIC_motionIcon").src="motion_notification_off.gif";
  GE("LIGHT_PIC_recordIcon").src="";
  GE("LIGHT_PIC_recordIcon").src="server_recorde_off.gif";
  
 
};
function StartAlarmWorker()
{
  // Check Queue and Send PTZ api;
  popPressQueue();

  SendHttp(c_iniUrl+"&getdlinkalarmstatus&getdlinksdstatus",true,SendOK);

};
var lastCode2 = -1;
var g_eventdostatus = 0;
var g_alwayGioOn = 0;
var g_iodostatus = 0;
function SendOK()
{
  if(g_SubmitHttp.readyState==4)
  {
	
    if(g_SubmitHttp.status==200)
    {
      try
      {
        var txt=g_SubmitHttp.responseText;
		
		var iy = txt.indexOf("UA getdlinkalarmstatus");
		if(iy>=0){
			clearTimeout(timerIDAlarm); //add 2015.1.20
			timerIDAlarm = null;
			return false;
		}	  	  
        
        var ix = txt.indexOf("OK getdlinkalarmstatus=");
        if(ix>=0)
        {
          var code = txt.substring(ix+23,ix+27);
          code = parseInt(code,16);
	      SetLight("gpInputIcon1",(((code & 0x00000001) != 0)?1:0));
	      SetLight("gpInputIcon2",(((code & 0x00000002) != 0)?1:0));
	      SetLight("motionIcon",(((code & 0x00000004) != 0)?1:0));
	      SetLight("recordIcon",(((code & 0x00000008) != 0)?1:0));
		  g_alwayGioOn = (((code & 0x00000010) != 0)?1:0); // user-trigger
		  g_iodostatus = (((code & 0x00000020) != 0)?1:0); // event-trigger
          if(g_isSupportVisca==1){
	        SetLight("gpInputIcon3",(((code & 0x00000040) != 0)?1:0));
	        SetLight("gpInputIcon4",(((code & 0x00000080) != 0)?1:0));
	        SetLight("gpInputIcon5",(((code & 0x00000100) != 0)?1:0));
	        SetLight("gpInputIcon6",(((code & 0x00000200) != 0)?1:0));
	        SetLight("gpInputIcon7",(((code & 0x00002000) != 0)?1:0));
	        SetLight("gpInputIcon8",(((code & 0x00004000) != 0)?1:0));
          }
		  
		  //alert(g_alwayGioOn);
		  //alert(g_iodostatus);
		  var status;
		  var v;
		  if(g_alwayGioOn==0)
		  {
		    status = 0;
			v=0;
		  }
		  else if( g_alwayGioOn==1 || g_iodostatus==1 )
		  {
		    status = 3;
			v=1;
		  }

		  ChangeDLinkLightStatus2("gpOutputButton", v ,status);
		  //g_alwayGioOn & g_iodostatus
		  ChangeIndexIOStatus( g_alwayGioOn , g_iodostatus );
        }

	    var iy = txt.indexOf("OK getdlinksdstatus=");
	    if(iy>=0)
	    {
          var code2 = txt.substring(iy+20,iy+23);
	      //alert(code2);

          code2 = parseInt(code2,16);
	      var sdinsert = ((code2 & 0x00000001) != 0);
          var sdlock = ((code2 & 0x00000002) != 0);
          var sdformat = ((code2 & 0x00000004) != 0);
	      var sdtesting = ((code2 & 0x00000008) != 0);
	  
	      if(lastCode2 != code2)
	      {
            var obj = GE("sdStatusStr");
            if(obj != null)
            {
              if(sdtesting)
			  {
				ShowSdBlock(false);
                obj.innerHTML = '&nbsp;';
			  }
	          else if(!sdinsert || !sdformat)
			  {
				ShowSdBlock(false);
                obj.innerHTML = GL("sd_no_inserted");
              //else if(!sdformat)
                //obj.innerHTML = GL("sd_format_failed")+'&nbsp;&nbsp;';
			  }
              else if(sdlock)
			  {
				ShowSdBlock(true);
                obj.innerHTML = GL("sd_write_protected");
			  }
              else
			  {
				ShowSdBlock(true);
                obj.innerHTML = GL("sd_ready");
			  }
  	          lastCode2 = code2;
	        }
	      }
	    }
		
		if(g_support_real_ptz && !IsViewer())
			SendHttp("vb.htm?setlongcctvzoom",true,RespPresetValue);
      }
      catch (e){};
	  
	  timerIDAlarm = setTimeout("StartAlarmWorker()",g_AlarmCheckTime);
    }
	else
	{
		clearTimeout(timerIDAlarm); //add 2015.1.20
		timerIDAlarm = null;
	
	}
    
  }
};
function RespPresetValue()
{
  if(g_SubmitHttp.readyState==4)
  {
		if(g_SubmitHttp.status==200)
		{
			  try
			  {
					var txt=g_SubmitHttp.responseText;
					
					
					var ix = txt.indexOf("OK setlongcctvzoom=");
					if(ix>=0)
					{ 
					  //g_ZoomSize = txt.substring(ix+19,ix+21); // set to ptz_dlink.js  Zoom in and Zoom out
					
					 } 
			  
			  }
			     catch (e){};
		  
		 }
  }	 

}
function ShowSdBlock(show)
{
	if(g_supportsdhide==0)
		return;
		
	var display = (show ? "block" : "none");
	var sd = GE("sdblock");
	if(sd!=null)
	{
		if(sd.style.display==display)
			return;

		sd.style.display=display;
	}
}

function SetAllLight()
{
  //SetDLinkLightValue("profile1",0);
  for(var id in DLinkLightAry)
  {
    tt = id.split("_");
    SetDLinkLightValue(tt[1],0);
  }
};
function ChangeIndexIOStatus(alwayGioOn,iodostatus)
{
  var obj = GE("iostatus");
  if( obj!=null && alwayGioOn==1)
  {
    obj.innerHTML=GL("user_trigger");
  }
  else if( obj!=null && iodostatus==1)
  {
	obj.innerHTML=GL("event_trigger");
  }
  else if(obj!=null && alwayGioOn==0 && iodostatus==0)
  {
    obj.innerHTML=GL("none");
  }
};



function Chk_AudioIn()
{		
	return (g_isSupportAudio && (parseInt("<%audioinenable%>") == 0));  //"<%audioinenable%>" = 0/1 = enable/disable				
};

function ChangeLanguage()
{
//--start 2010.12.27 modified
  i = c_langSel.GV();
  mui = langIDList[i];
  
  if(g_supportnvrbased)
	SendHttp("/cgi-bin/setmultilanguage.cgi?mui=" + mui, false, MuiOK);
  else
    SendHttp(c_iniUrl+"&mui=" + mui, false, MuiOK);
//--end 2010.12.27
};

function MuiOK()
{
  if(g_SubmitHttp.readyState==4 && g_SubmitHttp.status==200)
  {
    try
    {	
		if(g_supportnvrbased)
			location.href="index.htm";
		else{
			var txt = g_SubmitHttp.responseText;
			var x = txt.indexOf("OK mui");
			if(x >= 0)
				location.href="index.htm";
			 
		}
      
    }
    catch (e){};
  }
};

function WriteLeftSideTable()
{
  var o='';
  o+='<table width="125" border="0" height="100%">';
  o+='<tr><td id="sidenav_container"><p align="center">';
  //--start 2012.3.22 added
  if(g_supgioin == 0)
  {
	o+=AddLightBtn("motionIcon",0,0,42,38,"motion_notification_on.gif","motion_notification_off.gif",null,GL("motionIcon_alt"));
	o+=AddLightBtn("recordIcon",0,0,40,37,"server_recorde_on.gif","server_recorde_off.gif",null,GL("recordIcon_alt"));
  } //--end 2012.3.22
  else if(g_supgioin == 1)
  {
    o+=AddLightBtn("gpInputIcon1",0,0,32,37,"digital_input_on_1.gif","digital_input_off_1.gif",null,GL("gpInputIcon_alt"));
	o+=AddLightBtn("motionIcon",0,0,42,38,"motion_notification_on.gif","motion_notification_off.gif",null,GL("motionIcon_alt"));
	o+=AddLightBtn("recordIcon",0,0,40,37,"server_recorde_on.gif","server_recorde_off.gif",null,GL("recordIcon_alt"));
  }
  else
  {
	if (g_isSupportVisca==1)
	{
		o+=AddLightBtn("gpInputIcon1",0,0,24,30,"v_digital_input_on_1.gif","v_digital_input_off_1.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon2",0,0,24,30,"v_digital_input_on_2.gif","v_digital_input_off_2.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon3",0,0,24,30,"v_digital_input_on_3.gif","v_digital_input_off_3.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon4",0,0,24,30,"v_digital_input_on_4.gif","v_digital_input_off_4.gif",null,GL("gpInputIcon_alt"));
		o+='<br>';
		o+=AddLightBtn("gpInputIcon5",0,0,24,30,"v_digital_input_on_5.gif","v_digital_input_off_5.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon6",0,0,24,30,"v_digital_input_on_6.gif","v_digital_input_off_6.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon7",0,0,24,30,"v_digital_input_on_7.gif","v_digital_input_off_7.gif",null,GL("gpInputIcon_alt"));
		o+='&nbsp;';
		o+=AddLightBtn("gpInputIcon8",0,0,24,30,"v_digital_input_on_8.gif","v_digital_input_off_8.gif",null,GL("gpInputIcon_alt"));
		o+='<br><br>';
	}
	else
	{
		o+=AddLightBtn("gpInputIcon1",0,0,32,37,"digital_input_on_1.gif","digital_input_off_1.gif",null,GL("gpInputIcon_alt"));
		//o+='<img title="'+GL("gpInputIcon_alt")+'" alt="'+GL("gpInputIcon_alt")+'" src="digital_input_off_1.gif" name="gpInputIcon1" id="gpInputIcon1" width="32" height="37">';
		o+='&nbsp;&nbsp;&nbsp;&nbsp;';
		o+=AddLightBtn("gpInputIcon2",0,0,32,37,"digital_input_on_2.gif","digital_input_off_2.gif",null,GL("gpInputIcon_alt"));
		//o+='<img title="'+GL("gpInputIcon_alt")+'" alt="'+GL("gpInputIcon_alt")+'" src="digital_input_off_2.gif" name="gpInputIcon2" id="gpInputIcon2" width="32" height="37">';
		o+='<br>';	
	}
    o+=AddLightBtn("motionIcon",0,0,42,38,"motion_notification_on.gif","motion_notification_off.gif",null,GL("motionIcon_alt"));
    //o+='<img title="'+GL("motionIcon_alt")+'" alt="'+GL("motionIcon_alt")+'" src="motion_notification_off.gif" name="motionIcon" id="motionIcon" width="42" height="38">';
    o+='&nbsp;&nbsp;';
    o+=AddLightBtn("recordIcon",0,0,40,37,"server_recorde_on.gif","server_recorde_off.gif",null,GL("recordIcon_alt"));
    //o+='<img title="'+GL("recordIcon_alt")+'" alt="'+GL("recordIcon_alt")+'" src="server_recorde_off.gif" name="recordIcon" id="recordIcon" width="40" height="37">';
  }
  o+='</p></td></tr>'; 
  
  o+='<tr height="60" vAlign="top" ><td><div id="sidenav"><div id="sidenavoff">'+GL("camera")+'</div><div><a href="checkout.htm">'+GL("logout")+'</a></div></div></td></tr>';
//--2011.1.27 modified
  //o+='<tr><td><font color="#ffffff">'+GL("sd_status")+':'+'<div id="sdStatusStr" align="right" >&nbsp;</div></font></td></tr>';
  o+='<tr><td id="sdblock" style="display:'+(g_supportsdhide==1?'none':'block')+';"><font color="#ffffff">'+GL("sd_status")+':'+'<div id="sdStatusStr" align="right" >&nbsp;</div></font></td></tr>';
//--2011.1.27
  
//--start 2012.3.22 modified
  if(g_supgioout>0)
	o+='<tr><td><font color="#ffffff">'+GL("io_status")+':'+'<div id="iostatus" align="right" >&nbsp;</div></font></td></tr>';
//--end 2012.3.22

  if(g_supportwhitelightled)
  {
	o+='<tr><td><div id="whitelightLivebox"></div></td></tr>';
  }


  //to do ptz
  if(g_isShowPtzCtrl && !IsViewer())
  {
    o+=PtzCtrl();
  }
  
  if( (g_supportFishEye || g_supportfish_v2) && !IsViewer())
  {
	o+=FishCtrl();
  }	
  
  o+='<tr vAlign="top" ><td><br><font color="#ffffff">'+GL("select_language")+'</font><br>';
  o+=c_langSel.html;
  o+='</td></tr></table>';
  
  DW(o);
};

function WriteLiveVideoTable()
{
  var o='';
  o+='<div id="maincontent">'
  o+=GetDLinkOrangeBox(GL("live_video"),'<div id="boxstr"></div>');
  
  if(g_getprivacystate==1 && g_getprivacycontrol==1)
	o+=GetDLinkBlackBox(GL("live_video"),EnablePrivacyVideoBox());
  else
	o+=GetDLinkBlackBox(GL("live_video"),GetLiveVideoBox());
  o+='</div>';
  DW(o);  
};

function EnablePrivacyVideoBox()
{
 var o='';
    o+='<div align="center">';
	o+=GL("change_live_privacy_txt")+'<a href="maintenance.htm">'+GL("manager")+'</a>';
	o+='</div>';
 return o;

}

function GetLiveVideoBox()
{
  var o='';
  o+='<div align="center" id="ctrlCtx">';

  if (browser_IE)
  {
    if (IsVS())
	{
	  o+=GetTagAX1AndFixSize(1);
	}
	else
      o+=GetTagAX1AndFixSize();
  }	
  else
  {
	mpMode = UpdateGSize(mpMode);
    //v = CheckBrowser();
	//if(v == 'Firefox' || v == 'Chrome')
	if(l_profileformat[mpMode-1]!="JPEG" && l_profilereviewer[mpMode-1]!="2048x1536")	//20140922 modify || -> &&
	{
	  o='<div id="QuickTimeLayer" align="center">';
		o+=CreateIdleQuickTime();
	  o+='</div>';
	}
	else
	{
	  o+=imgFetcher.GetDmsImgStr(g_viewXSize,g_viewYSize);
	}
    //
  }
  o+='</div><br>';


  o+='<table align="center"><tr>';
  o+='<td>';
  if (browser_IE)
  {
	if(g_isSupP1 && g_numProfile>=1 )
		o+=GetDLinkLightBtn("profile1","profile1_on_f.gif","profile1_on_n.gif","profile1_on_p.gif","profile1_off_f.gif","profile1_off_n.gif","profile1_off_p.gif","ShowProfile1");
	if(g_isSupP2 && g_numProfile>=2 )
		o+='&nbsp;'+GetDLinkLightBtn("profile2","profile2_on_f.gif","profile2_on_n.gif","profile2_on_p.gif","profile2_off_f.gif","profile2_off_n.gif","profile2_off_p.gif","ShowProfile2");
	if(g_isSupP3 && g_numProfile>=3 )
		o+='&nbsp;'+GetDLinkLightBtn("profile3","profile3_on_f.gif","profile3_on_n.gif","profile3_on_p.gif","profile3_off_f.gif","profile3_off_n.gif","profile3_off_p.gif","ShowProfile3");
	if(g_isSupP4 && g_IsSupportProfile4 && g_numProfile>=4)
	  o+='&nbsp;'+GetDLinkLightBtn("profile4","profile4_on_f.gif","profile4_on_n.gif","profile4_on_p.gif","profile4_off_f.gif","profile4_off_n.gif","profile4_off_p.gif","ShowProfile4");
  }
  else
  {
    //if(g_isSupAJAX1)
	if(g_isSupP1 && g_numProfile>=1)
      o+=GetDLinkLightBtn("profile1","profile1_on_f.gif","profile1_on_n.gif","profile1_on_p.gif","profile1_off_f.gif","profile1_off_n.gif","profile1_off_p.gif","ShowProfile1");
    //if(g_isSupAJAX2)
	if(g_isSupP2 && g_numProfile>=2)
      o+='&nbsp;'+GetDLinkLightBtn("profile2","profile2_on_f.gif","profile2_on_n.gif","profile2_on_p.gif","profile2_off_f.gif","profile2_off_n.gif","profile2_off_p.gif","ShowProfile2");
    //if(g_isSupAJAX3)
	if(g_isSupP3 && g_numProfile>=3)
      o+='&nbsp;'+GetDLinkLightBtn("profile3","profile3_on_f.gif","profile3_on_n.gif","profile3_on_p.gif","profile3_off_f.gif","profile3_off_n.gif","profile3_off_p.gif","ShowProfile3");
  }
  
   
  if (browser_IE)
  {
    //o+='<div align="center">';
    //o+=GetDLinkLightBtn("profile1","profile1_on_f.gif","profile1_on_n.gif","profile1_on_p.gif","profile1_off_f.gif","profile1_off_n.gif","profile1_off_p.gif","ShowProfile1");
    //o+='&nbsp;'+GetDLinkLightBtn("profile2","profile2_on_f.gif","profile2_on_n.gif","profile2_on_p.gif","profile2_off_f.gif","profile2_off_n.gif","profile2_off_p.gif","ShowProfile2");
    //if(g_isSupP3)
      //o+='&nbsp;'+GetDLinkLightBtn("profile3","profile3_on_f.gif","profile3_on_n.gif","profile3_on_p.gif","profile3_off_f.gif","profile3_off_n.gif","profile3_off_p.gif","ShowProfile3");
    //o+='&nbsp;'+GetDLinkLightBtn("profile4","profile4_on_f.gif","profile4_on_n.gif","profile4_on_p.gif","profile4_off_f.gif","profile4_off_n.gif","profile4_off_p.gif",null);
    o+='&nbsp;'+GetDLinkLightBtn("screenButton","full_screen_f.gif","full_screen_n.gif","full_screen_p.gif","full_screen_f.gif","full_screen_n.gif","full_screen_p.gif","ShowFullScreen");
    o+='&nbsp;&nbsp;&nbsp;&nbsp;';
    o+='&nbsp;'+GetDLinkLightBtn("snapshotButton","snapshot_f.gif","snapshot_n.gif","snapshot_p.gif","snapshot_f.gif","snapshot_n.gif","snapshot_p.gif","Snapshot");
    o+='&nbsp;'+GetDLinkLightBtn("recordButton","recorde_on_f.gif","recorde_on_n.gif","recorde_on_p.gif","recorde_off_f.gif","recorde_off_n.gif","recorde_off_p.gif","RecordAviSwitch");
    o+='&nbsp;'+GetDLinkLightBtn("pathButton","path_setting_f.gif","path_setting_n.gif","path_setting_p.gif","path_setting_f.gif","path_setting_n.gif","path_setting_p.gif","ShowSetPath");	
	if(g_isSupportAudio)
		o+='&nbsp;'+GetDLinkLightBtn("listenButton","listen_on_f.gif","listen_on_n.gif","listen_on_p.gif","listen_off_f.gif","listen_off_n.gif","listen_off_p.gif","AudioSwitch");
	
    if(g_isSupportEPTZ != 1 && g_isSupportVisca == 0 && g_supportHisi == 0 && g_supportnvrbased == 0)
	  o+='&nbsp;'+GetDLinkLightBtn("zoomButton","zoomin_f.gif","zoomin_n.gif","zoomin_p.gif","zoomin_f.gif","zoomin_n.gif","zoomin_p.gif","ZoomSwitch");
    
	if(!IsViewer())
    {
	
	  if(g_isSupportTwoWayAudio && g_isHttp)	
		o+='&nbsp;'+GetDLinkLightBtn("streamoutButton","talk_on_f.gif","talk_on_n.gif","talk_on_p.gif","talk_off_f.gif","talk_off_n.gif","talk_off_p.gif","TwoWayAudio");
		
      if(g_supgioin>0)
	    o+='&nbsp;'+GetDLinkLightBtn("gpOutputButton","digital_output_on_f.gif","digital_output_on_n.gif","digital_output_on_p.gif","digital_output_off_f.gif","digital_output_off_n.gif","digital_output_off_p.gif","SetDigitalOutput");

      //o+='&nbsp;'+GetDLinkLightBtn("ledButton","led_on_f.gif","led_on_n.gif","led_on_p.gif","led_off_f.gif","led_off_n.gif","led_off_p.gif",null);
    }
    //o+='</div>';
  }
  else
  {
		o+='&nbsp;'+GetDLinkLightBtn("snapshotButton","snapshot_f.gif","snapshot_n.gif","snapshot_p.gif","snapshot_f.gif","snapshot_n.gif","snapshot_p.gif","Snapshot");
  }
  o+='</td>';
  
  if((g_isSupportEPTZ == 1 && !IsViewer()) || g_isSupportVisca==1 || ( (g_supportFishEye == 1 || g_supportfish_v2 == 1) && !IsViewer()) || g_supportZbc==1 )
  {
    o+='<td>&nbsp;</td>'
	if((g_supportFishEye || g_supportfish_v2) && !IsViewer())
		o+='<td id="gotopreset">'+GL("persetgoto")+'&nbsp;'+fisheyepresetlistname1.html+'</td>';
	else
	if(g_supportZbc==1)
		o+='<td id="gotopreset">'+GL("persetgoto")+'&nbsp;'+zbcpresetselect.html+'</td>';
	else
		o+='<td id="gotopreset">'+GL("persetgoto")+'&nbsp;'+presetselect.html+'</td>';
  }	
  o+='</tr></table>';
  
  return o;
};

var QtProtocol = "";
function CreateQuickTime(profile, protocol)
{
	QtProtocol = protocol;
	
	var RTSPName = GetLiveRtspName(profile);

	var o='';
//start 2010.11.04 added, if user input port number, quicktime will error.
	//var host = location.host.split(":");
	var host;
	if(g_isIPv6)
		host = g_netip;//because ipv6 not support rtsp.
	else
		host = g_host;
//end 2010.11.04

	var port = "";
	if(protocol=="UDP")
		port = g_RTSPPort;
	else
		port = g_Port;
		
	if(port=="")
		port = 80;
	port = (":"+port);
	  
//	if(g_supportFishEye){
	
//		o+=motionlive.GenHtml(g_viewXSize,g_viewYSize);
		
//	}else{
	
		o+='<embed id="qt_embed" width="'+g_viewXSize+'" height="'+g_viewYSize+'" ';
		o+='controller="true" ';
		o+='autoplay="true" ';
		o+='src="qt.mov" ';
		//o+='qtsrcdontusebrowser="" ';
		o+='qtsrc="rtsp://' + host + port + '/' + RTSPName + '" ';
		o+='type="video/quicktime" ';
		o+='scale="ToFit" ';
		o+='>';
//	}
	//alert(o);
	return o;
};

function CreateIdleQuickTime()
{
  var o='';
  o+='<embed id="qt_embed" width="'+g_viewXSize+'" height="'+g_viewYSize+'" ';
  o+='controller="true" ';
  o+='autoplay="false" ';
  o+='src="qt.mov" ';
  o+='qtsrcdontusebrowser="" ';
  o+='bgcolor="black" ';
  o+='qtsrc="" ';
  o+='type="video/quicktime" ';
  o+='scale="ToFit"';
  o+='>';
  
  return o;
};

function ChangeProfile(mode)
{
  var obj = GE(AxID);
  if (obj != null && GetDLinkLightValue("recordButton") == 1)
  {
	  //--2010.12.21 added
		g_TotalTime = REC_TIME;
		clearTimeout(timerRecordAvi);
	  //--
        obj.RecordAviStop();
  }
  
  if(mpMode == mode)
  {
    SetDLinkLightValue(("profile"+mpMode),1);
    return;
  }
  TurnOffAllProfileBtn();

  mpMode = UpdateGSize(mode);
  SetCookie("MP_MODE", mpMode);
  SetDLinkLightValue(("profile"+mpMode),1);
  //why?? why?? why??  different with appro???  appro is not use this turn on off.
  //isFirstOneshowCoords = true;
  
  StopGetEptzPostion();
  ChangeGlobalViewStatus(false);
  
  //if(g_isEPTZviewer)
  //  if(g_isSupportEPTZ == 1)
  //    g_Cropper.hide();
  
  if(g_isSupportVisca == 0)
    ChangePreset(mode);

//--start 2011.4.27, fix IE9 Live fault.
  location.reload();
  //MY_ONLOAD();
//--end 2011.4.27
};

function ChangePreset(mode)
{
  if(mode == 1)
    SendHttp("vb.htm?paratest=eptzpresetlistname1",false,GetPreset);
  else if(mode == 2)
    SendHttp("vb.htm?paratest=eptzpresetlistname2",false,GetPreset);
  else if(mode == 3)  
    SendHttp("vb.htm?paratest=eptzpresetlistname3",false,GetPreset);
};

function GetPreset()
{
  
  if (g_SubmitHttp.readyState==4)
  {
    if (g_SubmitHttp.status == 200)
    {
	//start 2010.11.4, End of the string are 0xa, but firefor will show Garbled
      var txt=g_SubmitHttp.responseText;
	  txt=txt.substring(0,txt.length-1).split("=");
	//end 2010.11.04
	//start modified--2010.11.17
	  var obj = GE("gotopreset");
	  if(obj != null)
	    obj.innerHTML = '<td id="gotopreset">'+GL("persetgoto")+'&nbsp;'+presetselect.rehtml(txt[1])+'</td></tr>';
	//end modified--2010.11.17
    }
  }
  
};
function SetLiveBoxStr()
{
  var o='';
  
  if(g_getprivacystate==1  && g_getprivacycontrol==1)
  {
	g_viewXSize="";
	g_viewYSize="";
  }
  o+=GL("live_video_boxstr",{1:g_viewXSize,2:g_viewYSize});
  //if(g_sdLock == 1)
  //  o+='<br><font color="#ff0000" face="Arial" >'+GL("sd_card_lock")+'</font>';

  GE("boxstr").innerHTML = o;
  //return o;
};

function TurnOffAllProfileBtn()
{
  SetDLinkLightValue("profile1",0);
  SetDLinkLightValue("profile2",0);
  SetDLinkLightValue("profile3",0);
  SetDLinkLightValue("profile4",0);
}
function ShowProfile1()
{
	if(g_supportFishEye || g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
	
  ChangeProfile(1);
  //SetDLinkLightValue("profile1",1);
};

function ShowProfile2()
{
  if(g_supportFishEye || g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
	
  ChangeProfile(2);
  //SetDLinkLightValue("profile2",1);
};

function ShowProfile3()
{
  if(g_supportFishEye || g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
	
  ChangeProfile(3);
  //SetDLinkLightValue("profile3",1);
};

function ShowProfile4()
{
	if(g_supportFishEye || g_supportfish_v2)
		SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
		
  ChangeProfile(4);
  //SetDLinkLightValue("profile3",1);
};
//var p = window.createPopup();
function ShowFullScreen()
{
 //  window.open("fullscreen.htm",'fullscreen','fullscreen=1,directories=0, location=0, menubar=0, resizable=0, scrollbars=0, status=0, titlebar=0, toolbar=0, scrollbars="no"');
  //window.moveTo(0,0);
  //window.resizeTo(screen.availWidth,screen.availHeight);
  //setTimeout("RunFS()",500);
  
  var obj = GE(AxID);
  if (obj != null)
  { 
    obj.FullScreen();
  }
  
}
function RunFS()
{
  var obj = GE(AxID);
  if (obj != null)
  {
    obj.EnableFullScreen(1);
  }
}
function GetDateStr(pfx,tail)
{
  var y,M,d,h,m,s,ms;
  var myDate = new Date();
  if (browser_FireFox)
  {
    y=FixNum(myDate.getYear()+1900,4);
  }
  else
  {
    y=FixNum(myDate.getYear(),4);
  }
  M=FixNum(myDate.getMonth()+1,2);
  d=FixNum(myDate.getDate(),2);
  h=FixNum(myDate.getHours(),2);
  m=FixNum(myDate.getMinutes(),2);
  s=FixNum(myDate.getSeconds(),2);
  ms=parseInt((myDate.getTime() % 1000)/100);
  return (g_titleName+"_"+y+M+d+h+m+s+ms+"."+tail);
  //return (pfx + "_"+g_titleName+"_"+y+M+d+h+m+s+ms+"."+tail);
}
function CheckSavePath()
{
  if(savePath=="" || savePath==null)
  {
    alert(GL("err_storage_folder"));
    return false;
  }
  return true;
}

//function PopupPage(URL,id,x,y,w,h)
//{
  //var fullProps = "dialogLeft:"+x+"px;dialogTop:"+y+"px;dialogWidth:"+w+"px;dialogHeight:"+h+"px;";
  //fullProps+="resizable:no;scrollbars:no;status:no";
  //showModalDialog(URL,id,fullProps);
//};

function Snapshot()
{
  if (browser_IE)
  {
    if(CheckSavePath())
    {
      var obj = GE(AxID);
      if (obj != null)
      {
        //obj.SaveCurrentImageWithText(savePath+ GetDateStr("Snapshot_","jpg"), "", 0); //0x55 show time and date
        //obj.SaveCurrentImageWithText(savePath+ GetDateStr("","jpg"), "", 0); //0x55 show time and date
        obj.Snapshot(savePath+ GetDateStr("","jpg"));
      }
    }
  }
  else
  {
    PopupPage("/dms?nowprofileid="+mpMode+"&"+Math.random(),'Snapshot',0,0,g_viewXSize,g_viewYSize);
  }  
}

var l_profilerate = new Array("<%profile1rate%>","<%profile2rate%>","<%profile3rate%>","<%profile4rate%>");
var timerRecordAvi = null;
var REC_TIME = 30;
var g_TotalTime = REC_TIME;
var g_AviQuality = 100;
function RecordAviSwitch()
{
  if(CheckSavePath())
  {
    var obj = GE(AxID);
    if (obj != null)
    {
      if (GetDLinkLightValue("recordButton") == 1)
      {
	    //mpMode = GetCookieInt("MP_MODE",1);
		//if(mpMode == 1) 
		  //g_GetProFileFPS = "getprofile1fps";
		//if(mpMode == 2) 
          //g_GetProFileFPS = "getprofile2fps";
		//if(mpMode == 3) 
		  //g_GetProFileFPS = "getprofile3fps";
		  
		//SendHttp(c_iniUrl+"&"+g_GetProFileFPS,true,GetFPS);
		savePath = GetCookieStr("SAVE_PATH","");
		//alert(g_GetFPS);
		obj.RecordParam(60, 0, 0);//60sec, datetime, avi
        //obj.RecordAviStart(savePath+ GetDateStr("","avi"),parseInt(g_AviQuality),parseInt(g_GetFPS));
        //obj.RecordAviStart(savePath+ GetDateStr("","avi"),parseInt(g_AviQuality),parseInt(l_profilerate[mpMode-1]));
        obj.RecordAviStart(savePath+g_titleName, parseInt(g_AviQuality), parseInt(l_profilerate[mpMode-1]));
		
		//--2010.12.21 added
		timerRecordAvi = setTimeout("CheckRecordAviStart()",1000);
		//--
      }
      else
      {
	  //--2010.12.21 added
		g_TotalTime = REC_TIME;
		clearTimeout(timerRecordAvi);
	  //--
        obj.RecordAviStop();
      }
    }
  }
  else
  {
    SetDLinkLightValue("recordButton",0);
  }
}

//--2010.12.21 added, copy from appro
function CheckRecordAviStart()
{
	var obj = GE(AxID);
	if (obj != null)
	{
		//g_TotalTime--;

//start modified--2010.11.23
		//if(parseInt(g_TotalTime) >= 0 && obj.GetAviRecordStatus()==1)
		if(obj.GetAviRecordStatus()==1)
		//if(parseInt(g_TotalTime) >= 0)
//end modified--2010.11.23
		{
			timerRecordAvi = setTimeout("CheckRecordAviStart()",1000);
		}
		else
		{
			//g_TotalTime = REC_TIME;
			//obj.RecordAviStop();
			//obj.RecordAviStart(savePath+ GetDateStr("","avi"),parseInt(g_AviQuality),parseInt(l_profilerate[mpMode-1]));
			//timerRecordAvi = setTimeout("CheckRecordAviStart()",1000);
			SetDLinkLightValue("recordButton", 0);
		}
	}
};
//--

function GetFPS()
{
if(g_SubmitHttp.readyState==4)
  {
    if(g_SubmitHttp.status==200)
    {
      try
      {
        var txt=g_SubmitHttp.responseText;
        var ix = txt.split("OK "+g_GetProFileFPS+"=");
		//alert(ix);
		//alert(ix.length);
        if(ix.length>=0)
        {
          g_GetFPS = ix[1];		  
        }
		else
		{
		  g_GetFPS = 15;
		}
      }
      catch (e){};
    }
  }
}

function ShowSetPath()
{
  var obj = GE(AxID);
  if (obj != null)
  {
    savePath = obj.BrowserFolder(savePath);
    SetCookie("SAVE_PATH",savePath);
  }
};

function AudioSwitch()
{   
	  var auOn = 0;
	  
	   if(g_enmute== 1){  // 0/1 =>disable/enable
		  SetDLinkLightValue("listenButton",0);  // let img can't change if  second value=0;
		  return;
	   }
	 
	  if ( Chk_AudioIn() )
	  {       
			auOn = !GetDLinkLightValue("listenButton");
		 
			if(auOn==0)
			{   
				var obj = GE(AxID);
				if(obj!=null)
					obj.AudioPlayerEnable = 1;
				DLinkLightSwitch("listenButton");
			}
			else if(auOn==1)
			{ 
				var obj = GE(AxID);
				if(obj!=null)
					obj.AudioPlayerEnable = 0;
				DLinkLightSwitch("listenButton");
			}			
			
	  }
/*
 //ben 20100706////////////////
  var auon = "<%audioinenable%>";
  //hard code,if litsen audio in off, don't light up button
  //notic:audioinenable = 1 -> "audio in off" checkbox is selected, means off audio
  //
  if(auon == 1){  
    SetDLinkLightValue("listenButton",0);
	return;
  }
  //end of ben 20100706////////////////	

  StartAX();
*/
};

function ZoomSwitch()
{
  var obj = GE(AxID);
  if (obj != null)
  {
    obj.PreviewZoom();
  }
};
var timerIDTalk = null;
var g_TalkTime = 0;
function TwoWayAudio()
{
 
 //hard code,if Audio out off, don't light up button
 //notic:audiooutenable = 1 -> "audio out off" checkbox is selected, means off talk 
 var auout = parseInt(GV("<%audiooutenable%>", 0)); 

  if( auout == 1){  // 0/1 =>enable audio out/disable audio out
	  SetDLinkLightValue("streamoutButton",0);  
	  return;
	 
 }
  else
  {          
 
    var obj = GE(AxID);
    if (obj == null)
    {	
		  SetDLinkLightValue("streamoutButton",0);
		  return;
    }

    if (GetDLinkLightValue("streamoutButton") == 1)
    {
		 //start 2010.11.04 added, if user input port number, activex will error.		  
		 //
		  if(g_audioType=="AAC" && g_supportHisi==1)
			g_TalkTime = obj.StartTwoWayAudioForSamplerate(g_host,0,0,3,16000);
		  else
			g_TalkTime = obj.StartTwoWayAudio(g_host,0,0,3);
		  //end 2010.11.04
	      
		  if(g_TalkTime > 0)
		  {
			timerIDTalk = setTimeout('StopTwoWayAudio()',parseInt(g_TalkTime)*1000);//2011.7.11 modified
		  }
		  else
		  {
			SetDLinkLightValue("streamoutButton",0);
		  }
    }
    else
    {
		  obj.StopTwoWayAudio();
		  clearTimeout( timerIDTalk );
    }
    //alert("To control 2 way Audio.");
  }
};

//--start 2011.7.11 added
function StopTwoWayAudio()
{
	var obj = GE(AxID);
	if (obj != null)
	{
		obj.StopTwoWayAudio();
		SetDLinkLightValue("streamoutButton",0);
		clearTimeout( timerIDTalk );
	}
}
//--end 2011.7.11

//function Chk_TwoWayAudio()
//{
//  return ("<%audiooutenable%>" == 1);
//};

function SetDigitalOutput()
{	
  //var o = c_iniUrl+"&allgiooutenable="+GetDLinkLightValue("gpOutputButton");
  if(g_iodostatus)
  {
    if(g_alwayGioOn)
      var o = c_iniUrl+"&giooutalwayson=1:0";
	else
	  var o = c_iniUrl+"&giooutreset=1:1"
  }
  else
  {
    var o = c_iniUrl+"&giooutalwayson=1:"+GetDLinkLightValue("gpOutputButton");
  
  }
  SendHttp(o,false);
};

var SendEPTZStatusHttp = null;
function SendEPTZWorker()
{
  SendEPTZStatusHttp = null;
  SendEPTZStatusHttp = InitXHttp();
  SendEPTZStatusHttp.onreadystatechange = GetEPTZStatus;
  try
  {
	SendEPTZStatusHttp.open("GET", "/vb.htm?geteptzstatus", true);
    SendEPTZStatusHttp.setRequestHeader("If-Modified-Since","0");
    SendEPTZStatusHttp.send(null);
  }catch(e){};
  //g_httpOK = true;
};

function GetEPTZStatus()
{
  if (SendEPTZStatusHttp.readyState==4)
  {
    if (SendEPTZStatusHttp.status != 200)
    {
      clearTimeout(timerEPTZ); //add 2015.1.20
	  timerEPTZ = null;
    }
    else
    {
		var list = SendEPTZStatusHttp.responseText;
		
		var iy = list.indexOf("UA geteptzstatus");
		if(iy>=0){
			clearTimeout(timerEPTZ); //add 2015.1.20
			timerEPTZ = null;
			return false;
		}
	
		var list = SendEPTZStatusHttp.responseText.split('=');
		if(list.length==2){
			var pan = list[1].substr(0,1);
			var preset = list[1].substr(1,1);
			CheckEPTZLight(pan,preset);
		}
		timerEPTZ = setTimeout("SendEPTZWorker()",1000);
		
		delete list;
	}
  }	
};
function SetLDC()
{	
  var o = c_iniUrl+"&ldcenable="+GetDLinkLightValue("ldcButton");

  SendHttp(o,false);
};

function CheckEPTZLight(pan,preset)
{
//start added--2010.11.17
  var panobj = GE("img_pan");
  var seqobj = GE("img_seq");
  if(panobj==null || seqobj==null)
	return;
//end added--2010.11.17
  
//start modified--2010.11.17
  if(mpMode == 1)
  {
    if( ((pan&0x1)!=0)?1:0 ){
	  panobj.src = "/pan-on_n.gif";
	  AutoPanOn = true;//--2010.12.21 added
	}else{
	  panobj.src = "/pan-off_n.gif";  
	  AutoPanOn = false;//--2010.12.21 added
	}  
	if( ((preset&0x1)!=0)?1:0 ){
	  seqobj.src = "/seq-on_n.gif";
	  SequenceOn = true;//--2010.12.21 added
	}else{  
	  seqobj.src = "/seq-off_n.gif"; 
	  SequenceOn = false;	  //--2010.12.21 added
	}
  }
  else if(mpMode == 2)
  {
    if( ((pan&0x2)!=0)?1:0 ){
	  panobj.src = "/pan-on_n.gif";
	  AutoPanOn = true;//--2010.12.21 added
	}else{  
	  panobj.src = "/pan-off_n.gif";
	  AutoPanOn = false;//--2010.12.21 added
	} 
	if( ((preset&0x2)!=0)?1:0 ){
	  seqobj.src = "/seq-on_n.gif";
	  SequenceOn = true;//--2010.12.21 added
	}else{  
	  seqobj.src = "/seq-off_n.gif"; 
	  SequenceOn = false;		  //--2010.12.21 added
	}	  
  }
  else if(mpMode == 3)
  {
    if( ((pan&0x4)!=0)?1:0 ){
	  panobj.src = "/pan-on_n.gif";
	  AutoPanOn = true;//--2010.12.21 added
	}else{  
	  panobj.src = "/pan-off_n.gif";
	  AutoPanOn = false;//--2010.12.21 added
	}  
	if( ((preset&0x4)!=0)?1:0 ){
	  seqobj.src = "/seq-on_n.gif";
	  SequenceOn = true;//--2010.12.21 added
	}else{  
	  seqobj.src = "/seq-off_n.gif"; 
	  SequenceOn = false;	//--2010.12.21 added
	}
  }
//end modified--2010.11.17
  
  //--2010.12.27 added
  if(AutoPanOn || SequenceOn)
  {
	if(g_isEPTZviewer)
	{
		if(EptzPositonWorking && EptzPostionProfile!=mpMode)
			StopGetEptzPostion();
			
		if(!EptzPositonWorking)
			StartGetEptzPostion();
	}
	else
	{
		if(EptzPositonWorking)
			StopGetEptzPostion();
	}
  }
  else
  {
	if(EptzPositonWorking)
		StopGetEptzPostion();
  }
  //--end 2010.12.27
  
};

//--start 2012.12.24 added for speed dome
var SendPTZStatusHttp = null;
function SendPTZWorker()
{
	SendPTZStatusHttp = null;
	SendPTZStatusHttp = InitXHttp();
	SendPTZStatusHttp.onreadystatechange = GetPTZStatus;
	try
	{
		SendPTZStatusHttp.open("GET", "/vb.htm?paratest=autopan_icon_status&paratest=sequence_icon_status&paratest=cruise_icon_status", true);
		SendPTZStatusHttp.setRequestHeader("If-Modified-Since","0");
		SendPTZStatusHttp.send(null);
	}catch(e){};
	//g_httpOK = true;
};

function GetPTZStatus()
{
	if (SendPTZStatusHttp.readyState==4)
	{
		if (SendPTZStatusHttp.status != 200)
		{
			//WS(GL("fail_"));
			timerPTZ = setTimeout("SendPTZWorker()",1000);
		}
		else
		{
			var autopan = 0, sequence = 0, cruise = 0;
			var txt = SendPTZStatusHttp.responseText;

			var ix = txt.indexOf("OK autopan_icon_status=");
			if(ix >= 0)
			{
				autopan = txt.substring(ix+23, ix+24);
			}

			var ix = txt.indexOf("OK sequence_icon_status=");
			if(ix >= 0)
			{
				sequence = txt.substring(ix+24, ix+25);
			}

			var ix = txt.indexOf("OK cruise_icon_status=");
			if(ix >= 0)
			{
				cruise = txt.substring(ix+22, ix+23);
			}
			
			CheckPTZLight(autopan, sequence, cruise);
			timerPTZ = setTimeout("SendPTZWorker()", 1000);
		}
	}
};

function CheckPTZLight(autopan, sequence, cruise)
{

 	var panobj = GE("img_pan");
	if(panobj!=null && autopan!=null){
		if(autopan=="1"){
			panobj.src = "/v_pan-on_n.gif";
		}else{
			panobj.src = "/v_pan-off_n.gif";  
		}
	}

 	var seqobj = GE("img_seq");
	if(seqobj!=null && sequence!=null){
		if(sequence=="1"){
			seqobj.src = "/v_seq-on_n.gif";
		}else{
			seqobj.src = "/v_seq-off_n.gif";  
		}
	}
  
 	var cruobj = GE("img_cruise");
	if(cruobj!=null && cruise!=null){
		if(cruise=="1"){
			cruobj.src = "/v_cruise_on_n.gif";
		}else{
			cruobj.src = "/v_cruise_off_n.gif";
		}
	}

};
//--end 2012.12.24

/*
var JOYSTICK_MIN = 0;
var JOYSTICK_MID = 32767;
var JOYSTICK_MAX = 65535; 
var JOYSTICK_FIXNUM = 3000;

function StartEPTZWorker()
{
  if(browser_IE)
  {
    var obj = GE(AxID);
	if(obj!=null)
	{
	  if(obj.GetIsJoystick() == 1)
	  {
	    var x1 = parseInt( obj.GetJoystickX() );
	    var y1 = parseInt( obj.GetJoystickY() );
	  }
	  else
      {
	  
	  }
	  timerEPTZJoystick = setTimeout("StartEPTZWorker()",50);
	}
  }
  else
  {
  
  }
};
*/

var SendViscaStatusHttp = null;
//var SendViscaStep = 0;
function StartViscaWorker()
{
  //"&getviscaalarmout&getzoomratio";
  //SendViscaStep = 0;
  SendViscaWorker("/cgi-bin/visca.cgi?getzoom");
  //SendViscaWorker("/vb.htm?getzoomratio");
};
function SendViscaWorker(url)
{
  SendViscaStatusHttp = null;
  SendViscaStatusHttp = InitXHttp();
  SendViscaStatusHttp.onreadystatechange = GetViscaStatus;
  try
  {
	//SendViscaStatusHttp.open("GET", "/cgi-bin/visca.cgi?getzoom", false);
	//SendViscaStatusHttp.open("GET", "/vb.htm?getzoomratio", false);
	SendViscaStatusHttp.open("GET", url, true);
    SendViscaStatusHttp.setRequestHeader("If-Modified-Since","0");
    SendViscaStatusHttp.send(null);
  }catch(e){};
};
function GetViscaStatus()
{
  if (SendViscaStatusHttp.readyState==4)
  {
    if (SendViscaStatusHttp.status != 200)
    {
      //WS(GL("fail_"));
    }
    else
    {
		//if(SendViscaStep==0){
		//	SendViscaStep = 1;
		//	SendViscaWorker("/vb.htm?getzoomratio");
		//	return;
		//}
		
        //var txt = SendViscaStatusHttp.responseText;
        /*var iz = txt.indexOf("OK getviscaalarmout=");
        if(iz>=0)
        {
          var code = txt.substring(iz+20,iz+21);
          g_alwayGioOn = parseInt(code);
          g_iodostatus = 0;
		  var status;
		  var v;
		  if(g_alwayGioOn==0)
		  {
		    status = 0;
			v=0;
		  }
		  else
		  {
		    status = 3;
			v=1;
		  }

		  //visca's output status use api=getdlinksdstatus
		  ChangeDLinkLightStatus2("gpOutputButton", v ,status);
		  //g_alwayGioOn & g_iodostatus
		  ChangeIndexIOStatus( g_alwayGioOn , g_iodostatus );
        }*/
		
        /*var iw = txt.indexOf("OK getzoomratio=");
        if(iw>=0){
        	var code = txt.substring(iw+16,iw+18);
			if(code=="1X") code = "";
			
        	var ax = GE(AxID);
			if (ax != null){
			
				try	{
					ax.Information = code;
				}
				catch (e){}
			}
		}*/
		/*var list = txt.split("=");
		var zoom = list[1];
		if(zoom=="1X")
			zoom = "";
		
       	var ax = GE(AxID);
		if (ax != null){
			
			try	{
				ax.Information = zoom;
			}
			catch (e){}
		}*/
        //
		
		//if(SendViscaStep==0){
		//	SendViscaStep = 1;
		//	SendViscaWorker(c_iniUrl+"&getzoomratio");
		//}else
		//if(g_ViscaZoomEn)
		//	timerVisca = setTimeout("StartViscaWorker()", g_ViscaInterval);
	}
  }	
};
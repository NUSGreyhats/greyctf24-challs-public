// Public Page list of Maintenance.html
var MENU_ITEM_MAINTENANCE = new Array(
"maintenance_menu_device","maintenance_device.htm",1,
"maintenance_menu_backup_restore","maintenance_backup_restore.htm",1,
"maintenance_menu_firmware_upgrade","maintenance_firmware_upgrade.htm",1,
"checkout","checkout.htm",1);


var _os_language = window.navigator.userLanguage || window.navigator.language;
var CopyrightYear=2017;
var g_viewXSize=0;
var g_viewYSize=0;
var browser_Netscape=false;
var browser_IE=false;
var browser_FireFox=false;
var keyword_Show='';
var keyword_Hide='';
var AxID="VideoCtrl";
var AxRoomID="VideoAxRoom";
var g_MaxSubmitLen=190+720; // it will be over, increase 30
var AxUuid="2D20E99C-1FD7-48EC-9FDF-CF3555B273D4";  //this is for Java Web Page Maker to replace.
var LAry = {};
var LangKeyPrefix = "lang_";
var g_CHID=0;
var CONTENT_PAGE='';
var CONTENT_PAGE_LAST=''; //for link error backup.
var CTRLARY = {};
var c_iniUrl = "/vb.htm?language=ie";
var g_httpOK = true;
var g_SubmitHttp = null;
var g_lockLink = false;  //lock the link , can not access.
var g_CHPageList = "c_sccd.htm;sdigital.htm;aenable.htm;motion.htm;img.htm;imgtune.htm;main.htm;";
var g_badLinkList="^bwcntl\\.htm;^image\\.htm;^update\\.htm;^nftphost\\.htm;^help\\.htm;^ndhcpsvr\\.htm;^nupnp\\.htm;^k_\\w*\\.htm;^p_\\w*\\.htm;^ptz_\\w*\\.htm;^faq\\.htm;^version\\.htm;^index\\.htm;^sccd\\.htm;^armio\\.htm;^svideo\\.htm;^tailpage\\.htm;^mcenter\\.htm;^lang\\.htm".split(";");
var g_AdvMode = 0; //display advance menu. 1:on , 0:off
var g_lastPolicy = 0;
var WCH=null; //WebContentHttp
//set language name , must has order.

var g_langFullNameList=new Array("en_en","zh_cn","zh_tw","cs_cs","nl_nl","fi_fi","fr_fr","de_de","it_it","pl_pl","pt_pt","es_es","sv_sv","hu_hu","ro_ro","tr_tr","ru_ru","ja_ja","ko_ko","br_br","ae_ae","ja_ja");	//20140514	add japanese


var g_langNameList;
var g_langName;
var g_sh_net=true;
var g_sh_pppoe=true;
var g_backList=new Array();
var g_fwdList=new Array();
var NO_STORAGE = 255; //255
var ISNOSTORE=(g_defaultStorage == NO_STORAGE);
//add vt specify , video server not limited.
//it is a stupid way, to check this.
//var g_X=(g_brandName=="vt")&&(!IsVS());
//g_X=false;
var g_isShowUpdate  =( (g_oemFlag0 & 0x00000001) != 0 );
var g_isShowBWCtrl  =( (g_oemFlag0 & 0x00000002) != 0 );
var g_isShowUPnP    =( (g_oemFlag0 & 0x00000004) != 0 );
var fish_count_move=1;

//define codec:
var V_JPEG=1000;
var V_MPEG4=1005;
var V_H264=1010;

/************* Browser **************/
var browser = {
        IE: false,
        FireFox: false,
        Chrome: false,
        Opera: false,
        Safari: false,
        Netscape: false,
        id: function(){
                var url = location.href.substr(location.href.lastIndexOf('/')+1);
                if( url.indexOf("fullScreen.html")<0 && url.indexOf("general_setting.html")<0 ){
                        return isNaN(window.parent.browser_id)?0:window.parent.browser_id;
                }else{
                        return isNaN(window.top.opener.parent.browser_id)?0:window.top.opener.parent.browser_id;
                }
        },
        modelname: function(){
                return "<%modelname%>";
        },
        init: function() {
			var Sys = {};
			var ua = navigator.userAgent.toLowerCase();
			var s;
			var ver_serial = 0;
			(s = ua.match(/edge\/([\d.]+)/)) ? Sys.spartan = s[1] :  //for IE spartan
			(s = ua.match(/msie ([\d.]+)/)) ? Sys.ie = s[1] :  //for IE 6~10
			(s = ua.match(/Trident\/([\d.]+)/i)) ? Sys.ie = s[1] : //for IE 11 later
			(s = ua.match(/opr\/([\d.]+)/)) ? Sys.opera = s[1] :
			(s = ua.match(/firefox\/([\d.]+)/)) ? Sys.firefox = s[1] :
			(s = ua.match(/chrome\/([\d.]+)/)) ? Sys.chrome = s[1] :
			
			(s = ua.match(/version\/([\d.]+).*safari/)) ? Sys.safari = s[1] : 0;
			
			ver_serial = parseInt(s[1].substring(0,s[1].indexOf(".")), 10);
			
			if (Sys.ie || window.ActiveXObject) this.IE = true;
			else if (Sys.spartan) this.Spartan = true;

			else if (Sys.opera) this.Opera = true;
			
			else if (Sys.firefox) this.FireFox = true;

			else if (Sys.chrome && (ver_serial >= 42) ) this.Chrome = true;

			else if (Sys.safari) this.Safari = true;

			else if (document.layers) this.Netscape = true;
        },
        isMozilla : function() {
                return (this.Netscape || this.FireFox);
        },

        noCache: function() {
                var meta='<meta HTTP-EQUIV="pragma" CONTENT="NO-CACHE">';
					meta+='<meta HTTP-EQUIV="Expires" CONTENT="-1">';
					meta+='<meta HTTP-EQUIV="Cache-Control" CONTENT="no-store, no-cache, must-revalidate">';
                DW(meta);

        },

        utf8: function() {
                var meta='<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>'
                DW(meta);
        }
}
browser.init();
/************* Browser **************/
//initialize language name.
{
  var o='';
  var t=g_s_mui;
  var i=0;
  var l_firstkey = _os_language.substring(0,2);    //20140922 add
  var lang_PosArray = new Array();	
	
  while (t > 0)
  {
    if (t%2 == 1)
    {
	  lang_PosArray.push(i);
      o+=g_langFullNameList[i]+";";
    }
    t = Math.floor(t/2);
    i++;
  }
  o = o.substring(0,o.length-1);
  g_langNameList = o.split(";");
  
  if ( g_mui == 255){  // 255 -> 0xff
	
		for(var i=0; i<lang_PosArray.length ;i++){		
			if( _os_language.toLowerCase().replace(/-/gi,"_") == g_langFullNameList[lang_PosArray[i]]){
				g_langName = g_langFullNameList[lang_PosArray[i]];
				g_mui=lang_PosArray[i];
				break;
			}	
		}		
		
		if( typeof g_langName == "undefined" ){			    //20140922 add
			g_langName = l_firstkey + '_' + l_firstkey;
			for(var j=0; j<lang_PosArray.length ;j++)
			{
				if(g_langFullNameList[lang_PosArray[j]]==g_langName){
					g_mui=lang_PosArray[j];					
					break;
				}
			
			}
			
			if(g_mui == 255){
				g_mui=0;
				g_langName = "en_en";
			}	
		}
  }	
  else if (g_langNameList.length == 0 || g_mui < -1 || g_langNameList[0]=="")  g_langName = "en_en";
  else if (g_langNameList.length == 1)  g_langName = g_langNameList[0];  
  else g_langName = g_langFullNameList[g_mui];
}

//This is xml http request object for dynamic fetch html
//var xhttp = null;
var THIS_PAGE = GetWebPageName(location.href);

//check brower type, and set show ,hide keyword.
if (browser.IE)
{
  browser_IE = true;
  keyword_Show = "visible";
  keyword_Hide = "hidden";
}
else if (document.layers)
{
  browser_Netscape = true;
  keyword_Show = "show";
  keyword_Hide = "hide";
}
else
{
  browser_FireFox = true;
  keyword_Show = "visible";
  keyword_Hide = "hidden";
}

//if (IsMpeg4())
//if(g_isSupMpeg4)
//{
//  g_viewXSize = g_mpeg4XSize;
//  g_viewYSize = g_mpeg4YSize;
//}
//else
//{
//  g_viewXSize = g_jpegXSize;
//  g_viewYSize = g_jpegYSize;
//}

//Video Server fix size.
if (IsVS())
{
  g_viewXSize = 320;
  g_viewYSize = (g_isPal) ? 288 : 240;
}
//init the sub menu value
var MENU_ITEM_IMAGE;
var MENU_ITEM_SYSTEM;
var MENU_ITEM_NETWORK;
var MENU_ITEM_APP_SET;
var MENU_ITEM_APP_REC;
var MENU_ITEM_APP_ALARM;

ReloadSubMenu();

function IsMozilla()
{
  return (browser_Netscape || browser_FireFox);
}

function IsInBadLinkList(link)
{
  if (link == null || link == "")
    return false;
  link = link.toLowerCase();
  for(var i=0;i<g_badLinkList.length;i++)
  {
    if (TestRE(link,g_badLinkList[i]))
    {
      return true;
    }
  }
  return false;
}

function TagAX1(id,width,height)
{
  var o='<div id="'+AxRoomID+'" name="'+AxRoomID+'"><OBJECT ID="'+((id == null)?AxID:(AxID+id))+'"';
  o+=' CLASSID="CLSID:'+AxUuid+'"';
  //--2012.10.12 modified 
  o+=' CODEBASE="/VDControl.CAB?'+AxVer+'#version='+AxVer+'" width='+width+' height='+height+'></OBJECT></div>';
  //--2012.10.12 end
  //alert(o);
  return o;  
}

//-----start 2012.04.25 
var KeepDown=false;
function EventMouseClick()
{
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("LMouseClick",	function(x,y){			
			if(g_supportFishEye)
				SendHttpPublic(c_iniUrl+"&LmouseclickX="+x+"&LmouseclickY="+y);
		});
	}
}

function EventMouseDown()
{        
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("LMouseDown", function(x,y){
		
			
			if( g_fisheyeautopan==1 ||  g_fisheyesequence==1){
				ChangeImg("img_pan","pan-off_n.gif");  //for fisheye
				ChangeImg("img_seq","seq-off_n.gif");  //for fisheye
				SendHttpPublic("cgi-bin/fisheye.cgi?prstop=1",false);
				g_fisheyeautopan=0;
				g_fisheyesequence=0; 
			}
			KeepDown=true;  
			
			if(g_supportZbc==1)
				SendHttpPublic('/cgi-bin/zbcmousedrag.cgi?action=0&streamid='+mpMode+'&mousex='+x+'&mousey='+y);		
			else if(g_supportFishEye)			
				SendHttpPublic("/cgi-bin/fisheye.cgi?LmousedownX="+x+"&LmousedownY="+y+"&KeepDown="+KeepDown+"&streamid="+mpMode);
		});  
	}
}

function EventMouseUp()
{	
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("LMouseUp",	function(x,y){
			KeepDown=false;
				
			if(g_supportZbc==1)
				SendHttpPublic('/cgi-bin/zbcmousedrag.cgi?action=1&streamid='+mpMode+'&mousex='+x+'&mousey='+y);
			else if( g_supportfish_v2 == 1)					
				SendHttpPublic("/cgi-bin/fisheye.cgi?winid=" + obj.GetFishWinId() + "&KeepDown=" + KeepDown + "&streamid=" + mpMode);				
			else if(g_supportFishEye)		
				SendHttpPublic("/cgi-bin/fisheye.cgi?LmouseupX="+x+"&LmouseupY="+y+"&KeepDown="+KeepDown+"&streamid="+mpMode);
		});
	}
}

function EventMouseMove()
{	var countEvent=0;
	if(browser_IE){
		var obj = GE(AxID);		
		if(obj!=null){
			obj.attachEvent("LMouseMove",	function(x,y){
				if(KeepDown==true && (countEvent==10 || countEvent==0) && g_supportZbc != 1) 
					SendHttpPublic("/cgi-bin/fisheye.cgi?LmousemoveX="+x+"&LmousemoveY="+y+"&streamid="+mpMode);				    					
		
				countEvent++;						  
				if(countEvent>10)
					countEvent=0;				
			} );  			
		}
	}
		
}
// --end

//-----start 2013.01.30

function EventRMouseClick()
{
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("RMouseClick",	function(x,y){
		
		});
	}
}
function EventRMouseDown(){
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("RMouseDown", function(x,y){
	
	
			
		});
	}
}

function EventRMouseUp(){
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("RMouseUp",	function(x,y){
		
		});
	}
}
//--end

function EventMouseWheel(){
	var obj = GE(AxID);
	if(obj!=null){
		obj.attachEvent("MouseWheelMove",	function(deltra){
		
			if(g_supportZbc==1){
			
				if(deltra==120)
						SendHttpPublic("/cgi-bin/zbcMousewheel.cgi?move=1");			//zoom out
				else if(deltra==-120)
						SendHttpPublic("/cgi-bin/zbcMousewheel.cgi?move=-1"); // zoom in
			}					
			
		});
	}
}
//--end

// for zbc ����
//add 2013.01.31
function chkAXfocus()
{
	var mousewheelevt=(/Firefox/i.test(navigator.userAgent))? "DOMMouseScroll" : "mousewheel" //FF doesn't recognize mousewheel as of FF3.x
		
	if (document.attachEvent) //if IE (and Opera depending on user setting)
		document.attachEvent("on"+mousewheelevt, displaywheel)
	else if (document.addEventListener) //WC3 browsers
		document.addEventListener(mousewheelevt, displaywheel, false) 

}

function displaywheel(e){
    var evt=window.event || e //equalize event object
    var delta=evt.detail? evt.detail*(-120) : evt.wheelDelta //check for detail first so Opera uses that instead of wheelDelta

	
	if( (delta==-120 || delta==-360) && evt.altKey==1)
		{
			if(browser_IE)
				{
					var obj = GE(AxID);
					if (obj != null)
						obj.focus();
				}		
		}	
	else if( (delta==120 || delta==360) && evt.altKey==1)
		{
			if(browser_IE)
				{
					var obj = GE(AxID);
					if (obj != null)
						obj.focus();
				}	
		
		}	
}
//end 2013.01.31

function ChangeAx2Pic(w,h,forceWait)
{
  var rooms = GES(AxRoomID);
  if (rooms != null)
  {
    if (w == null)
    {
      if (rooms.length > 1 || CONTENT_PAGE != "main.htm")
      {
        w=320;
        h=240;
      }
      else
      {
        w=640;
        h=480;
      }
    }
    var o='<img src="noActiveX.gif" ';
    o+=' width="'+w+'" height="'+h+'"';
    o+=' />';

    for (var i=0;i<rooms.length;i++)
    {
      if (forceWait!=true)
      {
        rooms[i].innerHTML=o;
      }
    }
    
  }
};

function ChangeAx2LimitPic(w,h,forceWait)
{
  var rooms = GES(AxRoomID);
  if (rooms != null)
  {
    if (w == null)
    {
      if (rooms.length > 1 || CONTENT_PAGE != "main.htm")
      {
        w=320;
        h=240;
      }
      else
      {
        w=640;
        h=480;
      }
    }
    var o='<img src="limitfull.gif" ';
    o+=' width="'+w+'" height="'+h+'"';
    o+=' />';

    for (var i=0;i<rooms.length;i++)
    {
      if (forceWait!=true)
      {
        rooms[i].innerHTML=o;
      }
    }
    
  }
};


function GetLiveUrlNoID(ifrmonly,audioEn,sMode)
{
  var o;
 // o = 'http://'+location.host+'/ipcam/'+ (IsMpeg4()?"mpeg4":"mjpeg") + '.cgi?language=ie';
  o = 'http://'+location.host+'/ipcam/';
  //20081219 chirun addand modify for 7313
  if(sMode == 1)
  {
    o+="mjpeg.cgi";
  }
  if (sMode == 2)
  {
    //o+="mpeg4.cgi";
    o+="mjpegcif.cgi";
  }
  if (sMode == 3)
  {
    //o+="mpeg4cif.cgi";
    o+="mpeg4.cgi";
  }
  if (sMode == 4)
  {
    o+="mpeg4cif.cgi";
  }
  
  o+="?language=ie";

  if (ifrmonly == 1)
  {
    o+="&ifrmonly=1";
  }
  if(audioEn == 1)
  {
    o+="&audiostream=1";
  }
  //alert(o);
  return o;
}

//--start 2011.9.23 added for IPv6
//�έp 10F: �Ϊ�:10B���Ӽ�
function cLength(str)
{
	var reg = /([0-9a-f]{1,4}:)|(:[0-9a-f]{1,4})/gi;
	var temp = str.replace(reg,' ');
	return temp.length;
}
/*
 * �P�_ipv6�榡
 * @author yifangyou
 * @version gslb 2011-03-10
 * */
function isIPv6(tmpstr)
{
	//CDCD:910A:2222:5498:8475:1111:3900:2020
	var patrn=/^([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}$/i;
	var r=patrn.exec(tmpstr)
	if(r)
	{
		return true;
	}
	if(tmpstr=="::"){
		return true;
	}
	//F:F:F::1:1 F:F:F:F:F::1 F::F:F:F:F:1�榡
	patrn=/^(([0-9a-f]{1,4}:){0,6})((:[0-9a-f]{1,4}){0,6})$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{    
		var c=cLength(tmpstr);
		if(c<=7 && c>0)
		{
			return true;
		}
	}                
	//F:F:10F::
	patrn=/^([0-9a-f]{1,4}:){1,7}:$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{
		return true;
	}
	//::F:F:10F
	patrn=/^:(:[0-9a-f]{1,4}){1,7}$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{
		return true;
	}
	//F:0:0:0:0:0:10.0.0.1�榡
	patrn=/^([0-9a-f]{1,4}:){6}(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{
		if(r[2]<=255 && r[3]<=255 &&r[4]<=255 && r[5]<=255 )
		return true;
	}
	//F::10.0.0.1�榡
	patrn=/^([0-9a-f]{1,4}:){1,5}:(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{
		if(r[2]<=255 && r[3]<=255 &&r[4]<=255 && r[5]<=255 )
			return true;
	}
	//::10.0.0.1�榡
	patrn=/^::(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/i;
	r=patrn.exec(tmpstr);
	if(r)
	{
		if(r[1]<=255 && r[2]<=255 &&r[3]<=255 && r[4]<=255)
			return true;
	}
	return false;
}

//fix for Chrome safari opera, remove [ and ].
var tmpipv6 = location.hostname;
tmpipv6 = tmpipv6.replace(/\[/ig, '');		//replace [
tmpipv6 = tmpipv6.replace(/\]/ig, '');		//replace ]
//alert(tmpipv6);
//

g_isIPv6 = isIPv6(tmpipv6);

//Initial IPv6
if(g_isIPv6)
{
	g_host = tmpipv6;
}
else//IPv4
{
	g_host= location.hostname;
}
//alert(g_host);
//--end 2011.9.23 added for IPv6

function GetLiveRtspName(profile)
{
	if(profile == 1)
		return g_RTSPName1;
	else if(profile == 2)
		return g_RTSPName2;
	else if(profile == 3)
		return g_RTSPName3;
}


//forceWait: do not show the graph message. it will wait the ActiveX be installed.
//mode:99 is for display title
function StartActiveXOneEx(ifrmonly,audioEnable,codec,isFocusWindow,axid,mode,forceWait,isMode4)
{
  var obj = (axid == null) ? GE(AxID) : GE(AxID+axid) ;
  
  //var g_Stream = GetCookie("StreamType");
  //if(g_Stream!=null)
	g_StreamType = 3;//default is http
	if(!g_isIPv6)
	{
		switch(mpMode){
		case 1:
			if(g_numProfile>=1 && g_pf1mcen==1)
				g_StreamType = 1;//is multicase
			break;
		case 2:
			if(g_numProfile>=2  && g_pf2mcen==1)
				g_StreamType = 1;//is multicase
			break;
		case 3:
			if(g_numProfile>=3  && g_pf3mcen==1)
				g_StreamType = 1;//is multicase
			break;
		}
	}
  
  
  if (obj != null)
  {
    try
    {
	  obj.Stop();
	  obj.IsIPv6 = g_isIPv6;
	  obj.StreamType = g_StreamType;
	  
//This is for HTTP
	  //url = location.host.split(":");
      obj.URL = g_host;
      obj.User = "";
      obj.Password = "";
	
	  //alert(mpMode)
	  if(audioEnable)
	  {
        obj.ReqCommand = '/ipcam/stream.cgi?nowprofileid='+mpMode+'&audiostream=1';
		//obj.IsPlayAudio = 1;
	  }
	  else
	  {
	    obj.ReqCommand = '/ipcam/stream.cgi?nowprofileid='+mpMode+'&audiostream=0';
		//obj.IsPlayAudio = 0;
	  }
      if(isMode4 == 1)
	    obj.ReqCommand = '/ipcam/stream.cgi?nowprofileid=4';
	
	  switch(window.location.protocol)
      {
        case "http:":
          obj.IsHttps = 0;
		  if(g_Port == "" || g_Port == "null" || g_Port == " " || g_Port == null || isNaN(g_Port))
            g_Port = 80;
        break;
        case "https:":
          obj.IsHttps = 1;
		  if(g_Port == "" || g_Port == "null" || g_Port == " " || g_Port == null || isNaN(g_Port))
            g_Port = 443;
        break;
        default:
          obj.IsHttps = 0;
		  if(g_Port == "" || g_Port == "null" || g_Port == " " || g_Port == null || isNaN(g_Port))
            g_Port = 80;
        break;
      }
	  obj.HttpPort = g_Port;
	  
// displaymode

		obj.DisplayMode=fish_mode;		 	  
			
//This is For RTSP.
		obj.RtspServer = g_host;
		obj.RtspPort = g_RTSPPort;
		obj.RtspName = GetLiveRtspName(mpMode);
		obj.RtspSupportAudio = audioEnable;		
//
	  
	  if((g_isSupportEPTZ == 1) && (mode == 4))
	    SetEPTZPoint(obj,isFocusWindow);
	
	  //---start---	2010.11.3 added
	  obj.IsSupportJoystick = g_SupportJoystick && (l_profileresolution[mpMode-1]!=l_profilereviewer[mpMode-1]) && !IsViewer();
	  //---end---	2010.11.3
	  
	  //---start---	2012.07.11 added
	  obj.IsSupportJoystickFish = !IsViewer() && g_supportFishEye;
	  //---end---	2012.07.11

	  //---start---	2013.11.19 added
	  obj.IsSupportHisi = g_supportHisi;
	  //---end---

	  if(mode == 6)	
	    obj.AFLocation = g_AutoFocusLocation;
      //Status 0 is none, 1 is Privacy Mask , 2 is motion ,3 is Zoom, 4 is focus in/out, 5 is ???, 6 is FOCUS9, 7 is Motion dyna,8,9 is JOYSTICKFISH,10 is FOCUS16x8
	  else if(mode==10)
		obj.AFLocation16x8 = g_AutoFocusLocation;
		
      obj.Status(mode);
	  
	  //alert(g_viewXSize+":"+g_viewYSize);
      obj.Width = g_viewXSize;
      obj.Height = g_viewYSize;
	
	//--start 2011.6.21 add for test
	  obj.AudioAmplifyRatio = g_audioAmplifyRatio;
	//--end 2011.6.21
	
	//--start 2011.6.21 add for ALC
	  if(g_supportFishEye==1)
		obj.EnableALC = 1;
	//--end 2011.6.21
	  
	  //0:ulaw 1:g726  2:aac
	  var audiotype = 0;
	  if(g_audioType == "G.711")
	    audiotype = 0;
	  if(g_audioType == "G.726")
        audiotype = 1;
	//--start 2011.10.4
	  if(g_audioType == "AAC")
        audiotype = 2;
	//--end 2011.10.4
	  obj.AudioType = audiotype;
	  
	  //1 is keep , 0 is not
	  obj.KeepFocusWindow = g_KeepFocusWindow;
      //motion
	  if(g_profileCheckMode == 1)
	  {
        obj.Motionxblock = 12;
        obj.Motionyblock = 8;
	  }
      else{
		obj.Motionxblock = g_motionBlock_Width;
		obj.Motionyblock = g_motionBlock_Height;
      }
	  
	
	
	  if(g_supportmotion_windowmode){
	
		 obj.MotionRectNumber = g_maxmotionarea_window;  // for nvrbased		 		
		 obj.MotionBlock = g_motionwindowarea;
	  }
	 else
		obj.MotionBlock = g_motionBlock;
	  
	//start 2010.11 added for new Motion Dyna mode
	  obj.MotionAmount = g_MotionAmount;
	//end 2010.11
	
      var status = obj.Start();
	  if(status == 503)
	  {
	    ChangeAx2LimitPic(null,null,false);
		alert(GL("limitfull"));
	  }
    }
    catch (e)
    {
      ChangeAx2Pic(null,null,forceWait);
    }
  }
  else
  {
    ChangeAx2Pic();
  }
};

function SetEPTZPoint(obj,isFocusWindow)
{
  
  if(isFocusWindow == 1)
  {
	var x1 = 0;
    var y1 = 0;
    var x2 = 100;
    var y2 = 100;
  }
  else if(isFocusWindow == 0)
  {
    var EPTZx1 = 0;
    var EPTZy1 = 0;
    var size = l_profileresolution[mpMode-1].split('x');
    var resolutionX = size[0];
    var resolutionY = size[1];
    var rateX = resolutionX/g_viewXSize;
    var rateY = resolutionY/g_viewYSize;
    var size = l_profilereviewer[mpMode-1].split('x');
    var EPTZx2 = size[0];
    var EPTZy2 = size[1];
    if(mpMode == 1)
    {
      //EPTZx1 = g_EPTZ1x1;
      //EPTZy1 = g_EPTZ1y1;
    }
    else if(mpMode == 2)
    {
      //EPTZx1 = g_EPTZ2x1;
      //EPTZy1 = g_EPTZ2y1; 
    }
    else if(mpMode == 3)
    {
      //EPTZx1 = g_EPTZ3x1;
      //EPTZy1 = g_EPTZ3y1;  
    }
	var x1 = EPTZx1/rateX;
    var y1 = EPTZy1/rateY;
    var x2 = 120/rateX;
    var y2 = 90/rateY;
    x1 = Math.round(x1);
    y1 = Math.round(y1);
    x2 = Math.round(x2);
    y2 = Math.round(y2);
  }	
  //alert(x1+','+y1+','+x2+','+y2);
  obj.SetFocusWindowPoint(x1,y1,x2,y2);	
};

//id : channel id.
//forceWait: do not show the graph message. it will wait the ActiveX be installed.
//codec: prefer show which codec?
function StartActiveXEx(ifrmonly,audioEnable,codec,chid,axid,mode,forceWait)
{
  var myID = null; 
  if (IsVS())//check is Video-Server
  {
		// id == null mean run all.
		if (chid == null || chid == 0)
		{
			  var i;
			  for (i=1;i<=g_maxCH;i++)
			  {
				StartActiveXOneEx(ifrmonly,audioEnable,codec,i,i,mode,forceWait);
			  }
		}
		else
		{
		  StartActiveXOneEx(ifrmonly,audioEnable,codec,chid,axid,mode,forceWait);
		}
  }
  else
  {   
    //ipcam has no channel
    StartActiveXOneEx(ifrmonly,audioEnable,codec,null,null,mode,forceWait);
  }

};


// get object from id
function GE(name)
{
  return document.getElementById(name);
}
// get obj array from name
function GES(name)
{
  return document.getElementsByName(name);
}
//genernate the "select" html tag
function SelectObject(strName,strOption,intValue,onChange)
{
  DW(SelectObjectNoWrite(strName,strOption,intValue));
}
function SelectObjectNoWrite(strName,strOption,intValue,onChange)
{
  var o='';
  o+='<SELECT NAME="'+strName+'" id="'+strName+'" ';
  if (onChange == null)
  {
    o+='>';
  }
  else
  {
    o+=' onChange="'+onChange+'" >';
  }
  aryOption = strOption.split(';');
  for (var i = 0; i<aryOption.length; i++)
  {
    if(i==intValue)
    {
      o+='<OPTION selected value='+i+'>'+aryOption[i];
    }
    else
    {
      o+='<OPTION value='+i+'>'+aryOption[i];
    }
  }
  o+='</SELECT>';
  return o;
}


//Genernate "select" , the value is number
// include start and end
function CreateSelectNumber(name,start,end,gap,init)
{
  DW(GetSelectNumberHtml(name,start,end,gap,init));
}
//fixNum : the digital fix count.
function GetSelectNumberHtml(name,start,end,gap,init,onChange,onFocus,fixNumC)
{
  var o='';
  o+='<select id="'+name+'" name="'+name+'" class="m1" ';
  if (onChange != null)
  {
    o+=' onchange="'+onChange+'"';
  }
  if (onFocus != null)
  {
    o+=' onfocus="'+onFocus+'"';
  }
  o += '>';
  var i=0;
  
  if(start>end) {
      for (i=start;i>=end;i-=gap)
	  {
		var fixStr = i;
		if(fixNumC != null)
		{
		  fixStr = FixNum(i,fixNumC);
		}
		if(i==init)
		{
		  o+='<option selected value='+i+'>'+fixStr;
		}
		else
		{
		  o+='<option value='+i+'>'+fixStr;
		}
	  }
	  o+='</select>';  
  
  }
  else if(start<=end){
	  for (i=start;i<=end;i+=gap)
	  {
		var fixStr = i;
		if(fixNumC != null)
		{
		  fixStr = FixNum(i,fixNumC);
		}
		if(i==init)
		{
		  o+='<option selected value='+i+'>'+fixStr;
		}
		else
		{
		  o+='<option value='+i+'>'+fixStr;
		}
	  }
	  o+='</select>';
  }
	 
  return o;
}

// return the radio button that be checked.
function GetRadioValue(name)
{
  var value = 0;
  var i;
  var radioObj = GES(name);
  if (radioObj != null)
  {
    for (i=0;i<radioObj.length;i++)
    {
      if (radioObj[i].checked == true)
      {
        value = radioObj[i].value;
        break;
      }
    }
  }
  return value;
}
// if  radio button value equal vv , then check this option.
function SetRadioValue(name,vv)
{
  var i;
  var radioObj = GES(name);
  if (radioObj != null)
  {
    for (i=0;i<radioObj.length;i++)
    {
      if (radioObj[i].value == vv)
      {
        radioObj[i].checked = true;
        break;
      }
    }
  }
}
function IsMpeg4()
{
  return (g_isSupMpeg4);
}


function CreateText(name,size,maxlength,value,isPassword,onChangeFunc)
{
  DW(CreateTextHtml(name,size,maxlength,value,isPassword,onChangeFunc));
}
function CreateTextHtml(name,size,maxlength,value,isPassword,onChangeFunc,onKeyUP,onFocus,onBlur)
{
  var type = "text";
  if (isPassword)
  {
    type = "password";
  }
  else if (size == "0")
  {
    type="hidden";
  }
  var o='';
  o+="<input name='"+name+"' id='"+name+"' type='"+type+"' size='"+size+"' maxlength='"+maxlength+"' value='"+value+"'";
  if (onChangeFunc != null)
  {
    o+=" onChange='"+onChangeFunc+"' ";
  }
  if (onKeyUP != null)
  {
    o+="onKeyup='"+onKeyUP+"' ";
  }
  if (onFocus != null)
  {
    o+="onFocus='"+onFocus+"' ";
  }
  if (onBlur != null)
  {
    o+="onBlur='"+onBlur+"' ";
  }
  o+=">";
  return o;
}



//===================================================
// Validate
//===================================================
//test the reqular expression  , v is value, re is regualar expression
function TestRE(v, re) 
{
	return new RegExp(re).test(v);
}

//check the string is null or blank.
//return ture -> str is not null or ""
//return false -> str is 
function CheckIsNull(str,defMsg,msg,isQuite)
{
  var result = false;
  if (CheckIsNullNoMsg(str))
  {
    if (isQuite != true)
    {
      if (msg != null)
      {
        //alert(msg);
		ShowDLinkWarning(GL(msg));
      }
      else
      {
        //alert(GL("verr_vacuous",{1:defMsg}));
        ShowDLinkWarning(GL("verr_vacuous",{1:defMsg}));
      }
    }
    result = true;
  }
  return result;
}
function CheckIsNullNoMsg(str)
{
  return (str == null || str == "");
}
//===================================================
//check E-Mail
function CheckBadEMail(str,msg,isQuite)
{
  var result = false;
  if (!TestRE(str,'^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+@[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$'))
  {
    if (isQuite != true)
    {
      if (msg == null)
      {
        //alert(GL("verr_email"));
        ShowDLinkWarning(GL("verr_email"));
      }
      else
      {
        //alert(msg);
        ShowDLinkWarning(msg);
      }
    }
    result = true;
  }
  return result;
}
//===================================================
//check the range of number.

//check the range of  number ,include min and max ( min <= x <= max)
//true: the number(str) is not in the range.
function CheckBadNumberRange(str,min,max,defMsg,msg,isQuite,extra)
{
  var result = false;
  var num = parseInt(str);
  var isExtra = (extra != null) ? (num == extra) : (false);
//start--20101111 modified
  if ((!( num >= min && num <= max) && !isExtra) || !CheckIsNumber(str))
  {
    if (isQuite != true)
    {
      if (msg == null)
      {
        if(extra == null)
          //alert(GL("verr_bad_num",{1:defMsg,2:min,3:max}));
		  ShowDLinkWarning(GL("verr_bad_num",{1:defMsg,2:min,3:max}));
        else
          //alert(GL("verr_bad_num_ex",{1:defMsg,2:min,3:max,4:extra}));
		  ShowDLinkWarning(GL("verr_bad_num_ex",{1:defMsg,2:min,3:max,4:extra}));
//end--20101111 modified
      }
      else
      {
        alert(msg);
      }
    }
    result = true;
  }
  return result;
}
//start--20101111 added
function CheckIsNumber(str){
	var reg = /^[0-9]*$/;
	return reg.test(str);
}
//end--20101111
//===================================================
//check the length of the string.
//true: if the length of the string is not in range(minLen <= x <= maxLen)
function CheckBadStrLen(str,minLen,maxLen,defMsg,msg,isQuite)
{
  var result = false;
  if (str == null)
  {
    result = true;
  }
  else
  {
    var len = str.length;
    if (!( len >= minLen && len <= maxLen))
    {
      if (isQuite != true)
      {
        if (msg == null)
        {
          if (minLen != maxLen)
          {
            //alert(GL("verr_str_len",{1:defMsg,2:minLen,3:maxLen}));
            ShowDLinkWarning(GL("verr_str_len",{1:defMsg,2:minLen,3:maxLen}));
          }
          else
          {
            //alert(GL("verr_str_len2",{1:defMsg,2:minLen}));
            ShowDLinkWarning(GL("verr_str_len2",{1:defMsg,2:minLen}));
          }
        }
        else
        {
          //alert(msg);
          ShowDLinkWarning(msg);
        }
      }
      result = true;
    }
  }
  return result;
}


//check string , include the non alphabet or digital char.
//true : found non alphabet or digital char, False: all chars are belong alphabet or digital number
//noCheckNum : do not check digital number. it's mean  only check alphabet
//noCheckLower: do not check lower alphabet,
//noCheckLower: do not check upper alphabet,
function CheckBadEnglishAndNumber(str,defMsg,msg,noCheckNum,noCheckLower,noCheckUpper,isQuite)
{
  var result = false;
  if (str == null)
  {
    result = true;
  }
  else
  {
    var i = 0;
    for (i=0;i<str.length;i++)
    {
      var cc = str.charCodeAt(i);
      var checker = true; //true : means baddly.
      if (noCheckNum == null || noCheckNum == false)
      {
        checker = checker && !(cc>=48 && cc<=57);
      }
      if (noCheckLower == null || noCheckLower == false)
      {
        checker = checker && !(cc>=97 && cc<=122);
      }
      if (noCheckUpper == null || noCheckUpper == false)
      {
        checker = checker && !(cc>=65 && cc<=90);
      }
      if (checker)
      {
        if (isQuite != true)
        {
          if (msg == null)
          {
            alert(GL("verr_eng_digital",{1:defMsg}));
          }
          else
          {
            alert(msg);
          }
        }
        result = true;
        break;
      }
    }
  }
  return result;
}

//--2011.4.12 add
function CheckBadEnglishAndNumberAndSpecialCharEx(str,defMsg,SpecialChar,isQuite)
{
  var result = false;
  if (str == null)
  {
    result = true;
  }
  else
  {
    var i = 0, j = 0;
	var cc, checker, sc;
	
    for (i=0;i<str.length;i++)
    {
	  cc = str.charCodeAt(i);
      checker = true; //true : means baddly.
      
	  //0~9
      checker = checker && !(cc>=48 && cc<=57);
      
      //a~z
      checker = checker && !(cc>=97 && cc<=122);
      
      //A~Z
      checker = checker && !(cc>=65 && cc<=90);
      
      for(j=0;j<SpecialChar.length;j++){
	     sc = SpecialChar.charCodeAt(j);
	     checker = checker && !(cc==sc);
	  }
      
	  if (checker)
      {
        if (isQuite != true)
        {
			//alert(GL("verr_eng_num_char",{1:defMsg,2:SpecialChar}));
			ShowDLinkWarning(GL("verr_eng_num_char",{1:defMsg,2:SpecialChar}));
        }
        result = true;
        break;
      }
    }
  }
  return result;
}

//check the special char is not allow.
//include char = true; --> fail
//not include = false; --> pass
function CheckSpecialChar(str,defMsg,SpecialChar,isQuite)
{
  var result = false;	//not include
  if (str == null)
  {
    result =true;		//include
  }
  else
  {
    var i = 0, j = 0;
	var cc, checker, sc;
	//var uri = encodeURIComponent(str);

    for (i=0;i<str.length;i++)
    {
	  cc = str.charCodeAt(i);
      checker = false; //not include.
      
      for(j=0;j<SpecialChar.length;j++){
	     sc = SpecialChar.charCodeAt(j);
	     checker = checker || (cc==sc);
	  }
      
	  if (checker)
      {
        if (isQuite != true)
        {
			//alert(GL("verr_special_char",{1:defMsg,2:SpecialChar}));
			ShowDLinkWarning(GL("verr_special_char",{1:defMsg,2:SpecialChar}));
        }
        result = true;
        break;
      }
    }
  }
  return result;
}

function DW(str)
{
  document.write(str);
}
//===================================================
//Submit the form 
//===================================================
//create the submit button
//CLID: Control List ID
function CreateSubmitButton(CLID,isAsync)
{
  DW(CreateSubmitButton_(CLID,isAsync));
}
function CreateSubmitButton_(CLID,isAsync)
{
  
  var fun = "ValidateCtrlAndSubmit";
  fun += ((CheckIsNullNoMsg(CLID))?"(CTRLARY":("("+CLID) );
  fun += ((CheckIsNullNoMsg(isAsync))?"":(","+isAsync) );
  fun += ")";
  //alert(fun+isAsync);
  
  var o='';
  o+='<input type="button" id="smbtn_'+((CLID==null)?"":CLID)+'" value="'+GL("submit")+'" class="m1" onClick="'+fun+'">';
  return o;

}

var SendEPTZPointHttp = null;
function SendEPTZPoint(num,RespFunc)
{
  
  SendEPTZPointHttp = null;
  SendEPTZPointHttp = InitXHttp();
  if(RespFunc==null)
	SendEPTZPointHttp.onreadystatechange = GetEPTZPoint;
  else
	SendEPTZPointHttp.onreadystatechange = RespFunc;
  try
  { 
  
	if( !IsViewer()){
	
		if( num == 1)
		  SendEPTZPointHttp.open("GET", "/vb.htm?paratest=profile1eptzcoordinate", true);
		if( num == 2)
		  SendEPTZPointHttp.open("GET", "/vb.htm?paratest=profile2eptzcoordinate", true);
		if( num == 3)
		  SendEPTZPointHttp.open("GET", "/vb.htm?paratest=profile3eptzcoordinate", true);
	}
    
    SendEPTZPointHttp.setRequestHeader("If-Modified-Since","0");
    SendEPTZPointHttp.send(null);
    WS(GL("sending_"));
  }catch(e){};
  g_httpOK = true;
};

function GetEPTZPoint()
{
  if (SendEPTZPointHttp.readyState==4)
  {
    if (SendEPTZPointHttp.status != 200)
    {
      
      WS(GL("fail_"));
    }
    else
    {
	//start modified--2010.11.17
      var list = SendEPTZPointHttp.responseText.split('=');
	  if(list.length!=2)
		return;
	//end modified--2010.11.17
	
	  if(mpMode == 1)
	  {
	   	g_EPTZ1x1 = parseInt(list[1].substr(0,4)*1);
        g_EPTZ1y1 = parseInt(list[1].substr(4,4)*1);
	  }
	  if(mpMode == 2)
	  {
	    g_EPTZ2x1 = parseInt(list[1].substr(0,4)*1);
        g_EPTZ2y1 = parseInt(list[1].substr(4,4)*1);
	  }
	  if(mpMode == 3)
	  {
        g_EPTZ3x1 = parseInt(list[1].substr(0,4)*1);
        g_EPTZ3y1 = parseInt(list[1].substr(4,4)*1);
	  }
	  
	  //--2010.12.27 added
	  if(g_isEPTZviewer && EptzPositonWorking)
		MoveUvumiWin();
	  //--2010.12.27
	  
      WS(GL("ok_"));
    }
  }
};

function SendHttp(url,isAsync,callBack)
{
  isAsync = new Boolean(isAsync);
  g_SubmitHttp = null;
  g_SubmitHttp = InitXHttp();
  if (callBack != null)
  {
    g_SubmitHttp.onreadystatechange = callBack;
  }
  else
  {
    g_SubmitHttp.onreadystatechange = OnSubmitReadyStateProcess;
  }
  
  try
  {
    g_SubmitHttp.open("GET", url, isAsync);
    g_SubmitHttp.setRequestHeader("If-Modified-Since","0");
    g_SubmitHttp.send(null);
    WS(GL("sending_"));
  }catch(e){};
};

function OnSubmitReadyStateProcess()
{
  if (g_SubmitHttp.readyState==4)
  {
    if (g_SubmitHttp.status != 200)
    { 
		  if ( g_SubmitHttp.status==12152 || g_SubmitHttp.status==0)
		  { 
			g_httpOK = true;
			WS(GL("ok_"));
		  }	
		  else
		  { 
			  alert(GL("err_submit_fail"));
			  g_httpOK = false;
			  WS(GL("fail_"));
		  }
    }
    else
    {
      g_httpOK = true;
      WS(GL("ok_"));
    }
  }
};

var g_SubmitHttpPost = '';
function SendHttpPost(url,isAsync,callBack,content)
{
  isAsync = new Boolean(isAsync);
  g_SubmitHttpPost = null;
  g_SubmitHttpPost = InitXHttp();
  if (callBack != null)
  {
    g_SubmitHttpPost.onreadystatechange = callBack;
  }
  else
  {
    g_SubmitHttpPost.onreadystatechange = OnSubmitPostProcess;
  }
  
  try
  {
    g_SubmitHttpPost.open("POST", url, isAsync);
    g_SubmitHttpPost.setRequestHeader("If-Modified-Since","0");
    g_SubmitHttpPost.send(content);
    WS(GL("sending_"));
  }catch(e){};
};

function OnSubmitPostProcess()
{
  if (g_SubmitHttpPost.readyState==4)
  {
    if (g_SubmitHttpPost.status != 200)
    { 
		  if ( g_SubmitHttpPost.status==12152 || g_SubmitHttpPost.status==0)
		  { 
			g_httpOK = true;
			WS(GL("ok_"));
		  }	
		  else
		  { 
			  alert(GL("err_submit_fail"));
			  g_httpOK = false;
			  WS(GL("fail_"));
		  }
    }
    else
    {
      g_httpOK = true;
      WS(GL("ok_"));
    }
  }
};

var g_SubmitHttpEPTZ;
function SendHttpEPTZ(url,isAsync,callBack)
{
  isAsync = new Boolean(isAsync);
  g_SubmitHttpEPTZ = null;
  g_SubmitHttpEPTZ = InitXHttp();
  if (callBack != null)
  {
    g_SubmitHttpEPTZ.onreadystatechange = callBack;
  }
  else
  {
    g_SubmitHttpEPTZ.onreadystatechange = OnSubmitReadyStateProcessEPTZ;
  }
  
  try
  {
    g_SubmitHttpEPTZ.open("GET", url, isAsync);
    g_SubmitHttpEPTZ.setRequestHeader("If-Modified-Since","0");
    g_SubmitHttpEPTZ.send(null);
    WS(GL("sending_"));
  }catch(e){};
};

function OnSubmitReadyStateProcessEPTZ()
{
  if (g_SubmitHttpEPTZ.readyState==4)
  {
    if (g_SubmitHttpEPTZ.status != 200)
    {  
      alert(g_SubmitHttpEPTZ.status+" "+ GL("err_submit_fail"));
      WS(GL("fail_"));
    }
    else
    {
      WS(GL("ok_"));
    }
  }
};

var g_SubmitHttpPublic;
function SendHttpPublic(url,isAsync,callBack)
{
  isAsync = new Boolean(isAsync);
  g_SubmitHttpPublic = null;
  g_SubmitHttpPublic = InitXHttp();
  if (callBack != null)
  {
	  g_SubmitHttpPublic.onreadystatechange = callBack;
  }
  else
  {
	  g_SubmitHttpPublic.onreadystatechange = OnSubmitReadyStateProcessPublic;
  }
  
  try
  {
	g_SubmitHttpPublic.open("GET", url, isAsync);
	g_SubmitHttpPublic.setRequestHeader("If-Modified-Since","0");
	g_SubmitHttpPublic.send(null);
    WS(GL("sending_"));
  }catch(e){};
};

function OnSubmitReadyStateProcessPublic()
{
  if (g_SubmitHttpPublic.readyState==4)
  {
    if (g_SubmitHttpPublic.status != 200)
    { 
     //  alert(g_SubmitHttpPublic.status+" "+ GL("err_submit_fail")); //2012.09.05  
      WS(GL("fail_"));
	  
    }
    else
    {
      WS(GL("ok_"));
    }
  }
};

var g_SubmitHttpPublic1;
function SendHttpPublic1(url,isAsync,callBack)
{
  isAsync = new Boolean(isAsync);
  g_SubmitHttpPublic1 = null;
  g_SubmitHttpPublic1 = InitXHttp();
  if (callBack != null)
  {
	  g_SubmitHttpPublic1.onreadystatechange = callBack;
  }
  else
  {
	  g_SubmitHttpPublic1.onreadystatechange = OnSubmitReadyStateProcessPublic1;
  }
  
  try
  {
	g_SubmitHttpPublic1.open("GET", url, isAsync);
	g_SubmitHttpPublic1.setRequestHeader("If-Modified-Since","0");
	g_SubmitHttpPublic1.send(null);
    WS(GL("sending_"));
  }catch(e){};
};

function OnSubmitReadyStateProcessPublic1()
{
  if (g_SubmitHttpPublic1.readyState==4)
  {
    if (g_SubmitHttpPublic1.status != 200)
    {
      alert(g_SubmitHttpPublic1.status+" "+ GL("err_submit_fail"));
      WS(GL("fail_"));
    }
    else
    {
      WS(GL("ok_"));
    }
  }
};

function ShowObjVar(obj)
{
  var ssss;
  for (i in obj) ssss += i+"="+obj[i]+", ";
  document.write("<h1>"+ssss+"</h1>");
}


function IsChecked(name)
{
  var obj = GE(name);
  var result = false;
  if (obj != null)
  {
    result = obj.checked;
  }
  return result;
}
function SetChecked(name,isChk)
{
  var obj = GE(name);
  if (obj != null)
  {
    obj.checked = isChk;
  }
}
function Bool2Int(data)
{
  return (data) ? 1 : 0;
}
//===================================================
// Get the value form the object.
//===================================================
//return obj.value
function GetValue(name)
{
  var result = '';
  var obj = GE(name);
  if (obj != null)
  {
    if (obj.type.indexOf("select") >= 0)
    {
      result = obj.options[obj.selectedIndex].value;
    }
    else
    {
      result = obj.value;
    }
  }
  else
  {
    alert(GL("verr_miss_obj",{1:name}));
  }
  return result;
}

//===================================================
// set the value of the object.
//===================================================
function SetValue(name,value)
{
  var obj = GE(name);
  if (obj != null)
  {
    if (obj.type.indexOf("select") >= 0)
    {
      for (var i=0;i<obj.options.length;i++)
      {
        if (obj.options[i].value==value)
        {
          obj.selectedIndex = i;
          break;
        }
      }
    }
    else
    {
      obj.value = value;
    }
  }
  else
  {
    alert(GL("verr_set_value",{1:name}));
  }
}

function GetDeviceTitleStr(extName)
{
  //var devName = g_deviceName;
  var devName = g_titleName;

  if (extName == null)
  {
    return GetTitleTag(devName);
  }
  else
  {
    return GetTitleTag(extName);
  }
}
function GetTitleTag(titleStr)
{
  return ("<title>"+titleStr+"</title>");
}

// if exist otherName then the document title will be "otherName" and the "extTitle" will be nonsense 
//if the "otherName" = null, but the "extTitle" exist, then the document title will be "<%devicename%> + extTitle"
// If both of them are equals null, then the document title will be "<%devicename%>" , and  the "<%devicename%>" default value is "LAN Camera"
function WriteHtmlHead(extTitle,otherName,onLoadFunc,onUnLoadFunc,onResizeFunc,refreshTime)
{
  var o='';
  o+=GetHtmlHeaderNoBannerStr(extTitle,otherName,onLoadFunc,onUnLoadFunc,onResizeFunc,refreshTime);
  // 20090113 Netpool Add for D-Link Style
  o+='<table border="0" cellspacing="1" cellpadding="2" align="center" bgcolor="#FFFFFF" width="800" >';
  o+='<tr><td height="25" ><img src="D-Link.gif" border=0></td></tr>';
  o+='<tr><td id="mainMenuBar" >'+GetMenuStr()+'</td></tr>';
  o+='<tr><td id="DLinkToolBar" >'+GetDLinkToolStr()+'</td></tr>';
  //o+='<tr><td colSpan=3>';
  //o+='<img height=61 src="'+g_brandName+'.jpg" width=770 useMap=#Map border=0></td></tr>';
  //o+=GetLogoHtml();
  //o+=GetViewCHHtml();
  //fix ActiveX can't install. add an <OBJECT> on the index page.
  //20061220 To avoid many trouble, so force user install activex.
  //if (g_useActiveX == 1 || IsMpeg4() || IsVS() )
  //o+='<OBJECT CLASSID="CLSID:'+AxUuid+'" CODEBASE="/VDControl.CAB#version='+AxVer+'" width=0 height=0 ></OBJECT>';
  //o+='<img id="arrowImg" style="position:absolute;left:-600px;z-index:5;cursor: pointer;" src="arrow.gif" onClick="ClickArrow(event)" onMouseMove="MoveOnArrow(event)" onMouseOut="WS()" border=0 />';
  // 20081204 chirun modify for 7313 355 d-link 
  // modify o+='<img height=61 src="nobrand.jpg" width=770 useMap=#Map border=0></td></tr>';
  //o+='<div id ="imgbrand" ><img height=61 src="nobrand.jpg" width=770 useMap=#Map border=0></div>';
  // 20081204 chirun modify for 7313 355 d-link 
  // del o+='<div id ="imgbrand" style="background-image: url(newbrand.gif); width:770; height:61; "  useMap=#Map border=0> </div></td></tr>';
  //o+='<tr><td width=12.5 valign="top" background="ie_02.jpg" height="492">&nbsp;</td>';
  //o+='<div align=center>';
  //o+='<td width=745 align=center>';
  //o+='<td valign="top" align=center ><table ><tr>';
  o+='<tr><td><div id="WebContent" >';
  DW(o);
};

function GetHtmlHeaderNoBannerStr(extTitle,otherName,onLoadFunc,onUnLoadFunc,onResizeFunc,refreshTime)
{
  var o='';
  o+=GetHtmlHeaderNoBodyStr(extTitle,otherName,refreshTime);
  // 20090112 Netpool Modified for D-Link Style
  o+='<body topmargin="1" leftmargin="0" rightmargin="0" bgcolor="#757575" ';
  if(onLoadFunc != null)
  {
    o+='onLoad="'+onLoadFunc+'()" ';
  }
  if(onUnLoadFunc != null)
  {
    o+='onUnLoad="'+onUnLoadFunc+'()" ';
  }
  if(onResizeFunc != null)
  {
    o+='onResize="'+onResizeFunc+'()" ';
  }
  // 20090115 Netpool Modified for D-Link Style
  o+='>';
  return o;
};

function GetHtmlHeaderNoBodyStr(extTitle,otherName,refreshTime)
{
  var o='';
  //o+='<html ><head>';
  if (otherName != null)
  {
    o+=GetTitleTag(otherName);
  }
  else if (extTitle != null)
  {
    o+=GetDeviceTitleStr(extTitle);
  }
  else
  {
    o+=GetDeviceTitleStr();
  }
  if (refreshTime != null)
  {
    o+='<meta HTTP-EQUIV="Refresh" CONTENT="'+refreshTime+'">';
  }
  //o+='<meta http-equiv=Content-Type content="text/html; charset=UTF-8">';
  o+='<meta HTTP-EQUIV="pragma" CONTENT="NO-CACHE">';
  o+='<META HTTP-EQUIV="Expires" CONTENT="-1">';
  o+='<meta HTTP-EQUIV="Cache-Control" CONTENT="no-store, no-cache, must-revalidate">';
  o+='<meta HTTP-EQUIV="Cache-Control" CONTENT="post-check=1, pre-check=2">';
  //o+='<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />';
  //o+='<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />';
  //o+='<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />';
  //20070518 it seems css not really need for different lang.
  //o+='<link href="lc_'+g_langName+'.css" rel="stylesheet" type="text/css">';
  o+='<link href="lc_en_us.css?'+webVer+'" rel="stylesheet" type="text/css">';
  
  if(g_isSupportEPTZ == 1)
    o+='<link rel="stylesheet" type="text/css" media="screen" href="/uvumi/uvumi-crop.css?'+webVer+'" />';	
  
  o+='</head>';
  return o;
}

//initial header
function WriteHtmlHeader(TitleName, refreshTime){
	var o = '';
	if (TitleName != null) 
		o += '<title>' + TitleName + '</title>';
	else 
		o += '<title>' + g_titleName + '</title>';
	
	if (refreshTime != null) 
		o += '<meta HTTP-EQUIV="Refresh" CONTENT="' + refreshTime + '">';
	o += '<meta HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">';
	//o+='<link href="common.css" rel="stylesheet" type="text/css">';
	DW(o);
}

var  g_isViewer = false;
function IsViewer()
{
	  /*if(g_supportnvrbased){ 2015.07.06 temp remark
		var url="/cgi-bin/userprivilege.cgi";		
	  
		SendHttpPublic("/cgi-bin/snmp.cgi?"+url ,false, RespIsViewer);
		
		return g_isViewer;
	  }	
	  else*/
		return (g_isAuthorityChange && g_socketAuthority > 1);
}

function RespIsViewer()
{
  if (g_SubmitHttpPublic.readyState==4)
  {
    if (g_SubmitHttpPublic.status != 200)
    {
        g_isViewer = false;
    }
    else
    {		
		var txt= g_SubmitHttpPublic.responseText.split("\r\n");
		var tmp="";
			tmp = trim(txt[1]);	
			
		 if( parseInt(tmp,10) == 3)
			g_isViewer = true;
		 else
			g_isViewer = false;
		
    }
  }
}

//get link string, it will depends on authority.
//20060801 fix link to use XMLHttpRequest to fetch web page.
function GetLinkStr(link,key,type)
{
  var o='';
  if (IsViewer())
  {
    o+=GL(key);
  }
  else
  {
    // 20090206 Netpool Modified for D-Link Style
    o+=GetDLinkContentLink(key,link,type);
  }
  return o;
}

function MainMenuDown(obj,key)
{
  obj.className = "menuLinkDOWN";
  //WS();
}

function MainMenuIn(obj,key,isMM)
{
  obj.className = "menuLinkON";
  //var k = obj.innerHTML.toLowerCase().replace(new RegExp(" ","g"),"_").replace(new RegExp("/","g"),"_");
  if (isMM != false)
    WS( GL(key+"_comment") );
}

function MainMenuOut(obj,key)
{
  obj.className = "menuLink";
  //WS();
}

function GetFirstOKLink(menuAry)
{
  for (var i=2;i<menuAry.length;i+=3)
  {
    if (parseInt(menuAry[i]) == 1)
      return menuAry[i-1];
  }
  return null;
}

//calculate bottom menu
var totalMenuItem = 0;
// 20090116 Netpool Modified for D-Link Style
function GetMenuStr()
{
  var o='';
  o+='<table id="DLinkMainTable" border="0" cellSpacing="0" cellPadding="2" >';
  o+='<tr class="topnav_container" >';
  o+='<td class="td1" ><img src="dcs3110.gif" width="125" height="25" ></td>';
  o+='<td class="td1" id="MI_0">'+GetLinkStr("index.htm","home","home")+'</td>';
//  o+='<td width="115" height="24">';
//  if (IsViewer())
//    o+='&nbsp;';
//  else
//  {
//    o+='<a href="version.htm" target=_blank>';
//    o+='<img border="0" src="version.gif" width="10" height="10"></a>';
//  }
  o+='<td class="td1" id="MI_1">'+GetLinkStr("image.htm","image","image")+'</td>';
  o+='<td class="td1" id="MI_2">'+GetLinkStr("network.htm","network","network")+'</td>';
  o+='<td class="td1" id="MI_3">'+GetLinkStr("system.htm","system","system")+'</td>';
  totalMenuItem = 4;
  var tmpLink = GetFirstOKLink(MENU_ITEM_APP_SET);
  if (tmpLink == null) tmpLink = GetFirstOKLink(MENU_ITEM_APP_REC);
  if (tmpLink == null) tmpLink = GetFirstOKLink(MENU_ITEM_APP_ALARM);
  if (tmpLink != null)
  {
    o+='<td class="td1" id="MI_4">'+GetLinkStr("application.htm","application","application")+'</td>';
    totalMenuItem++;
  }
  //add no card check.
  if (g_defaultStorage != NO_STORAGE && g_defaultStorage<2)
  {
    o+='<td class="td1" id="MI_5">';
    if(g_defaultStorage == "1")
    {
      //if(g_SDInsert == "1")
      if(false)
        o+=GetLinkStr(g_cardGetLink,"sd_card","card");
      else
        o+=GL("sd_card");
    }
    else
    {
      if(g_CFInsert == "1")
        o+=GetLinkStr(g_cardGetLink,"cf_card","card");
      else
        o+=GL("cf_card");
    }
    o+='</td>';
    totalMenuItem++;
  }
//  if (g_isSupportptzpage && !g_isShowPtzCtrl)
//  {
//    o+='<td class="td1" id="MI_6">'+GetLinkStr("ptz.htm","pan_tilt","pop")+'</td>';
//    totalMenuItem++;
//  }
  o+='<td class="td1" id="MI_7">'+GetLinkStr( ("help.htm"),"help","help")+'</td>';
  totalMenuItem++;
  o+='</tr></table>';
  return o;
};

function PopupPTZ(URL)
{
  //return PopupPage(URL,"PTZ",80,0,575,125);
  return PopupPage(URL,"PTZ",80,0,455,125);
}
function PopupPage(URL,id,x,y,w,h)
{
  var windowProps = "location=no,scrollbars=no,menubars=no,toolbars=no,resizable=no,left="+x+",top="+y+",width="+w+",height="+h;
  return WindowOpen(URL,id,windowProps);
}
function WindowOpen(URL,id,props)
{
  var popup = window.open(URL,id,props);
  try
  {
    popup.focus();
  }catch(e){};
}

function GetMapLinkStr()
{
  var o='';
  o+='<MAP name=Map>';
  //if(g_brandUrl != null && !CheckIsNullNoMsg(g_brandUrl) && g_brandUrl.indexOf("%") < 0 && g_brandUrl != "(null)")
  //{
	//  o+="<AREA shape=RECT coords='27, 10, 205, 50' href='"+g_brandUrl+"' target=_blank name='brand'>";
  //}
	o+='<AREA shape=RECT coords="556, 42, 636, 58" href="index.htm" name="index">';
  if (!IsViewer())
  {
    o+='<AREA shape=RECT coords="635, 42, 691, 58" href="help.htm" target=_blank name="help">';
  }
  //o+='<AREA shape=RECT coords="692, 42, 757, 58" href="http://'+location.host+'logout.htm" name="logout">';
  o+='<AREA shape=RECT coords="692, 42, 757, 58" href="logout.htm" name="logout">';
  o+='</MAP>';
  return o;
}

function WriteBottom(lastctx)
{
  var o='';
  //o+='</td>';
  //o+='</div>';
  //o+='</tr></table></td>';
  o+='</div></td></tr></table>';
  //o+='<td width=14 valign="top" background="ie_04.jpg" height="492">&nbsp;</td></tr>';
  //o+='<tr><td colSpan=3 id="mainMenuBar">';
  //o+=GetMenuStr();
  //o+='</td></tr>'
  // 20090119 Netpool Modified for D-Link Style
  //o+='<tr><td background="address.jpg">';
  //o+='<p align="right" class="m2"><span id="devTitleLayer">'+g_titleName+'</span>&nbsp&nbsp&nbsp&nbsp;</p>';
  //o+='</td></tr></table>';
  // 20090119 Netpool Modified for D-Link Style
  o+='<iframe name="retframe" frameborder="0" style="display:none;"></iframe>';
  o+='<div class="div1" align="center">Copyright &copy; '+CopyrightYear+' D-Link Corporation.</div><br>';
  o+=GetMapLinkStr();
  if (lastctx != null)
  {
    o+=lastctx;
  }
  o+='</body>';
  DW(o);
  //20071109 Luther add , fix text to center.
  //ResizeMenuItems();
}

function ResizeMenuItems()
{
  //resize
  var tmpW = 660 / totalMenuItem;
  for(i=0;i<9;i++)
  {
    try
    {
      var obj = GE("MI_"+i);
      if (obj != null)
      {
        obj.width = tmpW;
      }
    }
    catch(e){};
  }
}

function ReloadSubMenu()
{
  MENU_ITEM_IMAGE = new Array(
    'image','img.htm',1,
    //'image_h264','img_h264.htm',g_is264,
    'fine_tune','imgtune.htm',1,

    'privacy_mask','imgmask.htm',g_s_maskarea,
	//20081224 chirun add for 7313
    'image_daynight','imgdaynight.htm',g_s_daynight,
	"checkout","checkout.htm",1
  );
  
  //Note: do not mix the order, the img.htm will direct acces
  //MENU_ITEM_SYSTEM[23]
  MENU_ITEM_SYSTEM = new Array(
    'date_and_time','sdt.htm',1,
    'timestamp','sts.htm',(g_supportTStamp>0)?1:0,
    'users','suser.htm',1,
    'digital_io','sdigital.htm',1,
    'audio_mechanism','saudio.htm',(g_isSupportAudio)?1:0,
    //'rs232_set','srs.htm?:232',(g_isSupportRS232)?1:0,
    'rs485_set','srs.htm',(g_isSupportRS485)?1:0,
    //'sequence','sseq.htm',(g_isSupportSeq)?1:0,
    'update','c_update.htm',(g_isShowUpdate)?1:0,
    'event','aevt.htm',1,
	"checkout","checkout.htm",1
  );

  
  MENU_ITEM_NETWORK = new Array(
    "network","net.htm",1,
    "nftp","nftp.htm",g_serviceFtpClient,
    "nsmtp","nsmtp.htm",g_serviceSmtpClient,
    "sntp","nsntp.htm",g_serviceSNTPClient,
	
	// 20081128 chirun add for test  start
	"virtual_server","nvirtualserver.htm",g_serviceVirtualSClient,
	// 20081128 chirun add for test  end
	
    "ddns","nddns.htm",g_serviceDDNSClient,
    "wireless","nwireless.htm",(g_isSupWireless)?1:0,
    "pppoe","npppoe.htm",g_servicePPPoE,
    //"ftp_host","nftphost.htm",g_AdvMode,
    "upnp","c_nupnp.htm",(g_isShowUPnP)?1:0,
    //"mcenter","mcenter.htm",g_AdvMode,
    //"dhcp_server","ndhcpsvr.htm",g_AdvMode,
    //"ip_filter","nipfilter.htm",((!g_X)&&g_isSupportIPFilter)?1:0,
    "ip_filter","nipfilter.htm",(g_isSupportIPFilter)?1:0,
    "bwc_traffic","c_bwcntl.htm",(g_isShowBWCtrl)?1:0,
	"checkout","checkout.htm",1
  );

  
  MENU_ITEM_APP_SET = new Array(
  
    // 20081203 chirun del for 7313 355 d-link
    //del "video_file","setvid.htm",1,
	
	"ftp","setftp.htm",g_serviceFtpClient,
	// 20081128 chirun add for language  start
	"langx","c_lang.htm",(g_langNameList.length > 1)?1:0,
	// 20081128 chirun add for language  end
	
    
    "app_sd_card","setcard.htm",(parseInt(g_defaultStorage)==1)?1:0,
    //"app_cf_card","setcard.htm",(parseInt(g_defaultStorage)==0)?1:0,
    "smtp","setsmtp.htm",g_serviceSmtpClient,
	"checkout","checkout.htm",1
    //"langx","c_lang.htm",((!g_X)&&g_langNameList.length > 1)?1:0
    //"langx","c_lang.htm",(g_langNameList.length > 1)?1:0
  );

  MENU_ITEM_APP_REC = new Array(
    "enable_rec","renable.htm",((!ISNOSTORE)||(g_serviceFtpClient==1))?1:0,
    "schedule","rsch.htm",((!ISNOSTORE)||(g_serviceFtpClient==1))?1:0,
	"checkout","checkout.htm",1
  );

  MENU_ITEM_APP_ALARM = new Array(
    "enable_alarm","aenable.htm",1,
    "motion_detect","motion.htm",(g_isSupMotion)?1:0,
	"checkout","checkout.htm",1
  );
  
  
  
  MENU_ITEM_STATUS = new Array(
    "status_menu_decive","status_info.htm",1,
	"status_menu_log","status_log.htm",1,
	"checkout","checkout.htm",1
  );
}
function ReloadMainMenu()
{
  GE("mainMenuBar").innerHTML = GetMenuStr();
  //20071109 Luther add , fix text to center.
  //ResizeMenuItems();
}

function StopActiveX()
{
  var obj = GE(AxID);
  if (obj != null)
  {
    try
    {
      obj.ForceStop();
    }
    catch (e)
    {
    }
  }
  if (IsVS())
  {
    var i;

    for (i=1;i<=g_maxCH;i++)
    {
      obj = GE(AxID+i);
      if (obj != null)
      {
        try
        {
          obj.ForceStop();
        }
        catch (e)
        {
        }
      }
    }
  }
  
}


function CheckHex(n,isQuite,name)
{
  var i,strTemp;
  strTemp="0123456789ABCDEF";
  if ( n.length== 0)
  {
    if (isQuite != true) alert(GL("verr_vacuous",{1:(name==null || name=="" ? "hex" : name)}));
    return false;
  }
  n = n.toUpperCase();
  for (i=0;i<n.length;i++)
  {
    if (strTemp.indexOf(n.charAt(i)) == -1)
    {
      if (isQuite != true) alert(GL("verr_not_hex"));
      return false;
    }
  }
  return true;
}
function InitXHttp()
{
  var xhttp = null;
  if (IsMozilla())
  { 
    xhttp = new XMLHttpRequest(); 
    if(xhttp.overrideMimeType)
    { 
      xhttp.overrideMimeType('text/xml'); 
    } 
  }
  else if (browser_IE) 
  {
    try
    {
      xhttp = new ActiveXObject("Msxml2.XMLHTTP");
      //xhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    catch (e)
    { 
      try
      { 
        xhttp = new ActiveXObject("Microsoft.XMLHTTP"); 
      }
      catch (e){};
    }
  } 
  return xhttp;
}
function GetWebPageName(url)
{
  var ss = url.split("/");
  return ss[ss.length-1];
}
function CreateSystemMenuItem(key,menuUrl,isON)
{
  if (isON == null) isON = 1;
  if (isON != 1) return '';
  //20081225 chirun del for 7313
  //del if ((key == "ftp" || key == "smtp") && IsMpeg4()) return '';

  var o='';
  o+='<tr>';
  //srs.htm
  var isTitle = false;
  if ( menuUrl.indexOf("srs.htm")==0 )
  {
    isTitle = (menuUrl == CONTENT_PAGE);
  }
  else if ( CONTENT_PAGE.indexOf(menuUrl) == 0 )
  {
    isTitle = true;
  }
  if (isTitle)
  {
    o+='<td width="155" height="22" class="sel" style="border-bottom:1px solid #FFFFFF;" >'+GL(key)+'</td>';
  }
  else
  {
    o+=GetMenuItemLink(key,menuUrl);
  }
  o+='</tr>';
  return o;
}
function GetMenuItemLink(key,url,type)
{
  var o="";
  // 20090204 Netpool Modified for D-Link
  o+='<td width="128" height="22" bgcolor="#434343" class="menu" style="border-bottom:1px solid #FFFFFF;" onMouseOver="DLinkMainMenuIn(this,\''+key+'\')" onMouseOut="DLinkMainMenuOut(this,\''+key+'\')" onMouseDown="DLinkMainMenuDown(this,\''+key+'\')" onClick="';
  if (type == "pop")
  {
    o+= 'PopupPTZ(\''+url+'\');';
  }
  else if (type == "card")
  {
    o+= 'WindowOpen(\''+url+'\',\'CARD\',\'location=yes,directorybuttons=no,scrollbars=yes,resizable=yes,menubar=yes,toolbar=yes\');';
  }
  else
  {
    o+= 'ChangeContent(\''+url+'\');';
  }
  o+='" >'+GL(key)+'</td>';
  return o;
}
function GetContentLink(key,url,type)
{
  var o="";
  // 20090116 Netpool Modified for D-Link Style
  o+='<span class="menuLink" onMouseOver="MainMenuIn(this,\''+key+'\')" onMouseOut="MainMenuOut(this,\''+key+'\')" onMouseDown="MainMenuDown(this,\''+key+'\')" onClick="';
  if (type == "pop")
  {
    o+= 'PopupPTZ(\''+url+'\');';
  }
  else if (type == "card")
  {
    o+= 'WindowOpen(\''+url+'\',\'CARD\',\'location=yes,directorybuttons=no,scrollbars=yes,resizable=yes,menubar=yes,toolbar=yes\');';
  }
  // 20090116 Netpool Modified for D-Link Style
  else if(type == "home" || type == "help" || type =="image")
  {
    o+='DLinkGoHref(\''+url+'\')';
  }
  else
  {
    o+= 'ChangeContent(\''+url+'\');';
  }
  o+='" >'+GL(key)+'</span>';
  return o;
}

function CreateSystemMenu(extMenu)
{
  DW(CommonGetMenuStr(MENU_ITEM_SYSTEM, extMenu));
}

function CreateImageMenu(extMenu)
{
  DW(CommonGetMenuStr(MENU_ITEM_IMAGE, extMenu));
}

function GetTagAX1AndFixSize(id)
{
  var o='';
  //20070613 Luther fix 1280*960
//  if (g_viewXSize>700 && g_viewYSize==240)
//  {
//    o+=TagAX1(id,g_viewXSize,480);
//  }
//  else if (g_viewXSize>700 && g_viewYSize==288)
//  {
//    o+=TagAX1(id,g_viewXSize,576);
//  }
//  else if (g_viewXSize==640 && g_viewYSize==240)
//  {
//    o+=TagAX1(id,640,480);
//  }
  //20071024 Luther add, use common way
  if (g_viewXSize>=640 && g_viewYSize<300)
  {
    o+=TagAX1(id,g_viewXSize,g_viewYSize*2);
  }
  else
  {
    var w = g_viewXSize;
    var h = g_viewYSize;
    if (w > 720)
    {
      h = (720 * h) / w;
      w = 720;
    }
    o+=TagAX1(id,w,h);
  }
  return o;
}
function GetHalfViewSizeX()
{

  //20070613 Luther fix 1280 * 960
//  if (g_viewXSize > 400)
//    //return g_viewXSize / 2;
//    return 360;
//  else
//    return g_viewXSize;
  //20070920 for fix radio
  var tmp = g_viewXSize;
  while (true)
  {
    if (tmp > 360)
    {
      tmp /= 2;
    }
    else
    {
      break;
    }
  }
  return tmp;
}
function GetHalfViewSizeY()
{
  //20070613 Luther fix 1280 * 960
//  if (g_viewYSize > 300)
//    //return g_viewYSize / 2;
//    return 240;
//  else
//    return g_viewYSize;
  //20070920 for fix radio
  var tmp = g_viewYSize;
  while (true)
  {
    if (tmp > 288)
    {
      tmp /= 2;
    }
    else
    {
      break;
    }
  }
  return tmp;
}

// return the fix length string, if the length is too short , it will add the insChar.
//type:,0 insert insChar to left, the string will align right,
//type: 1 align left
//type:2 middle
function GetFixLenStr(str,len,insChar,type)
{
  var o="";
  str = ""+str; //make sure it is string
  var count = len - str.length;
  var lc=rc=0;
  if (type==1)
  {
    rc = count;
  }
  else if (type==2)
  {
    lc = count / 2;
    rc = count - lc;
  }
  else
  {
    lc = count;
  }
  if (lc > 0)
  {
    var i=0;
    for (i=0;i<lc;i++)
    {
      o+=insChar;
    }
  }
  o+=str;
  if (rc > 0)
  {
    var i=0;
    for (i=0;i<rc;i++)
    {
      o+=insChar;
    }
  }
  return o;
}

function DisableObject(name,isDisable)
{
  var obj = GE(name);
  if (obj != null)
  {
    obj.disabled = isDisable;
  }
  try
  {
    SetCIA(name, !isDisable);
    //CTRLARY[name].active = !isDisable;
  }catch (e){};

  var objs = GES(name);
  if (objs != null)
  {
    for (var i=0;i<objs.length;i++)
    {
      objs[i].disabled = isDisable;
    }
  }
}
function DisableObjs(list,isDisable)
{
  for (var i=0;i<list.length;i++)
  {
    DisableObject(list[i],isDisable);
  }
}
//--start 2011.5.20 added
function DisableRadio(name, value, isDisable)
{
	var radioObj = GES(name);
	if (radioObj != null)
	{
		for (i=0;i<radioObj.length;i++)
		{
			if (radioObj[i].value == value)
			{
				radioObj[i].disabled = isDisable;
				//if(isDisable)
				//	radioObj[i].checked = false;
				break;
			}
		}
	}
}
//--end 2011.5.20
//--start 2011.5.20 added
function GetRadioDisableStatus(name, value)
{
	var radioObj = GES(name);
	if (radioObj != null)
	{
		for (i=0;i<radioObj.length;i++)
		{
			if (radioObj[i].value == value)
				return radioObj[i].disabled;
		}
	}
	return false;
}
//--end 2011.5.20

//get init submit string
//return the  submit POSTDATA init data.
function GetIS()
{
  var o='GET /'+THIS_PAGE+'?';
  o+="language=ie";
  return o;
}

//set the object visible
function SetVisible(name,isVisible)
{
  var obj = GE(name);
  if (obj != null)
  {
    obj.style.visibility = (isVisible) ? keyword_Show : keyword_Hide;
  }
}

//change  size  to Bytes,MB,GB ex: 1035 = 1.02 KB
//fixDotSize decimal point postion , default is 2
function GetCapacityString(size,fixDotSize)
{
  var BASEUNIT = 1024;
  var capStr = '';
  if (fixDotSize == null || fixDotSize < 0)
  {
    fixDotSize = 2;
  }
  var total = parseFloat(size);
  if (total < BASEUNIT)
  {
    capStr = total +' Bytes';
  }
  else
  {
    total /= BASEUNIT;
    total = total.toFixed(fixDotSize);
    if (total == parseFloat(total))
    {
      total = parseFloat(total);
    }
    if (total < BASEUNIT)
    {
      capStr = total+' KB';
    }
    else
    {
      total /= BASEUNIT;
      total = total.toFixed(fixDotSize);
      if (total == parseFloat(total))
      {
        total = parseFloat(total);
      }
      if (total < BASEUNIT)
      {
        capStr = total+' MB';
      }
      else
      {
        total /= BASEUNIT;
        total = total.toFixed(fixDotSize);
        if (total == parseFloat(total))
        {
          total = parseFloat(total);
        }
        capStr = total+' GB';
      }
    }
  }
  return capStr;
}

//input data object and format id isDayLight ,return time string.
//timeFormat : 
// 0-> YY-MM-DD
// 1-> MM-DD-YY
// 2-> DD-MM-YY
function GiveMeDateTimeString(dateObj,timeFormat,isDayLight)
{
  return ( (GiveMeDateString(dateObj,timeFormat,isDayLight)) + " " + (GiveMeTimeString(dateObj)));
}
function GiveMeDateString(dateObj,timeFormat,isDayLight)
{
  var y,M,d;
  y=FixNum(dateObj.getYear(),2);
  M=FixNum(dateObj.getMonth()+1,2);
  d=FixNum(dateObj.getDate(),2);

  var o = "";
  if (isDayLight == 1)
    o += "(+) ";

  if (timeFormat==1)
  {
    o += M +"/"+ d +"/"+ y ;
  }
  else if (timeFormat == 2)
  {
    o += d +"/"+ M +"/"+ y ;
  }
  else
  {
    o += y +"/"+ M +"/"+ d ;
  }
  return o;
}

function GiveMeTimeString(dateObj)
{
  var h,m,s;
  h=FixNum(dateObj.getHours(),2);
  m=FixNum(dateObj.getMinutes(),2);
  s=FixNum(dateObj.getSeconds(),2);
  return (h +":"+ m +":"+ s);
}

function FixNum(str,len)
{
  return FixLen(str,len,"0");
}
function FixLen(str,len,c)
{
  var ins="";
  var i;
  for (i=0;i<len-str.toString().length;i++)
  {
    ins+=c;
  }
  return ins+str; 
}

function CommonGetMenuStr(items,extMenu)
{
  var o='';
  // 20090202 Netpool Modified for D-Link Style
  o+='<table class="left_table" align="center" border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >';
  var i;
  for (i=0;i<items.length;i+=3)
  {
    o+=CreateSystemMenuItem(items[i],items[i+1],items[i+2]);
  }
  if (extMenu != null)
  {
    for (i=0;i<extMenu.length/2;i++)
    {
      o+=CreateSystemMenuItem(extMenu[i*2],extMenu[(i*2)+1]);
    }
  }
  o+='</table>';
  return o;
}

function GetMenuNetworkStr(extMenu)
{
  return CommonGetMenuStr(MENU_ITEM_NETWORK, extMenu );
}


function GetMenuAppStr()
{
  //APP has three type: setting, record, alarm
  var o='';
  // 20090206 Netpool Modified for D-Link Style
  o+='<table class="left_table" align="center" border="0" cellpadding="2" cellspacing="0" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >';
  //o+='<table border="0" align="right" valign="top" >';
  o+=GetMenuAppSubStr(MENU_ITEM_APP_SET,GL("setting"));
  o+=GetMenuAppSubStr(MENU_ITEM_APP_REC,GL("record"));
  o+=GetMenuAppSubStr(MENU_ITEM_APP_ALARM,GL("alarm"));
  o+='</table>';
  return o;
}
function GetMenuAppSubStr(ITEMS,subName)
{
  if (GetFirstOKLink(ITEMS) == null) return "";
  var o='';
  // 20090206 Netpool Del for D-Link Style
  //o+='<tr class="mm1"><td height="20" colspan="2" >'+subName+'</td></tr>';
  var i;
  for (i=0;i<ITEMS.length;i+=3)
  {
    o+=CreateSystemMenuItem(ITEMS[i],ITEMS[i+1],ITEMS[i+2]);
  }
  return o;
}

function ChangeImageLeftVideo(useAX)
{
  GE("imgAX").innerHTML = GetImageLeftVideo(useAX);
}
function GetImageLeftVideo(useAX)
{
  var o="";
  if (IsMpeg4() || useAX == 1 || useAX == true)
  {
    if (IsVS())
    {
      o = TagAX1(1,GetHalfViewSizeX(),GetHalfViewSizeY());
    }
    else
    {
      o = TagAX1(null,GetHalfViewSizeX(),GetHalfViewSizeY());
    }
  }
  else
  {
    //o= "<img id='sampleimg' name='sampleimg' src='/dms' width=352 height=240 border=2>";
    o+='<table border=3 bordercolor="#99CCFF"><tr><td>';
//alert(imgFetcher.GetDmsImgStr());    
    o+= imgFetcher.GetDmsImgStr(GetHalfViewSizeX(),GetHalfViewSizeY());
    o+='</td></tr></table>';
  }
  return o;
}
//vType is user define variable 0 ,store the  mjpeg mode , display control is  ActiveX or JavaApplet
//isNoShowWaitImg , is in changing don't show the waitting img? 
function WriteImageLeftSide(vType,isNoShowWaitImg)
{
  CreateImageMenu();
//  DW('</div><center><div id="imgAX">');
//  if (isNoShowWaitImg)
//    DW(GetImageLeftVideo(vType));
//  else
//    DW("<img id='sampleimg' name='sampleimg' src='/Loading.gif' width=352 height=240 border=2>");
}

//get Select Object ,be select text not  index
function GetSelectText(name)
{
  var oo="";
  var obj = GE(name);
  if (obj != null)
  {
    oo = obj.options[obj.selectedIndex].text;
  }
  return oo;
}


function CheckBadFqdnLen(str,msg)
{
  var result = false;
  if (str.length > v_maxFqdnLen)
  {
    alert(msg);
    result = true;
  }
  return result;
}

//===========================================
// I18N, 
//===========================================
// GL : GetLanguage
// name: is the key of the i18n string, 
function GL(name, va)
{
  name = LangKeyPrefix + name;
  var v = (typeof(LAry[name]) == "undefined") ? GetDefaultStr(name) : LAry[name];
//alert(name);
  if (va) 
  {
    for (n in va)
      v = this.ReplaceVar(v, n, va[n]);
  }
  return v;
}

//string replace
// the {$xxx} will be treat a variable, and replace it.
// h: the origional string, r:replace key(no  $ sign.),v: replace value.
function ReplaceVar(h, r, v) 
{
//debug
//alert("h="+h+"r="+r+"v="+v);
//alert(h.replace(new RegExp('{\\\$' + r + '}', 'g'), v));
  return h.replace(new RegExp('{\\\$' + r + '}', 'g'), v);
}


function GetDefaultStr(v)
{
  v = v.substring(LangKeyPrefix.length,v.length);
  return v.replace(new RegExp("_","g")," ");
}

function AddLangs(ar) 
{
  for (var key in ar)
  {
    if (typeof(ar[key]) == 'function')
      continue;
//debug
//alert((key.indexOf(LangKeyPrefix) == -1 ? LangKeyPrefix : '') + key);
//alert(ar[key]);
    LAry[(key.indexOf(LangKeyPrefix) == -1 ? LangKeyPrefix : '') + key] = ar[key];
  }
}

//replace content key word to I18N .
function I18NHtml(src)
{
  var len = LangKeyPrefix.length;
  for (var key in LAry)
  {
    //alert(key.substring(len,key.lenght) +" : "+LAry[key]);
    src = ReplaceVar(src,key.substring(len,key.length),LAry[key]);
  }
  //alert(src);
  return src;
}
//===========================================
// about UI setting
//===========================================
//AddLightBtn : add a light button
//GetLight : get the light status. 0:off 1:on
//SwitchLight : switch the light status, on -> off , or off -> on
//SetLightPos : set the light position.

//add a graphic buttion, can display on-off,
//it will put the image in <div> tag.
//id : the light id
//onChangeFun is a function name, ex: turnOn(), if you want to add args, 
//  use \"\",  trunOn(\"1000\")
function AddLightBtn(id,left,top,width,height,onImg,offImg,onChangeFunc,describe)
{
  LightAry["LIGHT_"+id] = new LightInfo(id,onImg,offImg,onChangeFunc);

  var o='';
  //var o="";
  //o+="<div id='LIGHT_"+id+"' style='position:absolute; left:"+left+"px; top:"+top+"px; width:"+width+"px; height:"+height+"px; z-index:10'><img id='LIGHT_PIC_"+id+"' src='"+onImg+"' onClick='SwitchLight(\""+id+"\");' lowsrc='"+offImg+"' sv='1' chg='"+onChangeFun+"' style='cursor:pointer ' alt='"+describe+"'></div>";
  o+='<img name="LIGHT_PIC_'+id+'" id="LIGHT_PIC_'+id+'" src="'+offImg+'" title="'+describe+'" alt="'+describe+'" width="'+width+'" height="'+height+'" >';
  //o+="<div id='LIGHT_"+id+"' style='position:absolute; left:"+left+"px; top:"+top+"px; width:"+width+"px; height:"+height+"px; z-index:10'><img id='LIGHT_PIC_"+id+"' src='"+offImg+"' onClick='SwitchLight(\""+id+"\");' style='cursor:pointer ' alt='"+describe+"' onMouseOver='WS(\""+describe+"\");' onMouseLeave='WS();'></div>";
  return o;
  //DW(o);
}

function SwitchLight(id)
{
  var e = GE("LIGHT_PIC_"+id);
  //alert(e);
  if (e != null)
  {
    var obj = LightAry["LIGHT_"+id];
    if (obj != null)
    {
      //alert(obj);
      e.src = obj.switchNext();
    }
  }
}
function GetLight(id)
{
  //return 0;
  //disable buttons
  var e = LightAry["LIGHT_"+id];
  var res = 0;
  if (e != null)
  {
    res = e.value;
  }
  //alert(e.lowsrc);
  return res;
}
function SetLight(id,val)
{
  //if(id == "gpInputIcon2" && val!=0) { alert(GetLight(id)); }
  if (GetLight(id) != val)
  {
    //alert(GetLight(id));
    SwitchLight(id);
  }
}
function SetLightPos(id,x,y)
{
  var e = GE("LIGHT_"+id);
  if (e != null)
  {
    e.style.left=x;
    e.style.top=y;
  }
  //alert(e+":"+x+":"+y);
}
// the light information object
function LightInfo(id,onImg,offImg,chgFun)
{
  this.id = id;
  this.onImg = onImg;
  this.offImg = offImg;
  this.value = 0;
  this.onChangeFunc = chgFun;
  this.switchNext = LightSwitchNext;
}
// switch to next status, and return the new image.
function LightSwitchNext()
{
  var res;
  if (this.value == 0)
  {
    this.value = 1;
    res = this.onImg;
  }
  else
  {
    this.value = 0;
    res = this.offImg;
  }
  if (this.onChangeFunc != null)
  {
    this.onChangeFunc();
  }
  return res;
}
var LightAry = {};

//===========================================
// about Machine type
//===========================================
function IsVS()
{
  var res = false;
  //res = (g_machineCode == "1290" ||g_machineCode == "1280");
  //res = (g_machineCode == "1290" || g_machineCode == "1291");
  
  return res;
}

//===========================================
// Dynamic get content. XMLHttpRequest...
//===========================================
// use XMLHttpRequest to get the content, and put in center web page.
// isForceChange means do not check last page name, just reload it. 
function ChangeContent(link,isNoHis,isForceChange)
{
  if (link != null)
    link = link.toLowerCase();
  //WS((debugC++)+" : "+link);
  if (IsInBadLinkList(link))
    return;
  if (g_lockLink)
  {
    WS("LOCKED...");
    return;
  }
  g_lockLink = true;
  if (link == null)
  {
    link = CONTENT_PAGE;
  }
  else
  {
    CONTENT_PAGE_LAST = CONTENT_PAGE;
    if (isForceChange != true && CONTENT_PAGE==link)
    {
      //alert("link:"+link+":CP:"+CONTENT_PAGE);
      //avoid endless loop
      g_lockLink = false;
      return;
    }

    if (isNoHis != true)
    {
      if (g_backList.length > 0)
      {
        if (g_backList[g_backList.length-1] != link)
        {
          if (g_fwdList.length > 0 )
          {
            //alert(g_fwdList[g_fwdList.length-1]+"(11pop):"+g_backList[g_backList.length-1]+"(push)");
            g_backList.push(g_fwdList.pop());
          }
          //alert("11:g_backList(push) :"+link);
          g_backList.push(link);
        }
        
      }
      else
      {
        if (g_fwdList.length > 0 )
        {
          //alert(g_fwdList[g_fwdList.length-1]+"(22pop):"+g_backList[g_backList.length-1]+"(push)");
          g_backList.push(g_fwdList.pop());
        }

        //alert("22:g_backList(push) :"+link);
        g_backList.push(link);
      }
//      if (g_fwdList.length > 0 )
//      {
//        g_backList.push(g_fwdList.pop());
//      }
      g_fwdList = new Array();
    }

  }
  //20061211 move StopActiveX() to last, if you repeat to click the "image"
  // it will let ActiveX to stop , and can not restart.
  try
  {
    StopActiveX();
  }catch(e){};
  
  CONTENT_PAGE = link;
  if (WCH != null)
  {
    //WCH.onreadystatechange=null;
    delete WCH;
    WCH = null;
  }
  WCH = InitXHttp();
  WCH.onreadystatechange = OnWebContentProcess;
  try
  {
    WCH.open("GET", "/"+link, true);
    WCH.setRequestHeader("If-Modified-Since","0");
  //finally send the call
    WCH.send(null);
//alert("ChangeContent:"+data);
  }
  catch(e)
  {
    alert(GL("err_get_content"));
    CONTENT_PAGE = CONTENT_PAGE_LAST;
  }

  //g_lockLink = false;
}

function FoundBadLink(link)
{
  if (link == null || link == "") return true;
  var badStr=":/.%$#@!~^&*(){}|\\;\"'?><,";
  for (var i=0;i<badStr.length;i++)
  {
    if (link.indexOf(badStr.charAt(i)) >=0)
      return true;
  }
  return false;
}

//ALC , After Load Content
//Note: this function must call in the end of the each page. 
function ALC(time)
{
  WS("");
  g_lockLink = true;
  if(time != null)
    setTimeout(MY_ONLOAD, time);
  else
    setTimeout(MY_ONLOAD, 300);
}

function GetViewCHHtml()
{
  var o='';
  if (IsVS())
  {
    o+='<div id="viewChannelLayer" class="cssViewChLayer">';
    o+=GL('view')+': '+GetCHSelHtml();
    o+='</div>';
  }
  return o;
}

function OnWebContentProcess()
{
  if (WCH == null)
    return;
  if (WCH.readyState == 4 )
  {
    if (WCH.status == 200 || WCH.status==401 || WCH.status==404 || WCH.status==403)
    {
      //alert(WCH.responseText);
      if (WCH.responseText.indexOf("var.js") >=0 )
        return;
      //var body = GE("WebContent");
      //var o = '<span style="display: none">'+I18NHtml(WCH.responseText)+'</span>';
      var o = '';
      //o+=GetViewCHHtml()+GetEmptyCallback()+I18NHtml(WCH.responseText);
      o+=GetEmptyCallback()+I18NHtml(WCH.responseText);
      //alert(o);
      
      // call unload function.
      CallOnUnload();
      //set_innerHTML('WebContent',o);
      setInnerHTML(GE('WebContent'),o);
      setTimeout(CallOnResize,500);
      //GE("WebContent").innerHTML='<span style="display: none">'+I18NHtml(WCH.responseText)+'</span>';
      if (WCH.status != 200)
      {
        g_lockLink = false;
      }
    }
    else
    {
      alert(GL("err_get_content"));
      CONTENT_PAGE = CONTENT_PAGE_LAST;
      g_lockLink = false;
    }
  }
}

function GetEmptyCallback()
{
  var o='';
  o+='<scri'+'pt>function MY_ONUNLOAD(){};function MY_ONLOAD(){g_lockLink = false;};function MY_CH_CHANGE(){};';
  o+='function MY_SUBMIT_OK(){};function MY_ONRESIZE(){};function MY_BEFORE_SUBMIT(){};</scri'+'pt>';
  return o;
}

//===========================================
// call to content script.
//===========================================
function CallOnUnload()
{
  //alert("CallOnUnload");
  g_dmsRun = false;
  clearTimeout(jpegTimer);
  jpegTimer = null;

  clearTimeout(timerChangeImage);
  clearTimeout(FocusbusyTimer);
  clearTimeout(timerMoveUvumiWin);
  if (typeof(MY_ONUNLOAD) == 'function')
    MY_ONUNLOAD();
}

function CallOnResize()
{
  //alert("CallOnResize");
  //alert(document.body.offsetWidth );
  /*var obj = GE("pic");
  var obj2 = GE("pic2");
  if(obj!= null && obj2!= null & g_ePosition!= null)
  {
    GetPosition(g_ePosition,'pic');
    GetPosition(g_ePosition,'pic2');
  }*/
  var halfWidth = document.body.offsetWidth / 2;
  var obj = null;
  obj = GE("logoLayer");
  if (obj != null)
  {
    var tmpX = halfWidth - 370;
    if (g_brandName == "ipx")
    {
      tmpX += 30;
    };
    obj.style.left = tmpX;
  }
  obj = GE("arrowImg");
  if (obj != null)
  {
    obj.style.left = halfWidth + 270;
    obj.style.top = 520;
    var l,r;
    if (CONTENT_PAGE=="main.htm" || CONTENT_PAGE=="c_help.htm")
    {
      g_backList = new Array();
      g_fwdList = new Array();
      obj.style.left = -600;
    }
    else
    {
      var b = (g_backList.length > 0);
      if (g_backList.length == 1 && g_backList[0] == CONTENT_PAGE) b=false;
      var f = (g_fwdList.length > 0);
      if (b && f)
      {
        l=0;
        r=90;
      }
      else if (b)
      {
        l=0;
        r=60;
      }
      else if (f)
      {
        l=30;
        r=90;
      }
      else
      {
        l=30;
        r=60;
      }
      obj.style.clip="rect(0 "+r+" 30 "+l+")";
    }

  }
  if (IsVS())
  {
    obj = null;
    obj = GE("viewChannelLayer");
    if (obj != null)
    {
      obj.style.left = halfWidth + 250;
    }
    SetVisible("viewChannelLayer",(g_CHPageList.indexOf(CONTENT_PAGE+";") >= 0));
  }
  //if (g_isShowPtzCtrl)
  //{
    //FixPtzButtonPos((CONTENT_PAGE=="main.htm"));
  //}
  if (typeof(MY_ONRESIZE) == 'function')
    MY_ONRESIZE();
  
  //g_lockLink=false;
}

//===========================================
// Wrap the control to object.
//===========================================
//SetCCV : SetCommonContrlValue
function SetCCV(id,val)
{
  //alert(id);
  SetCtrlValue(CTRLARY,id,val);
}
function SetCtrlValue(ctrlList,id,val)
{
  var obj = ctrlList[id];
  if (obj != null)
  {
    obj.SV(val);
  }
}
//GetCCV : GetCommonContrlValue
function GetCCV(id)
{
  return GetCtrlValue(CTRLARY,id);
}
function GetCtrlValue(ctrlList,id)
{
  var res = '';
  var obj = ctrlList[id];
  if (obj != null)
  {
    res = encodeURIComponent(obj.GV());
  }
  return res;
}
//
function GetCCV_AES(id)
{
  return GetCtrlValue_AES(CTRLARY,id);
}
function GetCtrlValue_AES(ctrlList,id)
{
  var res = '';
  var obj = ctrlList[id];
  if (obj != null)
  {
    res = obj.GV();
  }
  return res;
}
//Set Control InActive 
function SetCIA(id,val)
{
  CTRLARY[id].active = (val==true);
/*
  var obj = CTRLARY[id];
  if (obj != null)
  {
    obj.active = (val==true);
  }
  else
  {
    alert("ERROR: SetCIA():"+id);
  }
*/  
}
function GetCtrlHtml(ctrlList, id)
{
  var res = '';
  var obj = ctrlList[id];
  if (obj != null)
  {
    if (obj.type == 'radio')
    {
      res = GetRadioONOFF(ctrlList,id);
    }
    else
    {
      res = obj.html;
    }
  }
  return res;
}

function WH(id)
{
  DW(WH_(id));
};

function WH_(id)
{
  return GetCtrlHtml(CTRLARY, id);
};

function WH_DIV(id,div)
{
  return '<div id='+div+'>'+GetCtrlHtml(CTRLARY, id)+'</div>';
};

function WH_DIV2(id,div)
{
  return '<div id='+div+' style="display:inline;">'+GetCtrlHtml(CTRLARY, id)+'</div>';
};

function GetRadioCtrlHtml(ctrlList, id, val)
{
  var res = '';
  var obj = ctrlList[id];
  if (obj != null)
  {
    res = obj.GetHtml(val);
  }
  return res;
}

function WRH(id,val)
{
  DW(WRH_(id,val));
}
function WRH_(id,val)
{
  return GetRadioCtrlHtml(CTRLARY, id,val);
}
function CPASS(ctrl,isQuite)
{
  var res = true;
  if (ctrl.checker != null)
  {
  
    res = ctrl.checker.IsPass(ctrl,isQuite);
  }
  return res;
}
function Ctrl_Select(id,list,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "select";
  this.active = !(inactive==true);
  this.id = id;
  this.list = list;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.html = SelectObjectNoWrite(id,list,val,onChangeFunc);
  //GetValue
  this.GV = function (){ return GetValue(this.id); };
  //SetValue
  this.SV = function (val){ SetValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.rehtml = function(newlist,val){ return SelectObjectNoWrite(this.id,newlist,(val!=null)?val:this.value,this.onChangeFunc);};

}
function Ctrl_SelectNum(id,sNum,eNum,gap,val,setcmd,onChangeFunc,onFocusFunc,fixNumC,checker,inactive)
{
  this.type = "selectNum";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.html = GetSelectNumberHtml(id,sNum,eNum,gap,val,onChangeFunc,onFocusFunc,fixNumC);
  //GetValue
  this.GV = function (){ return GetValue(this.id); };
  //SetValue
  this.SV = function (val){ SetValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};

}
function Ctrl_Text(id,size,maxlen,val,setcmd,checker,isPwd,onChangeFunc,inactive,onKeyUP,onFocus,onBlur)
{
  this.type = "text";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.html = CreateTextHtml(id,size,maxlen,val,isPwd,onChangeFunc,onKeyUP,onFocus,onBlur);
  //GetValue
  this.GV = function (){ return GetValue(this.id); };
  //SetValue
  this.SV = function (val){ SetValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.reHtml = function(newval){
	return CreateTextHtml(this.id,size,maxlen,newval,isPwd,onChangeFunc,onKeyUP);
  };

}
function Ctrl_Check(id,val,setcmd,onClickFunc,checker,inactive)
{
  this.type = "check";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.onClickFunc = onClickFunc;
  this.GetHtml = function ()
  {
    var o='';
    o+='<input type="checkbox" id="'+this.id+'" name="'+this.id+'" ';
    if ( this.value == 1)
    {
      o+= "checked ";
    }
    if ( this.onClickFunc != null)
    {
      o+= "onClick='"+this.onClickFunc+"'";
    }
    o+= " >";
    return o;
  };
  this.html = this.GetHtml();
  //GetValue
  this.GV = function (){ return Bool2Int( IsChecked(this.id) ); };
  //SetValue
  this.SV = function (val){ SetChecked(this.id,(val==1)); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};

}
function Ctrl_Radio(id,val,setcmd,onClickFunc,checker,inactive)
{
  this.type = "radio";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.onClickFunc = onClickFunc;
  this.GetHtml = function (val)
  {
    var o = "<input type='radio' name='"+this.id+"' id='"+this.id+"' class='m1' value='"+val+"' ";
    if ( this.value == val)
    {
      o+= "checked ";
    }
    if ( this.onClickFunc != null)
    {
      o+= "onClick='"+this.onClickFunc+"'";
    }
    o+= " >";
    return o;
  };
  //GetValue
  this.GV = function (){ return GetRadioValue(this.id); };
  //SetValue
  this.SV = function (val){ SetRadioValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};

}
function GetRadioONOFF(id)
{
  return GetRadioONOFF(CTRLARY,id);
}
function GetRadioONOFF(list,id)
{
  var o='';
  o+=GetRadioCtrlHtml(list,id,1);
  o+=GL("on");
  o+=GetRadioCtrlHtml(list,id,0);
  o+=GL("off");
  return o;
}
//enable or disable
function GetRadioENDIS(id)
{
  var o='';
  o+=WRH_(id,1);
  o+=GL("enable");
  o+=WRH_(id,0);
  o+=GL("disable");
  return o;
}
//AD: Allow/Deny
function GetRadioAD(id)
{
  var o='';
  o+=WRH_(id,1);
  o+=GL("allow");
  o+=WRH_(id,0);
  o+=GL("deny");
  return o;
}
//note: onChangeFunc not implement
function Ctrl_IPAddr(id,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "ipaddr";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.onChangeFunc = onChangeFunc;
  this.GetIP = function (s){
    if (s.charAt(0)=='0')
    {
      s = s.replace('0','');
      if (s.charAt(0)=='0')
      {
        s = s.replace('0','');
      }
    }
    if (s == "") return 0;
    return parseInt(s);
  };
  this.GV = function (){
    var o = '';
    for (var i=1;i<5;i++)
    {
      try
      {
        o+=FixNum( this.GetIP(GE(this.id+'_ip'+i).value) , 3);
        o+=(i<4)?".":"";
      }catch (e){};
    }
    this.value = o;
	
    //alert(o.replace(/\./g,""));
    return o.replace(/\./g,"");
  };
  this.SV = function (val){
    var ips = val.split(".");
    if(ips.length>=4)
    {
      for (var i=1;i<5;i++)
      {
        try
        {
          GE(this.id+'_ip'+i).value = this.GetIP(ips[i-1]);
        }catch (e){};
      }
      this.value = val;
    }
  };
  this.GetHtml = function (){
    var ips = this.value.split(".");
    //alert(ips.length);
    var o='';
    o+='<div class="cssIpAddr" id="'+this.id+'">';
    for (var i=1;i<5;i++)
    {
      //alert(ips[i-1]);
      o+='<input type="text" value="'+((ips.length>=4)?this.GetIP(ips[i-1]):'0')+'" name="'+this.id+'_ip'+i+'" id="'+this.id+'_ip'+i+'" maxlength=3 class="cssIpAddrItem" onkeyup="IPMask(this,event)" onkeydown="IPMaskDown(this,event)" onblur="if(this.value==\'\')this.value=\'0\';" onbeforepaste=IPMask_c()>';
      o+=(i<4)?".":"";
    }
    o+='</div>';
    return o;
  };
  this.html = this.GetHtml();
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.Disable = function (isDis)
  {
    this.active = !isDis;
    for (var i=1;i<5;i++)
      DisableObject(this.id+'_ip'+i,isDis);
  }

}
//note: onChangeFunc not implement
function Ctrl_IPFilter(id,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "ipfilter";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.onChangeFunc = onChangeFunc;
  this.GetIP = function (s){
    if (s.charAt(0)=='0')
    {
      s = s.replace('0','');
      if (s.charAt(0)=='0')
      {
        s = s.replace('0','');
      }
    }
    if (s == "") return 0;
    //return parseInt(s);
    return s;
  };
  this.GV = function (){
    var o = '';
    for (var i=1;i<5;i++)
    {
      try
      {
        o+=this.GetIP(GE(this.id+'_ip'+i).value);
        o+=(i<4)?".":"";
      }catch (e){};
    }
    this.value = o;
    return o;
  };
  this.SV = function (val){
    var ips = val.split(".");
    if(ips.length>=4)
    {
      for (var i=1;i<5;i++)
      {
        try
        {
          GE(this.id+'_ip'+i).value = this.GetIP(ips[i-1]);
        }catch (e){};
      }
      this.value = val;
    }
  };
  this.GetHtml = function (){
    var ips = this.value.split(".");
    //alert(ips.length);
    var o='';
    o+='<div class="cssIpFilter" id="'+this.id+'">';
    for (var i=1;i<5;i++)
    {
      //alert(ips[i-1]);
      o+='<input type="text" value="'+((ips.length>=4)?this.GetIP(ips[i-1]):'0')+'" name="'+this.id+'_ip'+i+'" id="'+this.id+'_ip'+i+'" maxlength=9 class="cssIpFilterItem" onkeyup="IPMask(this,event,true)" onkeydown="IPMaskDown(this,event)" onblur="if(this.value==\'\')this.value=\'0\';" onbeforepaste=IPMask_c(true)>';
      o+=(i<4)?".":"";
    }
    o+='</div>';
    return o;
  };
  this.html = this.GetHtml();
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.Disable = function (isDis){
    for (var i=1;i<5;i++)
      DisableObject(this.id+'_ip'+i,isDis);
  };

}
function Ctrl_IPFilter_Dlink(id,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "ipfilter";
  this.active = !(inactive==true);
  this.id = id;
  this.value = val;
  this.setcmd = setcmd;
  this.checker = checker;
  this.onChangeFunc = onChangeFunc;
  this.GetIP = function (s){
    if (s.charAt(0)=='0')
    {
      s = s.replace('0','');
      if (s.charAt(0)=='0')
      {
        s = s.replace('0','');
      }
    }
    if (s == "") return 0;
    //return parseInt(s);
    return s;
  };
  this.GV = function (){
    var o = '';
    for (var i=1;i<5;i++)
    {
      try
      {
        o+=this.GetIP(GE(this.id+'_ip'+i).value);
        o+=(i<4)?".":"";
      }catch (e){};
    }
    this.value = o;
    return o;
  };
  this.SV = function (val){
    var ips = val.split(".");
    if(ips.length>=4)
    {
      for (var i=1;i<5;i++)
      {
        try
        {
          GE(this.id+'_ip'+i).value = this.GetIP(ips[i-1]);
        }catch (e){};
      }
      this.value = val;
    }
  };
  this.GetHtml = function (){
    var ips = this.value.split(".");
    //alert(ips.length);
    var o='';
    o+='<div class="cssIpFilter_dlink" id="'+this.id+'">';
    for (var i=1;i<5;i++)
    {
      //alert(ips[i-1]);
      o+='<input type="text" value="'+((ips.length>=4)?this.GetIP(ips[i-1]):'0')+'" name="'+this.id+'_ip'+i+'" id="'+this.id+'_ip'+i+'" maxlength=5 class="cssIpFilterItem_dlink" onkeyup="IPMask(this,event,true)" onkeydown="IPMaskDown(this,event)" onblur="if(this.value==\'\')this.value=\'0\';" onbeforepaste=IPMask_c(true)>';
      o+=(i<4)?".":"";
    }
    o+='</div>';
    return o;
  };
  this.html = this.GetHtml();
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.Disable = function (isDis){
    for (var i=1;i<5;i++)
      DisableObject(this.id+'_ip'+i,isDis);
  };

}
//===========================================
// IP Mask control
//===========================================
function FocusToNextIPAddr(obj,isNext,select)
{
  //alert(obj+":"+isNext);
  obj.blur();
  var nextip=parseInt(obj.name.charAt(obj.name.length-1));
  nextip=(isNext)?nextip+1:nextip-1;
  nextip=nextip>=5?1:nextip;
  nextip=nextip<=0?4:nextip;
  try
  {
    var oo = GE(obj.name.substring(0,obj.name.length-1)+nextip);
    oo.focus();
    if (select)
    {
      oo.select();
    }
  }catch (e){};

}
function IPMaskDown(obj,evt)
{
  var key1 = evt.keyCode;
  if(key1 == 190 || key1 == 110)
  {
    FocusToNextIPAddr(obj,true,false);
  }
}
function IPMask(obj,evt,isFilter)
{
  var key1 = evt.keyCode;
  //alert(key1);
  if (!(key1==46 || key1==8 || key1==48 || (key1>=49 && key1<=57) || (key1>=97 && key1<=104) ))
  {
    if (isFilter == true)
    {
      obj.value=obj.value.replace(/[^\d\-\*\(\)]/g,'');
    }
    else
    {
      obj.value=obj.value.replace(/[^\d]/g,'');
    }
  }

  if(key1 == 190 || key1 == 110)
  {
    obj.select();
  }
  //alert(key1);
  if( key1==37 || key1==39 )
  {
    //alert("a:"+key1);
    FocusToNextIPAddr(obj,(key1==39),false);
  }  
  if(obj.value.length>=3)
  {
    if(parseInt(obj.value)>=256  ||  parseInt(obj.value)<0)
    {
      alert(GL("err_ip_address"));
      obj.value="";
      obj.focus();
      return  false;
    }
//    else  
//    {
      //alert("b:"+key1+":"+obj.value);
      //FocusToNextIPAddr(obj,true,true);
//    }
  }
}
function IPMask_c(isFilter)
{
  var txt = clipboardData.getData('text');
  txt = (isFilter==true)?txt.replace(/[^\d\-\*\(\)]/g,''):txt.replace(/[^\d]/g,'');
  clipboardData.setData('text',txt);
}
//===========================================
// validate control and submit
//===========================================
function GetSetterCmd(ctrl,val)
{
  return GetSetterCmdKV(ctrl.setcmd,val);
}
//direct input the name and value
function GetSetterCmdKV(name,val)
{
  var o = "&"+name;
  //Luther memo: it is important, null string is equals 0, :(
  if (isNaN(parseInt(val)) && val=="")
  {
    val = "(null)";
  }
  //if setcmd contain "=" ,it's mean video server do not add channel id.
  if (name.indexOf("=")<0)
  {
    o+="=";
    if(IsVS())
    {
      o += g_CHID+":";
    }
  }
  //add value
  o += val;
  return o;
}

var firstCmdList = null;
var firstCmdTotal = 0;
function addBeforSubmitCmd(cmd)
{
	if(firstCmdTotal<=0)
	{
		firstCmdList = new Array();
		firstCmdTotal = 0;
	}
	
	firstCmdList[firstCmdTotal] = cmd;
	firstCmdTotal++;
	
}

var cmdlist = null;
var cmdtotal = 0;
function ValidateCtrlAndSubmit(ctrlList,isAsync,SubmitCallBack)
{
	if (g_lockLink)
	{
		WS("LOCKED...");
		return;
	}

	if (isAsync == null) isAsync=false;
	//validate
	var res = true;
	for(var key in ctrlList)
	{
		var obj = ctrlList[key];
		if (obj.active)
		{
			res = obj.IsPass();
			if (!res)
			{
				return res;
			}
		}
	}

	//call back
	if ( MY_BEFORE_SUBMIT() == false )
	{
		return false;
	}

	g_httpOK = true;
	var len = g_MaxSubmitLen;
	cmdlist = new Array();
	cmdtotal = 0;
	if(firstCmdTotal>0)
	{
		for(var i=0; i<firstCmdTotal; i++)
		{
			cmdlist[cmdtotal] = firstCmdList[i];
			cmdtotal++;
		}
	}
	cmdtotal++;
	cmdlist[cmdtotal-1] = c_iniUrl;
	
	for(var key in ctrlList)
	{
		var obj = ctrlList[key];
		if (obj.active)
		{
			var str;
			if(g_support_aes == 1)
			{
				if(key == 'password')
				{
					str = '&pppoecert' + '=' + encodeURIComponent(AES_Encrypt128(str2hexstr(GetCtrlValue_AES(ctrlList,key)), encry_val));
				}
				else if(key == 'repassword')
					str = "";
				else
					str = GetSetterCmd(obj,GetCtrlValue(ctrlList,key));
			}
			else
			{
				str = GetSetterCmd(obj,GetCtrlValue(ctrlList,key));
			}
			
			cmdlist[cmdtotal-1] += str;
			
			len -= str.length;
			if (len < 10) {
				cmdtotal++;
				cmdlist[cmdtotal-1] = c_iniUrl;
				len = g_MaxSubmitLen;
			}
		}
	}
	//alert(cmdlist);
	SendAllCmd(1, SubmitCallBack);
};

var cmdindex = 0;
var cmdcallback = null;
function SendAllCmd(index, callback)
{
	cmdindex = index;
	cmdcallback = callback;
	//alert(cmdlist[index-1]);
	SendHttp(cmdlist[index-1], false, onSubmitallStatus);
};

function onSubmitallStatus()
{
	if (g_SubmitHttp.readyState == 4)
	{
		if (g_SubmitHttp.status != 200)
		{
			alert(g_SubmitHttp.status+" "+GL("err_submit_fail"));
			
			g_httpOK = false;
			WS(GL("fail_"));
			
			firstCmdList = null;
			firstCmdTotal = 0;
		}
		else
		{
			cmdindex++;
			//alert(cmdindex+" "+cmdtotal);
			if(cmdindex <= cmdtotal)
			{
				SendAllCmd(cmdindex, cmdcallback);
			}
			else
			{
				g_httpOK = true;
				WS(GL("ok_"));
				
				if(cmdcallback != null)
					cmdcallback();
				
				MY_SUBMIT_OK();
				
				firstCmdList = null;
				firstCmdTotal = 0;
			}
		}
	}
};

//===========================================
// Dispaly Message on browser status bar
//===========================================
function WS(msg)
{
  window.status = (msg==null)?"":msg;
}
//===========================================
// about video server channel
//===========================================
// Get the channel id from the global variable "g_CHID".
function GetCHSelHtml()
{
  var o="";
  o+="<select onChange='ChangeViewCH(this.value)' id='viewCHSel' class='m1'>";
  for (var i=0;i<5;i++)
  {
    o+="<option value='"+i+"' "+((i==g_CHID)?"selected":"")+">"+((i==0)?"---":i)+"</option>";
  }
  o+="</select>";
  return o;
}
function ChangeViewCH(id)
{
  //focus lost
  window.focus();
  GE("viewCHSel").blur();
  
  if (g_CHID == 0 || id == 0)
  {
    if (CONTENT_PAGE == "main.htm")
    {
      g_CHID=id;
      ChangeContent();
    }
    else
    {
      // no change g_CHID
      SetValue("viewCHSel",g_CHID);
      MY_CH_CHANGE();
      //20070419 Luther add 1 line
      ChangeChannelTextPanel(g_CHID);
    }
  }
  else
  {
    g_CHID=id;
    MY_CH_CHANGE();
    //20070419 Luther add 1 line
    ChangeChannelTextPanel(g_CHID);
  }
}
function GetLogoHtml()
{
  var o='';
  if (g_brandName != "nobrand")
  {
    o+='<div id="logoLayer" class="cssLogoLayer" >';
    var hasUrl = !(g_brandUrl == null || g_brandUrl == "" || g_brandUrl == "(null)");
    if (hasUrl)
    {
      o+='<a href="'+g_brandUrl+'" target="_blank">';
    }
    o+='<img border=0 src="'+g_brandName+'.gif">';
    if (hasUrl)
    {
      o+='</a>';
    }
    o+='</div>';
  }
  return o;
}
//===========================================
// Common comtent
//===========================================
//PH : Page Header
function GetPHHtml(key,bodytxt)
{
  return GetPHTxtHtml(GL(key),bodytxt);
}
//show text, not keyword.
function GetPHTxtHtml(txt,bodytxt)
{
  // 20090205 Netpool Modified for D-Link Style
  var o='';
  o+='<table class="maincontent" align="center" border="0" cellspacing="0" cellpadding="0" >';
  o+='<tr><td class="box_header" >'+txt+'</td></tr>';
  o+='<tr><center><td class="box_body" >';
  if(bodytxt == null)
    o+='&nbsp;';
  else
    o+=bodytxt;
  o+='</td></center></tr>';
  o+='</table>';
  return o;
}
function WritePH(key,bodytxt)
{
  DW(GetPHHtml(key,bodytxt));
}
function WriteTxtPH(txt)
{
  DW(GetPHTxtHtml(txt));
}
// 20090206 Netpool Add for D-Link Style
function WriteImagePH(useAX,isOK)
{
  DW('<table class="maincontent" align="center" border="0" cellspacing="0" cellpadding="0" >' );
  DW('<tr><td class="page_header">Live Video</td></tr>');
  DW('<tr><td class="page">');

  DW('<table border=0 cellspacing=0 cellpadding=0 align="center" >');
  DW('<tr height="20" bgcolor="#000000"><td align="left" ><span id="devTitleLayer" class="text1" >'+g_titleName+'</span></td></tr>');
  DW('<tr><td><center><div id="imgAX">');
  if (isOK)
    DW(GetImageLeftVideo(useAX));
  else
    DW("<img id='sampleimg' name='sampleimg' src='/Loading.gif' width=352 height=240 border=2>");
  DW('</div></center></td></tr></table>');

  DW('</td></tr></table>');
};
//===========================================
// Common Image Content
//===========================================
//useAX: use ActiveX control ? yes or not, 
//isOK: if in changing mode. isOK is false.
//PH : Page Header
function WriteImageTxtPH(txtTitle,useAX,isOK)
{
  DW('<table border="0" cellspacing="1" cellpadding="0" width="880" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  //20090203 Netpool Modified for D-Link Style
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  //20090228 chirun del
  //DW(CommonGetMenuStr(MENU_ITEM_IMAGE));
  DW(GetDLinkMenuStr(MENU_ITEM_STATUS, addMenu));
  DW('</td><td align="left" vAlign="top" width="650" >');

  var headTxt='Here is The Text of Head.';
  var bodyHTML='Here is HTML of body what you want to write.';
  DW(GetDLinkBox(headTxt,"000000","ff6f00",bodyHTML,"000000","dfdfdf",600));
  headTxt='Here is The 2th Text of Head.';
  bodyHTML='Here is the 2th HTML of body what you want to write.';
  DW(GetDLinkOrangeBox(headTxt,bodyHTML));
  headTxt='Here is The 3th Text of Head.';
  bodyHTML='Here is the 3th HTML of body what you want to write.';
  DW(GetDLinkBlackBox(headTxt,bodyHTML));

  //WriteTxtPH(txtTitle);
  //WriteImagePH(useAX,isOK);
  WriteDLinkTxtTablePH(txtTitle);
}
//PB : Page Bottom
function WriteImagePB()
{
  //20090206 Netpool Modified for D-Link Style
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td id="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}

function VS_NO_VIEW_ALL()
{
  if (g_CHID==0) g_CHID = 1;
  if (IsVS())
  {
    try
    {
    GE('viewCHSel').selectedIndex = g_CHID;
    }catch(e){};
  }
}
function ImageOnLoad(isNoShowWaitImg,useAX,codec,mode,forceWait)
{
  VS_NO_VIEW_ALL();
  //CallOnResize();
//alert(mode);
  if (isNoShowWaitImg)
  {
    if (useAX==1 || IsMpeg4())
    {
      if (!IsVS())
      {
        StartActiveXEx(0,0,codec,null,null,mode,forceWait);
        //video server will start in MY_CH_CHANGE		
      }
    }
    else
    {
      imgFetcher.RunDms();
    }
  }
  if (IsVS())
  {
    MY_CH_CHANGE();
  }
};
//===========================================
// Common Netowrk Content
//===========================================
//PH : Page Header
function WriteNetPH(titleKey,extMenu)
{
  //20090206 Netpool Modified for D-Link Style
  DW('<table border="0" cellspacing="1" cellpadding="0" width="900" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  DW(CommonGetMenuStr(MENU_ITEM_NETWORK, extMenu));
  DW('</td><td align="left" vAlign="top" width="650" >');
  WritePH(titleKey);
  WriteDLinkTablePH(titleKey);
}
//PB : Page Bottom
function WriteNetPB()
{
  //20090206 Netpool Modified for D-Link Style
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td id="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}
function WIPX(tid,ctx)
{
  DW('<tr class="b1"><td width=150 height="30" >');
  DW(GL(tid)+':</td><td >'+ctx+'</td></tr>');
}
function WIP(tid,id)
{
  WIPX(tid,WH_(id));
}
function WIP1(ctx,css)
{
  DW('<tr class="'+((css==null)?"b1":css)+'" width=150><td colspan=2 height="30" >');
  DW( ctx+'</td></tr>');
}                             
function WIPSubmit(isAsync)
{
  DW("<tr><td colspan=2 align=center><br>");
  CreateSubmitButton(null,isAsync);
  DW("</td></tr>");
}
//===========================================
// Common Application Content
//===========================================
//PH : Page Header
function WriteAppPH(titleKey)
{
  return WriteAppTxtPH(GL(titleKey))
}
function WriteAppTxtPH(txtTitle)
{
  //20090206 Netpool Modified for D-Link Style
  DW('<table border="0" cellspacing="1" cellpadding="0" width="900" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  DW(GetMenuAppStr());
  DW('</td><td align="left" vAlign="top" width="650" >');
  WriteTxtPH(txtTitle);
  WriteDLinkTxtTablePH(txtTitle);
}

//PB : Page Bottom
function WriteAppPB()
{
  //20090206 Netpool Modified for D-Link Style
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td id="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}
function WTablePH(w)
{
  DW("<center><table width="+((w!=null)?w:"450")+" border=0 cellPadding=0 cellSpacing=0>");
}
function WTablePB()
{
  DW("</table></center>");
}
function WIApp(id,enid,ctx)
{
  DW("<tr><td height=30 class='b1'>");
  DW(WH_(id)+" "+GL(enid)+" - "+ctx+"");
  DW("</td></tr>");
}
function WIApp1(ctx)
{
  DW("<tr><td height=30 class='b1' style='text-indent:3em'>"+ctx+"</td></tr>");
}
function WIAppSubmit()
{
  DW("<tr><td ><center><br>")
  CreateSubmitButton();
  DW("</td></tr>");
}
//===========================================
// Common System Content
//===========================================
//PH : Page Header
function WriteSysPH(titleKey,addMenu)
{
  return WriteSysTxtPH(GL(titleKey),addMenu);
}
function WriteSysTxtPH(txtTitle,addMenu)
{
  //20090206 Netpool Modified for D-Link Style
  DW('<table border="0" cellspacing="1" cellpadding="0" width="900" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  DW(CommonGetMenuStr(MENU_ITEM_SYSTEM, addMenu));
  DW('</td><td align="left" vAlign="top" width="650" >');
  WriteTxtPH(txtTitle);
  WriteDLinkTxtTablePH(txtTitle);
}
//PB : Page Bottom
function WriteSysPB()
{
  //20090206 Netpool Modified for D-Link Style
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td id="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}
//===========================================
// Common Status chirun add for D-link(7315)
//===========================================
//PH : Page Header
function WriteStatusPH(titleKey,addMenu)
{
  return WriteStatusTxtPH(GL(titleKey),addMenu);
}
function WriteStatusTxtPH(txtTitle,addMenu)
{
  DW('<table border="0" cellspacing="1" cellpadding="0" width="900" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  DW(CommonGetMenuStr(MENU_ITEM_STATUS, addMenu));
  DW('</td><td align="left" vAlign="top" width="650" >');
}
//PB : Page Bottom
function WriteStatusPB()
{
  //20090206 Netpool Modified for D-Link Style
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td class="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}
//===========================================
// Common Maintenance chirun add for D-link(7315)
//===========================================
//PH : Page Header
function WriteMaintenancePH(titleKey,addMenu)
{
  return WriteMaintenanceTxtPH(GL(titleKey),addMenu);
}
function WriteMaintenanceTxtPH(txtTitle,addMenu)
{
  DW('<table border="0" cellspacing="1" cellpadding="0" width="900" height="500" align="center" bgcolor="#FFFFFF" bordercolordark="#FFFFFF" >');
  DW('<tr><td id="sidenav_container" align="left" vAlign="top" >');
  DW(CommonGetMenuStr(MENU_ITEM_MAINTENANCE, addMenu));
  DW('</td><td align="left" vAlign="top" width="650" >');
}
//PB : Page Bottom
function WriteMaintenancePB()
{
  WriteDLinkTablePB();
  DW('</td>');
  DW('<td id="sidenav_container" align="left" vAlign="top" >');
  DW('</td></tr></table>');
}
//===========================================
// Checker Object
//===========================================
//each checker has one validateObj and can link to another checker
function CheckerObj(validateObj, linkChecker)
{
  this.validateObj = validateObj;
  this.linkChecker = linkChecker;
  //this.ctrlList = ctrlList;
  this.IsPass = function(ctrlObj,isQuite)
  {
    var res = true;
    if (this.linkChecker != null)
    {
      res = this.linkChecker.IsPass(ctrlObj,isQuite);
    }
    if (res == true)
    {
      res = this.validateObj.IsPass(ctrlObj.GV(),isQuite);
	  
    }
    if (res == false)
    {
      try
      {
        var obj = GE(ctrlObj.id);
        obj.focus();
        obj.select();
      }catch (e){};
    }
    return res;
  };
}
//ValidateObj must implement IsPass(isQuite) return ture or false
//check the string length ,range (minLen <= x <= maxLen)
function V_StrLen(minLen,maxLen,defMsg,msg)
{
  //this.ctrlID = ctrlID;
  this.defMsg = defMsg;
  this.msg = msg;
  this.minLen = minLen;
  this.maxLen = maxLen;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadStrLen(val,this.minLen,this.maxLen,this.defMsg,this.msg,isQuite));
  };
}
//check the string is English or number
function V_StrEnglishAndNumber(defMsg,msg,noCheckNum,noCheckLower,noCheckUpper )
{
  //this.ctrlID = ctrlID;
  this.defMsg = defMsg;
  this.msg = msg;
  this.noNum = noCheckNum;
  this.noLower = noCheckLower;
  this.noUpper = noCheckUpper;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadEnglishAndNumber(val,this.defMsg,this.msg,this.noNum,this.noLower,this.noUpper,isQuite));
  };
}
//check the string is English or number
function V_StrEnAndNumAndChar(defMsg,SpecialChar,isQuite )
{
  //this.ctrlID = ctrlID;
  this.defMsg = defMsg;
  this.SpecialChar = SpecialChar;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadEnglishAndNumberAndSpecialCharEx(val,this.defMsg,this.SpecialChar,isQuite));
  };
}
//check the string is English or number and allow special char
function V_StrEngNumAndSpecialChar(defMsg,SpecialChar )
{
  //this.ctrlID = ctrlID;
  this.defMsg = defMsg;
  this.SpecialChar = SpecialChar;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadEnglishAndNumberAndSpecialCharEx(val, this.defMsg, this.SpecialChar, isQuite));
  };
}
//check the string is disallow special char.
function V_DisallowSpecialChar(defMsg, SpecialChar)
{
  //this.ctrlID = ctrlID;
  this.defMsg = defMsg;
  this.SpecialChar = SpecialChar;
  this.IsPass = function(val, isQuite)
  {
    return !(CheckSpecialChar(val,this.defMsg,this.SpecialChar,isQuite));
  };
}
function V_NumRange(min,max,defMsg,msg,extra)
{
  this.min = min;
  this.max = max;
  this.defMsg = defMsg;
  this.msg = msg;
  this.extra = extra;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadNumberRange(val,this.min,this.max,this.defMsg, this.msg, isQuite, this.extra));
  }
}
function V_Empty(defMsg,msg,isQuite)
{
  this.defMsg = defMsg;
  this.msg = msg;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckIsNull(val, this.defMsg, this.msg, isQuite));
  }
}
function V_EMail(msg)
{
  this.msg = msg;
  this.IsPass = function(val,isQuite)
  {
    return !(CheckBadEMail(val,this.msg,isQuite));
  }
}

function V_Hex()
{
  this.IsPass = function(val,isQuite)
  {
    return (CheckHex(val,isQuite));
  }
}

function V_Ip(msg)
{
  this.msg = msg;
  this.IsPass = function(val,isQuite)
  {
    return CheckIpFormat(val,this.msg,isQuite);
  }
}
//===========================================
// Global validate object
//===========================================
var gv_ipPort = new V_NumRange(1,65535,"");
var gco_ipPort = new CheckerObj(gv_ipPort);
var gv_byte = new V_NumRange(0,255,"");
var gco_byte = new CheckerObj(gv_byte);
var gv_empty = new V_Empty(GL("text_field"));
var gco_empty = new CheckerObj(gv_empty);
var gv_email = new V_EMail();
var gco_email = new CheckerObj(gv_email,gco_empty);
var gv_engNum = new V_StrEnglishAndNumber("");
var gco_engNum = new CheckerObj(gv_engNum,gco_empty);
var gv_hex = new V_Hex();
var gco_hex = new CheckerObj(gv_hex,gco_empty);
var gv_ip = new V_Ip("err_ip_address");
var gco_ip = new CheckerObj(gv_ip);
function Hex2Dec(hex)
{
  return parseInt(hex,16);
}
function Dec2Hex(dec)
{
  return dec.toString(16).toUpperCase();
}
//===========================================
// CSS style position.
//===========================================
function SetPos(id,x,y,w,h)
{
  var obj = GE(id);
  if (obj != null && obj.style != null)
  {
    try
    {
      obj.style.width = w;
      obj.style.height = h;
      obj.style.top = y;
      obj.style.left = x;
    }catch(e){};
  }
}
//===========================================
// Index Page
//===========================================
//Luther add for CMS access
function IndexCMSContent()
{
  DW('<link href="lc_en_us.css?'+webVer+'" rel="stylesheet" type="text/css"></head><body><table><tr><td valign="top" width="745"><div id="WebContent" ></div></td></tr></table></body>');  if (THIS_PAGE != null && THIS_PAGE.indexOf("?")>=0)
  {
    var ss = THIS_PAGE.split("?");
    if (FoundBadLink(ss[1]))
    {
      ChangeContent(page);
    }
    else
    {
    //alert(ss[1]+":"+CONTENT_PAGE+":"+ss[0]);
    if (ss[0] == ss[1]+".htm")
      ChangeContent(page);
    else
      ChangeContent(ss[1]+".htm");
    }
  }

}

function IndexContent(page,noHead,index,extTitle)
{
  if (noHead != true)
  {
    WriteDLinkHtmlHead(extTitle,null,null,"CallOnUnload","CallOnResize",null,index);
  }
  WriteDLinkBottom(index);

  if (THIS_PAGE != null && THIS_PAGE.indexOf("?")>=0)
  {
    var ss = THIS_PAGE.split("?");
    if (FoundBadLink(ss[1]))
    {
      ChangeContent(page);
    }
    else
    {
    //alert(ss[1]+":"+CONTENT_PAGE+":"+ss[0]);
    if (ss[0] == ss[1]+".htm")
      ChangeContent(page);
    else
      ChangeContent(ss[1]+".htm");
    }
  }
  else
  {
    ChangeContent(page);
  }
}

function MoveOnArrow(evt)
{
  var obj = GE("arrowImg");
  if (obj != null)
  {
    var v = parseInt(evt.x) - parseInt(obj.style.left);
    if (v < 30)
    {
      WS(GL("back"));
    }
    else if (v < 60)
    {
      WS(GL("reload"));
    }
    else
    {
      WS(GL("forward"));
    }
  }
}
function ClickArrow(evt)
{
  var obj = GE("arrowImg");
  if (obj != null)
  {
    if (g_lockLink)
    {
      WS("LOCKED...");
      return;
    }
    var v = parseInt(evt.x) - parseInt(obj.style.left);
    if (v < 30)
    {
      if (g_backList.length > 0)
      {
        var k = g_backList.pop();
//alert("33 g_backList pop "+k);
        g_fwdList.push(k);
//alert("44 g_fwdList push "+k);
//alert("C:"+CONTENT_PAGE+" B:"+g_backList.length+" F:"+g_fwdList.length);
        while (k == CONTENT_PAGE)
        {
          k = g_backList.pop();
          g_fwdList.push(k);
//alert("55g_backList pop "+k);
        }
        if (k != null)
        {
//          g_backList.push(k);
          //g_fwdList.push(k);
//alert("66g_fwdList push "+k);
          ChangeContent(k,true);
        }
      }
    }
    else if (v < 60)
    {
      ChangeContent(null,true);
    }
    else
    {
      if (g_fwdList.length > 0)
      {
        var k = g_fwdList.pop();
//alert("77g_fwdList pop "+k);
        g_backList.push(k);
//alert("88g_backList push "+k);
//alert("C:"+CONTENT_PAGE+" B:"+g_backList.length+" F:"+g_fwdList.length);
        while (k == CONTENT_PAGE)
        {
          
          k = g_fwdList.pop();
          g_backList.push(k);
//alert("99g_fwdList pop "+k);
        }
        if (k != null)
        {
          //g_fwdList.push(k);
          //g_backList.push(k);
//alert("AAg_backList push "+k);
          ChangeContent(k,true);
        }
      }
    }

  }
  
}

//============About JPEG Viewer===========
//use AJAX to replace Java Applet.
var g_maxDmsObj = 16;
var g_fetchList = {};
var jpegCounter = 0;
var jpegTimer = null;
var g_dmsRun = false;
var zeroFpsCount = 0;
var g_dmsDelayTime = 200; //����dms�n�Ϫ��t��

function ImageFetcher(myid)
{
  this.bufImg1 = new Image();
  this.bufImg2 = new Image();
  this.newImg = this.bufImg1;
  this.myID = myid;
  this.GetDmsImgStr = function (w,h)
  {
    //20070613 Luther fix 1280 * 960
    if (w > 720)
    {
      h = (720 * h) / w;
      w = 720;
    }
    return '<img src="" width="'+w+'" height="'+h+'" id="showdms_'+this.myID+'" border=0 >';
  };
  // 2013.03.18 add CalDelayTime by williamchen
  this.CalDelayTime = function()   
  {
  	
	if(mpMode<=g_numProfile)
	{
		if(l_profileformat[mpMode-1]=="JPEG")
			g_dmsDelayTime = 5;//1000 / parseInt(l_profilerate[mpMode-1]);
		else
			g_dmsDelayTime = 1000;
	}
	else
	if(mpMode==g_numAllProfile)
	{
		g_dmsDelayTime = 200;	// 5 image per second.
	}
	else
	{
		g_dmsDelayTime = 1000;	// 1 image per second.
	}
	
  }

  this.imgSwitch = function ()
  {
    if (this.newImg == this.bufImg1)
    {
      this.newImg = this.bufImg2;
    }
    else
    {
      this.newImg = this.bufImg1;
    }
  }
  
  this.RunDms = function ()
  {
    if (jpegTimer == null)
    {
      jpegTimer = setTimeout("JpegFrameCal()",1000);
    }
    g_dmsRun = true;
    //this.newImg = new Image();
    //this.imgSwitch();		//20141014 william remark
    //var d = g_dmsList[id];
    var obj = GE("showdms_"+this.myID);
    if (obj != null)
    {
      this.newImg.id = "showdms_"+this.myID;
      this.newImg.onload=DmsOK;
      this.newImg.src="/dms?nowprofileid="+mpMode+"&"+Math.random();
    }
  };


}
function DmsOK()
{
  
  var z = 1;
  if (GE("zoomSel") != null)
  {
    z = parseInt(GetValue("zoomSel"));
  }
  //var obj = GE("showdms_"+this.myID);
  var obj = GE("showdms_0");

  if (obj != null)
  {
    var p = obj.parentNode;
	//add williamchen 2013.06.25  
	var o_width=obj.width;
	var o_height=obj.height;
	//end
	p.removeChild(obj);
    var b = imgFetcher.newImg;
    if (CONTENT_PAGE=="main.htm")
    {
      b.width=g_viewXSize*z;
      b.height = g_viewYSize*z;
    }
    else
    {
		 if (browser_IE) //for ie10
		  {  
		  b.width=o_width;
		  b.height=o_height;
		  }	
		  else{		
		  b.width=obj.width;
		  b.height=obj.height;
		  }
    }
	p.appendChild(b);

	
	if (g_dmsRun && !g_lockLink) {	
		setTimeout("imgFetcher.RunDms()",g_dmsDelayTime);
	}
	
    jpegCounter++;
  }

}


var imgFetcher = new ImageFetcher(0);
g_fetchList[0] = imgFetcher;
/*
function GetDmsImgStr(id,w,h)
{
  return '<img src="" width="'+w+'" height="'+h+'" id="showdms_'+id+'" border=0 >';
}
*/
/*
//id is from 0 to 15
function RunDms(id)
{
  if (jpegTimer == null)
  {
    jpegTimer = setTimeout("JpegFrameCal()",1000);
  }
  g_dmsRun = true;
  g_dmsList[id] = new Image();
  var d = g_dmsList[id];
  var obj = GE("showdms_"+id);
  if (obj != null)
  {

    d.id = "showdms_"+id;
    d.onload=DmsOK;
    d.src="/dms?"+Math.random();
  }
}
function DmsOK()
{
  //id = 0;
  var z = 1;
  if (GE("zoomSel") != null)
  {
    z = parseInt(GetValue("zoomSel"));
  }
  for (var i=0;i<g_maxDmsObj;i++)
  {
    var obj = GE("showdms_"+i);
    if (obj != null)
    {
      var p = obj.parentNode;
      p.removeChild(obj);
      var b = g_dmsList[i];
      if (CONTENT_PAGE=="main.htm")
      {
        b.width=g_viewXSize*z;
        b.height = g_viewYSize*z;
      }
      else
      {
        b.width=obj.width;
        b.height = obj.height;
      }
      p.appendChild(b);
      if (g_dmsRun && !g_lockLink) setTimeout("RunDms("+i+")",5);
      jpegCounter++;
    }
  }
}
*/

//--start 2011.4.7 added
function UpdateGlobalViewHeight()
{
	var size = l_profileresolution[g_numAllProfile-1].split('x');
	var rate = g_globalWidth/size[0];
	g_globalHeight = Math.ceil(rate*size[1]);
	//alert("g_globalWidth="+g_globalWidth+" g_globalHeight="+g_globalHeight);
}
//--end 2011.4.7
//--start 2011.4.7 added
function UpdateViewHeight()
{
	var size = l_profileresolution[g_numAllProfile-1].split('x');
	var rate = g_ViewerWidth/size[0];
	g_ViewerHeight = Math.ceil(rate*size[1]);
	//alert("g_globalWidth="+g_globalWidth+" g_globalHeight="+g_globalHeight);
}
//--end 2011.4.7

var initialCoords = true;
var g_Cropper;
function RunCropper()
{
  //alert(mpMode);
  initialCoords = true;
  var size = l_profileresolution[mpMode-1].split('x');
  g_ResolutionX = size[0];
  g_ResolutionY = size[1];
  //alert(g_ResolutionX+','+g_ResolutionY);
	
  g_GlobalRateX = g_globalWidth/g_ResolutionX;
  g_GlobalRateY = g_globalHeight/g_ResolutionY;
	
  var solution = l_profilereviewer[mpMode-1].split('x');
  //alert(solution[0]+','+solution[1]);
  var xx = Math.floor(solution[0]*g_GlobalRateX);
  var yy = Math.floor(solution[1]*g_GlobalRateY);
  if(xx>g_globalWidth)
	xx=g_globalWidth;
  if(yy>g_globalHeight)
	yy=g_globalHeight;

  g_Cropper = new uvumiCropper('showdms_2',{
            maskOpacity:0.1,
			mini:{x:xx,y:yy},
			handleSize:0,
			handles:[ 
			['top', 'left'], 
			['top', 'right'], 
			['bottom', 'left'],
			['bottom', 'right'] ],
			//coordinates:true,
			doubleClik:false,
			onComplete:function(top,left,width,height){
				showCoords(top,left,width,height);
			}
  });
  
  clearTimeout(timerChangeImage);

  setTimeout('MoveUvumiWin()',1000);
  timerChangeImage = setTimeout('ChangeImage(1000)',2000);
};

function ChangeImage(time)
{
  g_Cropper.changeImageEPTZ("/dms?nowprofileid="+g_numAllProfile+"&"+Math.random());
  timerChangeImage = setTimeout('ChangeImage(1000)',time);
};

function MoveUvumiWin()
{
//--real resolution of profile.
  //size = l_profileresolution[mpMode-1].split("x");
  
  switch(mpMode)
  {
  case 1:

	if(g_supportHisi)
		g_Cropper.moveToClick_EPTZ(parseInt(g_EPTZ1y1*g_GlobalRateY) , parseInt(g_EPTZ1x1*g_GlobalRateX) );
	else
		g_Cropper.moveToClick_EPTZ(Math.round(g_EPTZ1y1*g_GlobalRateY) , Math.round(g_EPTZ1x1*g_GlobalRateX) ); //20140905
  break;
  case 2:
  
	if(g_supportHisi)
		g_Cropper.moveToClick_EPTZ(parseInt(g_EPTZ2y1*g_GlobalRateY) , parseInt(g_EPTZ2x1*g_GlobalRateX) );
	else
		g_Cropper.moveToClick_EPTZ(Math.round(g_EPTZ2y1*g_GlobalRateY) , Math.round(g_EPTZ2x1*g_GlobalRateX) ); //20140905
  break;
  case 3:

	if(g_supportHisi)
		g_Cropper.moveToClick_EPTZ(parseInt(g_EPTZ3y1*g_GlobalRateY) , parseInt(g_EPTZ3x1*g_GlobalRateX) );
	else
		g_Cropper.moveToClick_EPTZ(Math.round(g_EPTZ3y1*g_GlobalRateY) , Math.round(g_EPTZ3x1*g_GlobalRateX) ); //20140905
  break;
  }
};  
var isFirstOneshowCoords = false;
function showCoords(top,left,width,height)
{ 
  //alert("1 "+top+','+left+','+width+','+height);
  var ratex = (g_baseX/g_globalWidth);
  //var baseY = Math.round(g_baseY/ratex);
  var ratey = ratex;
  //why?? why?? why??
  if(!isFirstOneshowCoords)
  {
    //range : top 320 ,left 240
    g_EPTZmouseX = Math.round(top/ratex);
    g_EPTZmouseY = Math.round(left/ratey);
    g_EPTZWidth = Math.round(width/ratex);
    g_EPTZHeight = Math.round(height/ratey);
  }
  else
  {
    top = top/2;
	left = left/2;
	g_EPTZmouseX = Math.round(top/ratex);
    g_EPTZmouseY = Math.round(left/ratey);
	width = width/2;
	height = height/2;
	g_EPTZWidth = Math.round(width/ratex);
	g_EPTZHeight = Math.round(height/ratey);
  } 
  //alert(top+','+left+','+width+','+height);
  //top = y1 , left = x1
  //var index = GE("AJAXSelChg").options[GE("AJAXSelChg").options.selectedIndex].value;
  /*var size = l_profileresolution[mpMode-1].split('x');
  g_ResolutionX = size[0];
  g_ResolutionY = size[1];
  xx = (g_ResolutionX/320);
  yy = (g_ResolutionY/240);
  
  top = Math.round(top*yy);
  left = Math.round(left*xx);*/
  top = Math.round(top/ratex/g_GlobalRateX);
  left = Math.round(left/ratey/g_GlobalRateY);

  var str_x = '';
  var str_y = '';
  str_x += left;
  str_y += top;
  
  if(top!=g_tempx1 || g_tempy1!=left)
  {
	if(str_x.length < 4)
	{
	  if(str_x.length == 1)
	    str_x='000'+str_x;
	  else if(str_x.length == 2)
		str_x='00'+str_x;
	  else if(str_x.length == 3)  
		str_x='0'+str_x;
	}
	if(str_y.length < 4)
	{
	  if(str_y.length == 1)
	    str_y='000'+str_y;
	  else if(str_y.length == 2)
		str_y='00'+str_y;
	  else if(str_y.length == 3)  
		str_y='0'+str_y;
    }
    g_tempx1 = top;
    g_tempy1 = left;
	//alert(str_x+','+str_y);
	
	if(!EptzPositonWorking && !initialCoords)//--2010.12.21 modified
		SendHttpEPTZ("/vb.htm?eptzcoordinate="+mpMode+str_x+str_y,false);
  }
  
	initialCoords = false;
};

//--2010.12.21 added, for get eptz postion
var timeGetEptzPostion = null;
//var timeMoveEptzPostion = null;
var EptzPositonWorking = false;
var EptzPostionProfile = -1;
var AutoPanOn = false;
var SequenceOn = false;
function StartGetEptzPostion(){
	if(EptzPositonWorking==true)
	{
		clearInterval(timeGetEptzPostion);
		//clearInterval(timeMoveEptzPostion);
	}
		
	timeGetEptzPostion = setInterval("SendEPTZPoint("+mpMode+")", 1000);
	//timeMoveEptzPostion = setInterval("MoveUvumiWin()", 1000);
	
	EptzPostionProfile = mpMode;
	EptzPositonWorking = true;
}
function StopGetEptzPostion(){
	EptzPositonWorking = false;
	EptzPostionProfile = -1;
	
	if(timeGetEptzPostion!=null)
		clearInterval(timeGetEptzPostion);
	//clearInterval(timeMoveEptzPostion);
	timeGetEptzPostion = null;
	//timeMoveEptzPostion = null;
}
//--

function JpegFrameCal()
{
  WS(jpegCounter+" fps");
  if (jpegCounter == 0)
  {
    zeroFpsCount ++;
  }
  else
  {
    zeroFpsCount = 0;
  }
  jpegCounter = 0;
  if (g_dmsRun && !g_lockLink)
  {
    jpegTimer = setTimeout("JpegFrameCal()",200);
  }
  if (zeroFpsCount >= 10)
  {
    zeroFpsCount = 0;
    //this is not good.
//    alert("RESTART DMS");
    var n;
    for (n in g_fetchList)
    {
      var obj = GE("showdms_"+n);
      //alert("n="+n+" obj="+obj);
      if (obj != null)
      {
        g_fetchList[n].RunDms();
      }
    }
    
  }
}

function InitLoad()
{
  //alert(g_langName);
 // alert(g_mui);

  loadJS("/setInnerHTML.js");
  loadJS("/lang_"+g_langName+".js");
};

//you must prepare a <div> element,
//ex: <div id="pppoe_view" style="position:absolute; top:0;left:0;width:0;height:0; z-index:3; visibility:hidden"></div>
//
function PopView(divName,x,y,w,h,url)
{
  var obj = document.getElementById(divName);
  obj.style.top=y;
  obj.style.left=x;
  obj.innerHTML='<table ><tr><td style="border-width:thick;border-color:red"><iframe width='+w+' height='+h+' src="'+url+'" ></iframe></td></tr><tr><td align="center"><input name="PopClose" type="button" value="Close" onClick=PopViewClose("'+divName+'")></td></tr></table>';
}

function PopViewClose(divName)
{
  document.getElementById(divName).style.visibility='hidden';
}
function PopViewCenter(divName,w,h,url)
{
  var x = (document.body.offsetWidth / 2) - (w/2);
  var y = (document.body.offsetHeight / 2) - (h/2);
  PopView(divName,x,y,w,h,url);
}

//20070419 Luther Add ---START---
//add change channel then change the title.
function ChangeChannelTextPanel(id)
{
  var obj = GE("chtxt");
  if (obj != null)
  {
    if (id <= 0)
    {
      id = 1;
    }
    obj.innerHTML = GL("channel") +" "+ id;
  }
}
function GetChannelTextPanelHTML(id)
{
  if (id <= 0)
  {
    id = 1;
  }
  return "<span id='chtxt'>"+GL("channel")+" "+id+"</span>";
}
//20070419 Luther add --- END ---

//20070620 Luther Add ---START---
//add change channel then change the title.
function IsEarlyIpCam()
{
  return (g_machineCode == "1688" || //7214
           g_machineCode == "1788" || //7215
           g_machineCode == "5678" || //7211,7221
           g_machineCode == "5679" || //7211W
		   g_machineCode == "1679");} //7313

//20070620 Luther add --- END ---
//20080204 Luther add ---START---
function GetCookie(name)
{
  var cname= name+"=";
  var dc = document.cookie;
  if(dc.length>0)
  {
    begin = dc.indexOf(cname);
    if(begin!=-1)
    {
      begin=begin+cname.length;
      end=dc.indexOf(";",begin);
      if(end==-1)
      {
        end=dc.length;
      }
      return dc.substring(begin,end);
    }
  }
  return null;
};

function SetCookie(name, value, expires)
{
  CookiesExpDay="365";
  var time = new Date();
  time.setTime(time.getTime()+((86400000)*CookiesExpDay));
  if(expires==null)
  {expires="";}
  document.cookie = name+"="+value+";expires="+ time.toGMTString();
};
function SaveCombo(id,cookieName)
{
  var obj = GE(id);
  if (obj != null)
  {
    var ix = obj.selectedIndex;
    if (ix >=0)
    {
      SetCookie(cookieName,obj.options[obj.selectedIndex].value);
    }
  }
};
function GetCookieInt(name,def)
{
  var i = parseInt(GetCookie(name));
  if (isNaN(i))
  {
    i = def;
  }
  return i;
}
function GetCookieStr(name,def)
{
  var i = GetCookie(name);
  if (i == null)
  {
    i = def;
  }
  return i;
}

if( GetCookie("chromeVerAlert") == null)
	SetCookie("chromeVerAlert", "false");

function UpdateGSize(z)
{
  //1
  if (g_numProfile>=1 && g_isSupP1 && z==1)
  {
    g_viewXSize = g_p1XSize;
    g_viewYSize = g_p1YSize;
  }
  else if (z==1)
  {
    z=2;
  }
  //2
  if (g_numProfile>=2 && g_isSupP2 && z==2)
  {
    g_viewXSize = g_p2XSize;
    g_viewYSize = g_p2YSize;
  }
  else if (z==2)
  {
    z=3;
  }
  //3
  if (g_numProfile>=3 && g_isSupP3 && z==3)
  {
    g_viewXSize = g_p3XSize;
    g_viewYSize = g_p3YSize;
  }
  else if (z==3)
  {
    z=4;
  }
  
  //4
  if (g_isSupP4 && z==4)
  {
    g_viewXSize = g_p4XSize;
    g_viewYSize = g_p4YSize;
  }
  else if (z==4)
  {
    z=1;
  }
  //alert(g_viewXSize+":"+g_viewYSize);
  //alert(g_isSupP1+":"+g_isSupP2+":"+g_isSupP3+":"+z);
  return z;
}

function UpdateDmsSize(z)
{
  //1
  if (g_isSupP1 && z==1)
  {
    g_viewXSize = g_p1XSize;
    g_viewYSize = g_p1YSize;
  }
  else if (z==1)
  {
    z=2;
  }
  //2
  if (g_isSupP2 && z==2)
  {
    g_viewXSize = g_p2XSize;
    g_viewYSize = g_p2YSize;
  }
  else if (z==2)
  {
    z=3;
  }
  //3
  if (g_isSupP3 && z==3)
  { 
    g_viewXSize = g_p3XSize;
    g_viewYSize = g_p3YSize;
	if(g_supportHisi)
		z=4;
  }
  else if (z==3)
  {
    z=4;
  }
  
  //4
  if (g_isSupP4 && z==4)
  {
    g_viewXSize = g_p4XSize;
    g_viewYSize = g_p4YSize;

  }
  else if (z==4)
  {
	if(g_supportHisi)
	    z=4;
	else
		z=1;
  }
  return z;
}

function GetJpegMpeg4Ctx(index,useActiveX,onChang)
{
  var o='';
  o+='<select onChange='+onChang+' id='+((useActiveX==1)?'JpegMpeg4Chg':'AJAXJpegChg')+' class="m1">';
  if (g_isSupS1)
    o+='<option value="1" '+((index==1)?'selected':'')+' >'+g_stream1name+'</option>';
  if (g_isSupS2)
    o+='<option value="2" '+((index==2)?'selected':'')+' >'+g_stream2name+'</option>';
  if (g_isSupS3 && useActiveX == 1)
    o+='<option value="3" '+((index==3)?'selected':'')+' >'+g_stream3name+'</option>';
  if (g_isSupS4 && useActiveX == 1)
    o+='<option value="4" '+((index==4)?'selected':'')+' >'+g_stream4name+'</option>';
  o+='</select>';
  return o;
};
function CheckBrowser()
{ 
  var cb = "Unknown"; 
  if(window.ActiveXObject)
  { 
    cb = "IE"; 
  }
  else if(navigator.userAgent.toLowerCase().indexOf("firefox") != -1)
  { 
    cb = "Firefox"; 
  }
  else if(navigator.userAgent.toLowerCase().indexOf("chrome") != -1)
  { 
    cb = "Chrome"; 
  }
  else if(navigator.userAgent.toLowerCase().indexOf("opera") != -1)
  { 
      cb = "Opera"; 
  } 
  else if((typeof document.implementation != "undefined") && (typeof document.implementation.createDocument != "undefined") && (typeof HTMLDocument != "undefined"))
  { 
    cb = "Mozilla"; 
  }
  return cb; 
};
function IsNumericRange(sText,start,end)
{
  var ValidChars = "0123456789."; 
  var IsNumber=true; 
  var Char; 
  for (i = 0; i < sText.length && IsNumber == true; i++) 
  { 
    Char = sText.charAt(i); 
    if (ValidChars.indexOf(Char) == -1) 
    { 
      return false; 
    } 
  }
  if(start!=null)
  {
    sText=parseInt(sText);
    start=parseInt(start);
    end=parseInt(end);
    if(sText<start || sText>end)
    {
      return false; 
    }
  }	
  
  return IsNumber;   
}

function ShowDiv(oRad,id)   
{   
  var Layer_choice;     
  if (document.getElementById) 
  { //Netscape 6.x   
    Layer_choice = eval("document.getElementById(\" "+id+" \")");   
  }   
  else 
  { // IE 5.x   
    Layer_choice = eval(" \"document.all.choice."+id+" \" ");   
  }   
  
  if(Layer_choice)
  {   
    if(oRad == true)   
    {  
       Layer_choice.style.display='';   
    }
    else  
    {   
       Layer_choice.style.display='none';   
    }   
  }   
};

function Ctrl_SelectEx(id,list,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "select";
  this.active = !(inactive==true);
  this.id = id;
  this.list = list;
  this.value = val;
  this.setcmd = setcmd;
  this.onChangeFunc = onChangeFunc;
  this.checker = checker;
  this.html = SelectObjectNoWriteEx(this.id,this.list,this.value,this.onChangeFunc);
  this.GV = function (){ return GetValue(this.id); };
  this.SV = function (val){ SetValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.rehtml = function(newlist,val){ 
	return SelectObjectNoWriteEx(this.id, newlist, (val!=null)?val:this.value, this.onChangeFunc);
  };
  this.rehtmlEx = function(newArray,val){ 
	return SelectObjectNoWriteExAry(this.id, newArray, (val!=null)?val:this.value, this.onChangeFunc);
  };
};

function SelectObjectNoWriteEx(strName,strOption,intValue,onChange)
{
  var o='';
  o+='<SELECT NAME="'+strName+'" id="'+strName+'" class="m1"';
  if (onChange == null)
  {
    o+='>';
  }
  else
  {
    o+=' onChange="'+onChange+'" >';
  }
  aryOption = strOption.split(';');
  for (var i = 0; i<aryOption.length; i++)
  {
    if(aryOption[i]==intValue)
    {
      o+='<OPTION selected value="'+aryOption[i]+'">'+aryOption[i];
    }
    else
    {
      o+='<OPTION value="'+aryOption[i]+'">'+aryOption[i];
    }
  }
  o+='</SELECT>';
  return o;
};

function SelectObjectNoWriteExAry(strName,aryOption,intValue,onChange)
{
  var o='';
  o+='<SELECT NAME="'+strName+'" id="'+strName+'" class="m1"';
  if (onChange == null)
  {
    o+='>';
  }
  else
  {
    o+=' onChange="'+onChange+'" >';
  }
  for (var i = 0; i<aryOption.length; i++)
  {
	var strOption = regexhtmlstr(aryOption[i]);
    if(aryOption[i]==intValue)
    {
      o+='<OPTION selected value="'+strOption+'">'+strOption;
    }
    else
    {
      o+='<OPTION value="'+strOption+'">'+strOption;
    }
  }
  o+='</SELECT>';
  return o;
};

function regexhtmlstr(str)
{
	var str1 = str.replace(/\\/ig, '\\');	//replace \ to \\.
	str1 = str1.replace(/\"/ig, '&quot;');		//replace " to \".
	str1 = str1.replace(/\'/ig, "&#39;");		//replace ' to \'.
	return str1;
};

function Ctrl_SelectEx1(id,itemlist,valuelist,val,setcmd,onChangeFunc,checker,inactive)
{
  this.type = "select";
  this.active = !(inactive==true);
  this.id = id;
  this.itemlist = itemlist;
  this.valuelist = valuelist;
  this.value = val;
  this.setcmd = setcmd;
  this.onChangeFunc = onChangeFunc;
  this.checker = checker;
  this.html = SelectObjectNoWriteEx1(this.id,this.itemlist,this.valuelist,this.value,this.onChangeFunc); 
  this.GV = function (){ return GetValue(this.id); };
  this.SV = function (val){ SetValue(this.id,val); };
  this.IsPass = function (isQuite){ return CPASS(this,isQuite);};
  this.rehtml = function(newlist,newValue,val){ 
	return SelectObjectNoWriteEx1(this.id,newlist,newValue,(val!=null)?val:this.value,this.onChangeFunc);
  };
};

function SelectObjectNoWriteEx1(strName,strOption,strValue,intValue,onChange)
{
	var aryValue=null,aryOption=null;
	var val = '';
	
  var o='';
  o+='<SELECT NAME="'+strName+'" id="'+strName+'" ';
  if (onChange == null)
  {
    o+='>';
  }
  else
  {
    o+=' onChange="'+onChange+'" >';
  }
  aryOption = strOption.split(';');
  if(strValue!=null && strValue!="")
	aryValue = strValue.split(';');
  for (var i = 0; i<aryOption.length; i++)
  {
	o+='<OPTION ';
	  
	if(aryValue==null || aryOption.length!=aryValue.length || aryValue[i]==null)
		val = i;
	else
		val = aryValue[i];
	
    if(val==intValue)
      o+='selected ';
		
    o+='value="'+val+'">'+aryOption[i];
  }
  o+='</SELECT>';
  return o;
};

function CheckIpFormat(val,msg,isQuite)
{
  var result = false;
  var valArray = val.split('.');
  if(valArray.length != 4)
  {
    //alert(GL(msg));
    ShowDLinkWarning(GL(msg));
  }
  else
  {
    for(i=0;i<4;i++)
	{
	  if(!IsNum(valArray[i]))
	  {
	    //alert(GL(msg));
	    ShowDLinkWarning(GL(msg));
		return false;
	  }	
	  if(!(parseInt(valArray[i]) >=0 && parseInt(valArray[i]) <=255))
	  {
	    //alert(GL(msg));
	    ShowDLinkWarning(GL(msg));
		return false;
	  }	
	}
	result = true;
  }
  return result;
};

function IsNum(id)
{  
  var tmp;
  var z="0123456789";
  var nab=id.length-1;
  for (var i=0;i<=nab;i++)
  {  
    tmp=id.substr(i,1);
    if (z.indexOf(tmp) == -1) { return false; }  
  }  
  return true;
};
if(g_isIpcam)
  var g_str = GL("ipcam_str"); 
else
  var g_str = GL("videoserver_str");
  
//--start 2010.12.27 copy from appro
var g_isHttp = true;
switch(window.location.protocol) 
{
    case "http:":
      g_isHttp = true;
    break ;
    case "https:":
	  g_isHttp = false;
    break;
    default:
	  g_isHttp = true;
    break;
};
//--

//--start 2011.1.3 added
function sleep(milliSeconds){
	var startTime = new Date().getTime(); // get the current time
	while (new Date().getTime() < startTime + milliSeconds); // hog cpu 
}
//--end 2011.1.3


//--start 2011.7.19
function CutString(OldStr, MaxLen)
{	
	var NewStr = "";
	if(OldStr.length>MaxLen)
	{
		NewStr = OldStr.substr(0, MaxLen);
		NewStr += "..";
		//NewStr += "\n";
		//NewStr += OldStr.substr(MaxLen, OldStr.length);
		return NewStr;
	}
	else
	{
		return OldStr;
	}
};
//--end 2011.7.19

var g_isCookieActivex = GetCookie('ActiveX');		//20140623 add
if(g_isCookieActivex == null)
{
  if(browser_IE)
  {
    SetCookie('ActiveX',1);
    g_isCookieActivex = 1;
  }
  else
  {
    SetCookie('ActiveX',0);
    g_isCookieActivex = 0;
  }
};
//--end 2012.6.13


//�h���r�ꥪ�䪺�ťյ��
function ltrim(instr){
	return instr.replace(/^[\s]*/gi,"");
};

//�h���r��k�䪺�ťյ��
function rtrim(instr){
	return instr.replace(/[\s]*$/gi,"");
};

//�h���r��e�᪺�ťյ��
function trim(instr){
	instr = ltrim(instr);
	instr = rtrim(instr);
	return instr;
};

//add williamchen 2013.06.25
function check_IE7or8()			//20140623 add
{
	var isIE7 = navigator.userAgent.search("MSIE 7") > -1;
	var isIE8 = navigator.userAgent.search("MSIE 8") > -1;
	return (isIE7 || isIE8);

}

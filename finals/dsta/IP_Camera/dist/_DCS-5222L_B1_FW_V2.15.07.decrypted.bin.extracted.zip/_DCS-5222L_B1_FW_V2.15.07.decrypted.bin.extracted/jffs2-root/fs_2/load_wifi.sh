#!/bin/sh
cd /opt/ipnc
read -r wifimac < /proc/appro/get_mac0
read -r wifichnplan < /proc/appro/channel_plan
if [ -n "$wifimac" ]; then
insmod wlan.ko rtw_initmac=$wifimac rtw_channel_plan=$wifichnplan
else
insmod wlan.ko rtw_channel_plan=$wifichnplan
fi

cp /opt/ipnc/etc/wpa_supplicant.conf /etc
/opt/ipnc/wpa_supplicant -Dwext -iwlan0 -c/etc/wpa_supplicant.conf -B

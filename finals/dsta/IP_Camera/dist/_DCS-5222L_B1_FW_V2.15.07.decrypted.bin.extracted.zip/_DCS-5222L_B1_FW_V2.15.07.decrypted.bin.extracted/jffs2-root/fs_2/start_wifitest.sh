#!/bin/sh
/sbin/ifconfig eth0 192.168.3.240 netmask 255.255.252.0 up
/usr/sbin/telnetd &
cd /opt/ipnc
insmod 8188eu_mp.ko
sleep 1
/sbin/ifconfig wlan0 up
echo V > /dev/watchdog


#!/bin/sh
export ISEXFAT=`fdisk -l /dev/mmcblk0 | sed -n '/\/dev\/mmcblk0p1/p' | sed -n 's/.*\(NTFS\).*/\1/p'`
if [ "$ISEXFAT" = "NTFS" ]; then
echo change to FAT32
cat << _eof_ | fdisk /dev/mmcblk0 > /dev/null 2> /dev/null
t
b
w
q
_eof_
fi


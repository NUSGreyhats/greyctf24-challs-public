#!/bin/sh

export LD_LIBRARY_PATH=/opt/ipnc/lib
export SSL_CERT_FILE=/opt/ipnc/etc/ca-bundle.crt
export PATH=$PATH:/opt/ipnc/ko_hi3518/
export FUSEMODULE=`gzip -dc /proc/config.gz | sed -n 's/CONFIG_FUSE_FS=m/M/p'`

if [ -f /proc/sys/kernel/printk ]; then
	echo 3 7 1 4 >  /proc/sys/kernel/printk
fi

/opt/ipnc/initial

if [ "$FUSEMODULE" = 'M' ]; then
	insmod /opt/ipnc/fuse.ko
	insmod /opt/ipnc/cuse.ko
fi

cd /opt/ipnc/ko_hi3518
./load3518 -i ov9712
cd /opt/ipnc
insmod /opt/ipnc/gpio.ko
ifconfig lo up
mkdir -p /etc/avahi/services
mkdir -p /etc/dhcpv6 /var/run/dhcpv6
cp /opt/ipnc/etc/avahi-daemon.conf /etc/avahi
cp /opt/ipnc/etc/boa.conf /etc
cp /opt/ipnc/etc/ppp/ip-* /etc/ppp
cp /opt/ipnc/etc/ushare.conf /etc
cp /opt/ipnc/etc/esmtprc /etc
cp /opt/ipnc/etc/quftprc /etc
cp /opt/ipnc/etc/ca-bundle.crt /etc

/opt/ipnc/watchdog &

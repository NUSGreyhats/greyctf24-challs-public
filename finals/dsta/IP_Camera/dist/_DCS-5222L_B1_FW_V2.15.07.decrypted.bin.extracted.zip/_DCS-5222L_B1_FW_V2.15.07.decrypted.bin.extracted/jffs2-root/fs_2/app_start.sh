#!/bin/sh
# Program:
#       This program load ".ko" and some default files
# History:
# 2013/03/07	sheppard

#Get mpp.ko
mount -t nfs -o nolock -o udp 192.168.1.200:/home/raul/work/dm355/nfs /mnt/nfs
cp -r /mnt/nfs/tmp/mpp_sdk3.0/ko_hi3518 /opt/ipnc
cp -r /mnt/nfs/tmp/himm /opt/ipnc/ko_hi3518
umount /mnt/nfs
#Get kill.sh mime.types
mount -t nfs -o nolock,udp 192.168.1.200:/home/sheppard/work/hisilicon/nfs /mnt/nfs
cp /mnt/nfs/killa.sh /opt/ipnc
cp /mnt/nfs/mime.types /etc
umount /mnt/nfs
#Get user compiler file ,change sheppard to your name!
mount -t nfs -o nolock,udp 192.168.1.200:/home/sheppard/work/hisilicon/nfs /mnt/nfs
cp /mnt/nfs/opt/8691/ipnc/etc/boa.conf /etc

cp /mnt/nfs/opt/8691/ipnc/avserver /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/server /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/httpd /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/LANDAP /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/scanip /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/log /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/syslogd /opt/ipnc/
#cp /mnt/nfs/opt/8691/ipnc/upnpc /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/pppoe /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/udhcpc /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/udhcpc.script /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/tmp_manage /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/onvif_discovery /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/watchdog /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/Font_64x48.fnt /opt/ipnc/

cp /mnt/nfs/opt/8691/ipnc/ioport.ko /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/gpio.ko /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/ushare /opt/ipnc/
cp /mnt/nfs/opt/8691/ipnc/ushare.conf /etc

cp -r /mnt/nfs/opt/8691/ipnc/lib /opt/ipnc/
cp -r /mnt/nfs/opt/8691/ipnc/onvif /opt/ipnc/
cp -r /mnt/nfs/opt/8691/ipnc/cgi-bin/ /opt/ipnc/
cp -r /mnt/nfs/opt/8691/www/* /opt/www
cp -r /mnt/nfs/opt/8691/ipnc/etc/ppp /opt/ipnc

cp /mnt/nfs/opt/8691/ipnc/start.sh /opt/ipnc
/opt/ipnc/start.sh



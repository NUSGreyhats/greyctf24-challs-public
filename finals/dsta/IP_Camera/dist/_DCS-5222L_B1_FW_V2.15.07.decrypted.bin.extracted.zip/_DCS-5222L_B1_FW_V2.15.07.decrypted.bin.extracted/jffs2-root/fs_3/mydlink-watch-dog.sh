#!/bin/sh

##########################
# mydlink agent checking #
##########################
# $1: process name
# $2: launch argument

CA_PID_FILE="ca-update.pid"
DST_SRV="http://ca-mgr.auto.mydlink.com/default"
TMP_CA="/tmp/.tmp.ca.file"
PUB_KEY="/mydlink/public-key.pem"
CA_CHECK_FLAG="/tmp/.ca.check.flag"
CA_FILE="/etc/ca-bundle.crt"

check_alive() {
  pid=`ps | grep $1 | grep -v grep | sed 's/^[ \t]*//'  | sed 's/ .*//'`
  if [ -z "$pid" ]; then
    echo "[`date`] $1 is not running!"

    killall $1
    $MYDLINK_BASE/$1 $2 > /dev/null 2>&1 &
    restart_cnt=`expr $restart_cnt + 1`
    if [ "$restart_cnt" -gt 6 ]; then
      echo "reboot cause device agent can't startup"
      reboot
    fi
  else
    restart_cnt=0
  fi
}

# Check duplicate agents
check_duplicate_agents() {
  num=`ps | grep $MYDLINK_BASE/signalc | grep -v grep -c`
  if [ "$num" -gt "1" ]; then
    echo "[`date`] Duplicate signalc ..."
    $MYDLINK_BASE/opt.local start
  fi
}

# Verify CA file

set_checked() {
  echo `date +"%s"` > $CA_CHECK_FLAG
}

ERR_NO_ERROR=0
ERR_NO_CHANGE=1
UPDATE_EXEF_EXIST=1

if [ -f /mydlink/ca-refresh ]; then
  /mydlink/ca-refresh "${DST_SRV}" "${CA_FILE}" "${TMP_CA}" "${PUB_KEY}" 
elif [ -f /opt/ca-refresh ]; then
  /opt/ca-refresh "${DST_SRV}" "${CA_FILE}" "${TMP_CA}" "${PUB_KEY}"
else
  echo "CA refresh fail cause ca-update app not exist"
  UPDATE_EXEF_EXIST=0
fi

ret=$?

if [ $ret -eq $ERR_NO_ERROR ] && [ $UPDATE_EXEF_EXIST -eq 1 ]; then
  retry=0
  while [ $retry -lt 3 ] 
  do
    let retry=$retry+1
    mdb set cainfo "${TMP_CA}"
    if [ $? -eq 0 ]; then
      break;
    fi
    if [ $retry -ge 3 ]; then
      echo "mdb cainfo fail"
    fi
  done
elif [ $ret -eq $ERR_NO_CHANGE ]; then
  set_checked
  rm -f $TMP_CA
  rm -f $PID_FILE
else
  echo "CA doesn't exist or overdue"
fi


# Get mydlink folder
MYDLINK_BASE="/mydlink"
if [ -f /mydlink/signalc ]; then
  MYDLINK_BASE="/mydlink"
elif [ -f /opt/signalc ]; then
  MYDLINK_BASE="/opt"
fi

# Set mydlink into PATH
export PATH=$MYDLINK_BASE:$PATH

# Get model name
MODEL_NAME="Unknown"
HAS_MDB=`mdb get dev_model | grep "L" -c`
if [ "1" -eq "$HAS_MDB" ]; then
  MODEL_NAME=`mdb get dev_model`
else
  wlan=`pibinfo Wireless`
  if [ "$wlan" = "1" ]; then
    MODEL_NAME=`tdb get System ModelW_ss`
  else
    MODEL_NAME=`tdb get System Model_ss`
  fi
fi

# Get LAN interface
LAN_INT="br0"
HAS_BR0=`ifconfig | grep "br0" -c`
if [ "$HAS_BR0" -ge "1" ]; then
  LAN_INT="br0"
else
  LAN_INT="eth0"
fi

restart_cnt=0
# Check agent status
while [ 1 ]
do
  sleep 5

  #check duplicate agent
  check_duplicate_agents

  # check mydlink agents
  check_alive signalc
  check_alive dcp "-i $LAN_INT -m $MODEL_NAME"

done


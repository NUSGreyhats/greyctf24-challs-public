#include <stdio.h>
int main(){char buf[1];return fgets(buf, 0x80, stdin);}
